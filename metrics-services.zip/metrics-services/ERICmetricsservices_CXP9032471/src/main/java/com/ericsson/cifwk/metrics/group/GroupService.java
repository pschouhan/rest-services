/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2015
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.group;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.exception.MetricsServiceException;
import com.ericsson.cifwk.metrics.sprint.Sprint;
import com.ericsson.cifwk.metrics.sprint.SprintRepository;
import com.google.common.base.Strings;

@Service
public class GroupService {

    private static final String PATTERN_DATEFORMAT = "dd/MM/yyyy";
    private static final String NO_DATA = "NO DATA";
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static final String VALUE = "value";
    private static final String TIME = "time";
    private static final String DELIVERED = "DELIVERED";
    private static final String OBSOLETED = "OBSOLETED";
    private static final String ARTIFACTS_IN_QUEUE = "artifactsInQueue";
    private static final String QUEUE_LENGTH = "queueLength";
    private static final String ARTIFACT_AVG = "artifactAvg";
    private static final String QUEUE_AVG = "queueAvg";
    private static final String ARTIFACT_PERCENTAGE = "artifactPercentage";
    private static final String QUEUE_PERCENTAGE = "queuePercentage";
    private static final String VALID = "valid";
    private static final String INVALID = "% difference not available";
    private static final String INFO = "info";
    private static final String TOO_MUCH = "Too much data to load";
    private static final String TOO_MANY = "Too many days to load";
    private static final String GROUPS = "Groups";
    private static final String ARTIFACTS = "Artifacts";
    private static final String DATA = "data";
    private static final String LABEL = "label";
    private static final String DATE_TIME = "dateTime";
    private static final String SPRINT_REGEX = "[0-9]+(\\.[0-9]+)";
    private static final String START_DATE = "startDate";
    private static final String SPRINT_KEY = "sprint";
    private static final String ARTIFACT_WEEK_KEY = "artifactWeek";
    private static final String GROUPS_WEEK_KEY = "groupsWeek";
    private static final String TESTWARE_WEEK_KEY = "testwareWeek";
    private static final String WEEK_FROM = "week?From";
    private static final String WEEK_TO = "week?To";

    @Value("${es.data.limit}")
    private int esDataLimit;

    @Value("${product}")
    private String product;

    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private SprintRepository sprintRepository;

    @Autowired
    private ServerDateTime serverDateTime;

    /**
     * Obtains Group, Artifact and Testware count on a daily basis for the
     * lapsed days in the sprint. Uses Sprint service to get all current Sprint
     * Information.
     *
     * @return Group, Artifact and Testware count per day list
     */
    public List<Map<String, Object>> getGroupArtifactAndTestwareCountOnDaily() {
    	// Get groupArtifactTestwareCount for status Delivered
        final List<Map<String, Object>> deliveredGroupArtifactTestwareCount = groupRepository.findGroupArtifactAndTestwareCountOnDaily(DELIVERED, getCurrentSprint());
        //Get groupArtifactTestwareCount for status obsoleted
        final List<Map<String, Object>> obsoletedGroupArtifactTestwareCount = groupRepository.findGroupArtifactAndTestwareCountOnDaily(OBSOLETED, getCurrentSprint());
        final List<Map<String, Object>> groupArtifactTestwareCount = getGroupArtifactTestwareTotalCount(deliveredGroupArtifactTestwareCount,obsoletedGroupArtifactTestwareCount);
      
        final List<Map<String, Object>> deliveredTestwareGroupCount = groupRepository.findTestwareGroupCountOnDaily(DELIVERED,getCurrentSprint());
        final List<Map<String, Object>> obsoletedTestwareGroupCount =groupRepository.findTestwareGroupCountOnDaily(OBSOLETED,getCurrentSprint());
        final List<Map<String, Object>> testwareGroupCountMap= getGroupArtifactTestwareTotalCount(deliveredTestwareGroupCount,obsoletedTestwareGroupCount);
        
        final List<Map<String, Object>> resultMap= getGroupArtifactTestwareTotalCount(groupArtifactTestwareCount,testwareGroupCountMap);
        
        logger.debug("Sprint Group Artifact and Testware Details: {}", resultMap);
        return resultMap;

    }

    /**
     * Obtains Group, Artifact and Testware count on a daily basis for the days
     * in the given range.
     *
     * @param startTime
     * @param endTime
     * @param status
     * @return Group, Artifact and Testware count per day list
     */
    public List<Map<String, Object>> getGroupArtifactAndTestwareCountOnDailyBetweenStatusTime(
            final long startTime, final long endTime) {
        long beginingTime = startOfDay(new DateTime(startTime));
        long endingTime = endOfDay(new DateTime(endTime));
        if (beginingTime == 0 || endingTime == 0) {
            endingTime = getCurrentSprint().getEndTimeInMillis();
            beginingTime = getCurrentSprint().getStartTimeInMillis();
        }
        logger.debug("Find delivery count trend from:{} ,to:{}", beginingTime, endingTime);
        final List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        if (!validDataCountForDeliveryTrends(beginingTime, endingTime)) {
            final Map<String, Object> map = new HashMap<String, Object>();
            map.put(INFO, TOO_MANY);
            list.add(map);
            return list;
        }
        
         List<Map<String, Object>> resultMap= new ArrayList<>();
        	// Get  groupArtifactTestwareCount for status DELIVERED
            final List<Map<String, Object>> deliveredGroupArtifactTestwareCount = groupRepository
                    .findGroupArtifactAndTestwareCountOnDailyBetweenStatusTime(
                    		DELIVERED,beginingTime,endingTime);
            // Get  groupArtifactTestwareCount for status OBSOLETED
            final List<Map<String, Object>> obsoletedArtifactTestwareCount = groupRepository
                    .findGroupArtifactAndTestwareCountOnDailyBetweenStatusTime(
                    		OBSOLETED,beginingTime,endingTime);
           final List<Map<String, Object>> groupArtifactTestwareCount = getGroupArtifactTestwareTotalCount(deliveredGroupArtifactTestwareCount,obsoletedArtifactTestwareCount);
            resultMap =groupArtifactTestwareCount;
            Long testwareGroupDate = 1458172800000l;//17th of march 2016
          if(beginingTime>=testwareGroupDate && endingTime>=testwareGroupDate){
        	final List<Map<String, Object>> deliveredGroupArtifactTestwareGroupCount=groupRepository.
        			findTestwareGroupCountOnDailyBetweenStatusTime(DELIVERED,beginingTime,endingTime);
        	 final List<Map<String, Object>> obsoletedArtifactTestwareGroupCount = groupRepository
                     .findGroupArtifactAndTestwareCountOnDailyBetweenStatusTime(
                     		OBSOLETED,beginingTime,endingTime);
        	final List<Map<String, Object>> groupArtifactTestwareGroupCount= getGroupArtifactTestwareTotalCount(deliveredGroupArtifactTestwareGroupCount,obsoletedArtifactTestwareGroupCount);
        	resultMap=getGroupArtifactTestwareTotalCount(groupArtifactTestwareCount,groupArtifactTestwareGroupCount);
        }
        
        
        logger.debug("Sprint Group Artifact and Testware Details: {}", groupArtifactTestwareCount);
        return resultMap;
    }

    
    private List<Map<String, Object>> getGroupArtifactTestwareTotalCount(final List<Map<String,Object>> deliveredList,
    		final List<Map<String,Object>> obsoletedList) {
   	 final List<Map<String, Object>> groupArtifactTestwareCount = new ArrayList<>();
	       for(int i=0; i<deliveredList.size(); i++){
	    	 Map<String, Object>  deliveredMap = deliveredList.get(i);
	    	 Map<String, Object>  obsoletedMap = obsoletedList.get(i);
	    	 Object deliveredDateValue = deliveredMap.get(DATE_TIME);
	    	 Object obsoletedDateValue = obsoletedMap.get(DATE_TIME);
	    	 if (deliveredDateValue.equals(obsoletedDateValue)){
	    		 deliveredMap.putAll(obsoletedMap);
	    		 groupArtifactTestwareCount.add(deliveredMap);
	    	 }
	       }
	       return groupArtifactTestwareCount;
    }
    
	/**
	 * Obtains list of current waiting queue details which calculate the
	 * timeInQueue difference with current time and sorted them
	 *
	 * @return queue list including with missing dependency, KGB status, queue
	 *         id delivered to the drop.
	 */
	public List<Group> getCurrentWaitingQueue() {
		final List<Group> groups = groupRepository.findWaitingQueueDetails(getCurrentSprint().getName());
		logger.debug("Current Waiting queue Group Details:{}", groups);
		groups.stream()
				.forEach(g -> g.setTimeInQueue(calculateWaitingTime(g.getTimeInQueue(), g.getStatusTimeInMillies())));
		Comparator<Group> byTimeInQueue = (e1, e2) -> Long.compare(e2.getTimeInQueue(), e1.getTimeInQueue());
		return groups.stream().sorted(byTimeInQueue).collect(Collectors.toList());
	}

	/**
	 * The Method calculates time differences from current time and to timeInQueue value
	 * @param timeInQueue
	 * @param statusTime
	 * @return calculated time
	 */
	private long calculateWaitingTime(final long timeInQueue, final long statusTime) {
		final long diffTime = (serverDateTime.getCurrentDateTime().getMillis() - statusTime) / (60 * 1000);
		return timeInQueue + diffTime;
	}

    /**
     * Obtains top ten teams that have delivered to the drop. Uses Sprint
     * service to get all current Sprint Information.
     *
     * @return group count and team name top ten list from teams that have
     *         delivered to the drop.
     */
    public List<Map<String, Object>> getDeliveredTeams() {
	final Sprint sprint = getCurrentSprint();
	final List<Map<String, Object>> teams = groupRepository.findTeamsContributedInDropByStatus(DELIVERED,
		sprint.getName(), sprint.getStartTimeInMillis(), sprint.getEndTimeInMillis());

	logger.debug("Top delivering Teams: {}", teams);
	return teams;
    }

    /**
     * Obtains Current activity in the queue. Today's number of artifacts in
     * queue and queue length and Calculates the difference percentage of
     * artifacts and Queue length against yesterday based on day's average.
     *
     * @return Map <artifactPercentage> artifacts percentage difference
     *         <queuePercentage> queue percentage difference
     *         <queueLength> Today's queue length <artifactsInQueue> Today's
     *         number of artifacts in queue
     */
    public Map<String, Object> getCurrentQueueActivity() {
	final Map<String, Object> today = getAverageQueueDetailsforToday();
	logger.debug("Average Group Details ,today:{}", today);
	final Map<String, Object> yesterday = getAverageQueueDetailsforYesterday();
	logger.debug("Average Group Details , yesterday:{}", yesterday);
	final int limitforLatesDetails = 1;
	final Group group = getLatestQueueDetails(limitforLatesDetails);
	logger.debug("Latest Group Details:{}", group);
	final Double todayQueueLength = (Double) today.get(QUEUE_AVG);
	final Double todayArtifacts = (Double) today.get(ARTIFACT_AVG);
	final Double yesterdayQueueLength = (Double) yesterday.get(QUEUE_AVG);
	final Double yesterdayArtifacts = (Double) yesterday.get(ARTIFACT_AVG);
	int artifactPercentage = 0, queuePercentage = 0;
	final Map<String, Object> map = new HashMap<String, Object>();
	if (yesterdayQueueLength > 0) {
	    queuePercentage = (int) Math.round((todayQueueLength - yesterdayQueueLength) * 100 / yesterdayQueueLength);
	    artifactPercentage = (int) Math.round((todayArtifacts - yesterdayArtifacts) * 100 / yesterdayArtifacts);
	    map.put(INFO, VALID);
	} else {
	    map.put(INFO, INVALID);
	}
	map.put(ARTIFACT_PERCENTAGE, artifactPercentage);
	map.put(QUEUE_PERCENTAGE, queuePercentage);
	map.put(QUEUE_LENGTH, group.getQueueLength());
	map.put(ARTIFACTS_IN_QUEUE, group.getArtifactsInQueue());
	logger.debug("Service retrieving Current Queue Activity information:{}", map);
	return map;
    }

    /**
     * Obtains details about change of delivery queue length and artifact count
     * in given time period
     *
     * @param startTime
     * @param endTime
     * @return Map <info> gives information about data available or not
     *         <data> List<Map <String, Object>> contains different legends for
     *         generating graphs
     */
    public Map<String, Object> getQueueTrendBetweenTime(final long startTime, final long endTime) {
	long beginingTime = startTime, endingTime = endTime;
	if (beginingTime == 0 || endingTime == 0) {
	    endingTime = serverDateTime.getCurrentDateTime().getMillis();
	    beginingTime = serverDateTime.getCurrentDateTime().minusMonths(3).getMillis();
	}
	logger.debug("Find delivery queue trend for:{} from:{} ,to:{}", product, beginingTime, endingTime);
	final Map<String, Object> map = new HashMap<String, Object>();
	if (!validDataCountForTrends(beginingTime, endingTime)) {
	    map.put(INFO, TOO_MUCH);
	    return map;
	}
	logger.debug("getQueueTrendBetweenTime Data Count is less than {} limit", esDataLimit);
	final List<Group> groups = groupRepository.findByProductBetweenStatusTime(beginingTime, endingTime, product,
		esDataLimit);
	if (groups.isEmpty()) {
	    map.put(INFO, NO_DATA);
	} else {
	    map.putAll(generateQueueTrendMapfromGroups(groups));
	}
	logger.debug(" Data Map :{}", map);
	return map;
    }

    /**
     * Method gives information about total number of artifacts ,group and
     * testware delivered in a certain time period The default time period is
     * sprint duration. Status should be provided
     *
     * @param startTime
     * @param endTime
     * @param status
     * @return Map contains count for group artifacts and testware in given time
     *         interval
     */
    public Map<String, Object> getTotalCountForDeliveries(final long startTime, final long endTime,
	    final String status) {
	long beginingTime = startOfDay(new DateTime(startTime));
	long endingTime = endOfDay(new DateTime(endTime));
	if (startTime == 0 || endTime == 0) {
	    endingTime = getCurrentSprint().getEndTimeInMillis();
	    beginingTime = getCurrentSprint().getStartTimeInMillis();
	}
	// Format for input
	final Map<String, Object> map = new HashMap<>();
	final String startDate = "startDate", endDate = "endDate";
	map.put(startDate, parseDate(beginingTime));
	map.put(endDate, parseDate(endingTime));
	map.putAll(groupRepository.findTotalGroupArtifactAndTestwareBetweenDateTimeByStatus(beginingTime, endingTime,
		status.trim().toUpperCase()));
	return map;
    }

    /**
     * Method gives information about group,artifact,testware for each sprint in
     * the queue split by week
     *
     * @param startSprint
     * @param endSprint
     * @return List of items, one for each sprint which contains
     *         artifact,testware,groups for each week of the sprint
     */

    public List<Map<String, Object>> getProfileActivities(final String startSprint, final String endSprint) {
	final int defaultLimit = 5;
	   final List<Sprint> sprints =
	                sprintRepository.findByDateTimeTillToday(serverDateTime.getCurrentDateTime().getMillis(), new PageRequest(0, defaultLimit, new Sort(
	                        Direction.DESC, START_DATE)));

	String startSprintValue = startSprint, endSprintValue = endSprint;
	
	
		logger.debug("chosen parameters: start sprint {} and end sprint {}",startSprintValue,endSprintValue);
	 if (Strings.isNullOrEmpty(startSprint) && Strings.isNullOrEmpty(endSprint)) {
	            // both params should be null for default condition
	     endSprintValue  = sprints.stream().findFirst().get().getName();;
	     startSprintValue  = sprints.stream().reduce((first, second) -> second).get().getName();
	            logger.debug("Going to load Default Sprint Profile Trend Data");
	        } else if (Strings.isNullOrEmpty(startSprint) || Strings.isNullOrEmpty(endSprint)) {
	            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid sprint range has been provided");
	        }
	        // Pattern to match sprint names
	        if (!matchPattern(startSprintValue, SPRINT_REGEX) || !matchPattern(endSprintValue, SPRINT_REGEX)) {
	            // If sprint names doesn't follow pattern
	            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid sprint names");
	        }
	
	final Sprint startSprintDetail = sprintRepository.findByName(startSprintValue);
	final Sprint endSprintDetail = sprintRepository.findByName(endSprintValue);

	final long startSprintInMills=startSprintDetail.getStartTimeInMillis();
	final long endSprintInMills=endSprintDetail.getEndTimeInMillis();
	final List<Sprint> sprintInRange = sprintRepository.findBetweenTime(endSprintInMills,
		startSprintInMills,
		new PageRequest(0, Integer.MAX_VALUE, new Sort(Direction.ASC, START_DATE)));
	List<Group> groupList = getGroupsBetweenStatusTimeFilteredBySprint(startSprintInMills,
		endSprintInMills, DELIVERED, getOnlySprintName(sprintInRange));

	return aggregateGroupsPerWeekWithStream(groupList, sprintInRange);
    }
    
    private boolean matchPattern(final String s, final String pattern) {
        try {
            final Pattern patt = Pattern.compile(pattern);
            final Matcher matcher = patt.matcher(s);
            return matcher.matches();
        } catch (final RuntimeException e) {
            logger.debug("Pattern {} didn't match {}", pattern, s);
            return false;
        }
    }

    /**
     * Obtains Group, Artifact and Testware count on a daily basis for the days
     * in the given range.
     *
     * @param startTime
     * @param endTime
     * @param status
     * @param sprintNameList
     * @return Group, Artifact and Testware count per day list
     */

    public List<Group> getGroupsBetweenStatusTimeFilteredBySprint(final long startTime, final long endTime,
	    final String status, final Object... sprintNameList) {
	long beginingTime = startOfDay(new DateTime(startTime));
	long endingTime = endOfDay(new DateTime(endTime));
	logger.debug("Find profile activities from:{} ,to:{}", beginingTime, endingTime);
	if (beginingTime == 0 || endingTime == 0) {
	    endingTime = getCurrentSprint().getEndTimeInMillis();
	    beginingTime = getCurrentSprint().getStartTimeInMillis();
	}

	final List<Group> groupArtifactTestwareCount = groupRepository.findGroupsBetweenStatusTimeFilteredBySprintName(
		status.trim().toUpperCase(), beginingTime, endingTime, product, sprintNameList);
	logger.debug("Range Group Artifact and Testware Details {}", groupArtifactTestwareCount);
	return groupArtifactTestwareCount;
    }

    private Object[] getOnlySprintName(final List<Sprint> sprints) {
	// Mapping Sprint names as object from "Sprint" objects
	logger.debug("Sprint included in range: {}", sprints);
	return sprints.stream().map(new Function<Sprint, String>() {
	    @Override
	    public String apply(final Sprint t) {
		return t.getName();
	    }
	}).collect(Collectors.toList()).toArray();
    }

    private Map<String, Object> generateQueueTrendMapfromGroups(final List<Group> groups) {
	final Map<String, Object> map = new HashMap<String, Object>();
	final List<Map<String, String>> artifactMaps = new ArrayList<>();
	final List<Map<String, String>> groupMaps = new ArrayList<>();
	final Map<String, Object> artifactMap = new HashMap<String, Object>();
	final Map<String, Object> groupMap = new HashMap<String, Object>();
	final List<Map<String, Object>> uiDataMap = new ArrayList<>();
	for (final Group group : groups) {
	    artifactMaps.add(getFieldAsTimeMap(group.getStatusTime(), group.getArtifactsInQueue()));
	    groupMaps.add(getFieldAsTimeMap(group.getStatusTime(), group.getQueueLength()));
	}
	map.put(INFO, VALID);
	groupMap.put(LABEL, GROUPS);
	groupMap.put(DATA, groupMaps);
	artifactMap.put(LABEL, ARTIFACTS);
	artifactMap.put(DATA, artifactMaps);
	uiDataMap.add(groupMap);
	uiDataMap.add(artifactMap);
	map.put(DATA, uiDataMap);
	return map;
    }

    private boolean validDataCountForTrends(final long startTime, final long endTime) {
	final long dataCount = groupRepository.countByProductBetweenStatusTime(startTime, endTime, product);
	final boolean inLimit = dataCount <= esDataLimit;
	logger.debug(" validDataCountForTrends, Data Count:{}, limit:{}, inLimit:{}", dataCount, esDataLimit, inLimit);
	return inLimit;
    }

    private boolean validDataCountForDeliveryTrends(final long startTime, final long endTime) {
	// +1 is given to include the finishing start day in duration
	final int dataCount = Days.daysBetween(new DateTime(startTime), new DateTime(endTime)).getDays() + 1;
	final boolean inLimit = dataCount <= esDataLimit;
	logger.debug("validDataCountForDeliveryTrends, Data Count:{}, limit: {}, inLimit:{}", dataCount, esDataLimit,
		inLimit);
	return inLimit;
    }

    private Map<String, String> getFieldAsTimeMap(final String time, final int value) {
	final long dateTime = new DateTime(time).getMillis();
	final Map<String, String> map = new HashMap<>();
	map.put(TIME, String.valueOf(dateTime));
	map.put(VALUE, String.valueOf(value));
	return map;
    }

    private Map<String, Object> getAverageQueueDetailsforYesterday() {
	final DateTime today = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay();
	final long endOfYesterday = today.minusMillis(1).getMillis();
	final long startOfYesterday = today.minusDays(1).getMillis();
	return getAverageQueueDetails(startOfYesterday, endOfYesterday);
    }

    private Map<String, Object> getAverageQueueDetailsforToday() {
	final DateTime today = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay();
	final long startOfToday = today.getMillis();
	final long endOfToday = today.plusDays(1).minusMillis(1).getMillis();
	return getAverageQueueDetails(startOfToday, endOfToday);
    }

    private Map<String, Object> getAverageQueueDetails(final long startTime, final long endTime) {
	final Sprint sprint = getCurrentSprint();
	final Map<String, Object> map = new HashMap<String, Object>();
	map.putAll(groupRepository.findAvgQueueDetails(sprint.getName(), startTime, endTime, QUEUE_AVG, QUEUE_LENGTH));
	map.putAll(groupRepository.findAvgQueueDetails(sprint.getName(), startTime, endTime, ARTIFACT_AVG,
		ARTIFACTS_IN_QUEUE));
	logger.debug("Service retrieving Average Queue Details:{}", map);
	return map;
    }

    private Group getLatestQueueDetails(final int limit) throws MetricsServiceException {
	final List<Group> groups = groupRepository.findLatestQueueDetails(limit, getCurrentSprint().getName());
	if (groups.isEmpty()) {
	    Group group = new Group();
	    group.setQueueLength(0);
	    group.setArtifactsInQueue(0);
	    return group;
	}
	return groups.get(0);
    }

    private Sprint getCurrentSprint() {
	return sprintRepository.findFirstByDateTime(serverDateTime.getCurrentDateTime().getMillis());
    }

    private long startOfDay(final DateTime date) {
	return date.withTimeAtStartOfDay().withZoneRetainFields(DateTimeZone.UTC).getMillis();
    }

    private long endOfDay(final DateTime date) {
	return date.plusDays(1).withTimeAtStartOfDay().withZoneRetainFields(DateTimeZone.UTC).minusMillis(1)
		.getMillis();
    }

    private String parseDate(final long timeInmillis) {
	// TODO : investigate about time issue with jenkins, it we found right
	// solution remove this approach
	final long dateTime = new DateTime(timeInmillis, DateTimeZone.UTC).withTimeAtStartOfDay().getMillis();
	final DateTimeFormatter dtf = DateTimeFormat.forPattern(PATTERN_DATEFORMAT);
	return dtf.print(dateTime);
    }

    


    private List<Map<String, Object>> aggregateGroupsPerWeekWithStream(final List<Group> groups,
	    final List<Sprint> sprintInRange) {
	final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
	final Map<String, List<Group>> dropGroups = groups.stream().collect(Collectors.groupingBy(Group::getDrop));
	for (final Sprint sprint : sprintInRange) {
	    final List<Group> sprintGroups = dropGroups.get(sprint.getName());
	    if (sprintGroups != null && sprintGroups.size() > 0) {
		final long week3StartDate = sprint.getStartDateTime().plusWeeks(2).withTime(00, 00, 00, 000)
			.getMillis();
		final long week2StartDate = sprint.getStartDateTime().plusWeeks(1).withTime(00, 00, 00, 000)
			.getMillis();
		final List<Group> week1MainStream = sprintGroups.stream()
			.filter(g -> ((new DateTime(g.getStatusTime(), DateTimeZone.UTC)
				.isAfter(sprint.getStartTimeInMillis())
			|| new DateTime(g.getStatusTime(), DateTimeZone.UTC).isEqual(sprint.getStartTimeInMillis()))
			&& new DateTime(g.getStatusTime(), DateTimeZone.UTC).isBefore(week2StartDate)))
			.collect(Collectors.toList());

		final List<Group> week2MainStream = sprintGroups.stream()
			.filter(g -> ((new DateTime(g.getStatusTime(), DateTimeZone.UTC).isAfter(week2StartDate)
				|| new DateTime(g.getStatusTime(), DateTimeZone.UTC).isEqual(week2StartDate))
				&& new DateTime(g.getStatusTime(), DateTimeZone.UTC).isBefore(week3StartDate)))
			.collect(Collectors.toList());

		final List<Group> week3MainStream = sprintGroups.stream()
			.filter(g -> ((new DateTime(g.getStatusTime(), DateTimeZone.UTC).isAfter(week3StartDate)
				|| new DateTime(g.getStatusTime(), DateTimeZone.UTC).isEqual(week3StartDate))
				&& (new DateTime(g.getStatusTime(), DateTimeZone.UTC)
					.isBefore(sprint.getEndTimeInMillis())
					|| new DateTime(g.getStatusTime(), DateTimeZone.UTC)
						.isEqual(sprint.getEndTimeInMillis()))))
			.collect(Collectors.toList());
		final Map<String, Object> map = new HashMap<String, Object>();
		map.put(SPRINT_KEY, sprint.getName());
	
		map.putAll(populateField(week1MainStream,"1"));
		map.putAll(populateField(week2MainStream,"2"));
		map.putAll(populateField(week3MainStream,"3"));
		
		map.putAll(populateDate(sprint, week2StartDate, week3StartDate));
		maps.add(map);
	    }
	}
	return maps;
    }

    private Map<String, Object> populateDate(final Sprint sprint, long week2StartLong, final long week3StartLong) {
	final DateTime week2Start = new DateTime(week2StartLong);
	final DateTime week3Start = new DateTime(week3StartLong);
	Map<String, Object> mapToSet = new HashMap<String, Object>();
	mapToSet.put(WEEK_FROM.replace("?", "1"), sprint.getStartDateTime().toString(PATTERN_DATEFORMAT));
	mapToSet.put(WEEK_FROM.replace("?", "2"), week2Start.toString(PATTERN_DATEFORMAT));
	mapToSet.put(WEEK_FROM.replace("?", "3"), week3Start.toString(PATTERN_DATEFORMAT));
	mapToSet.put(WEEK_TO.replace("?", "1"), week2Start.plusDays(-1).toString(PATTERN_DATEFORMAT));
	mapToSet.put(WEEK_TO.replace("?", "2"), week3Start.plusDays(-1).toString(PATTERN_DATEFORMAT));
	mapToSet.put(WEEK_TO.replace("?", "3"), sprint.getEndDateTime().toString(PATTERN_DATEFORMAT));
	return mapToSet;

    }

    private Map<String, Object> populateField(final List<Group> groups, final String week) {

	Map<String, Object> mapToSet = new HashMap<String, Object>();
	mapToSet.put(ARTIFACT_WEEK_KEY + week, groups.stream().mapToInt(Group::getArtifactsInGroup).sum());
	mapToSet.put(TESTWARE_WEEK_KEY + week, groups.stream().mapToInt(Group::getTestwareInGroup).sum());
	mapToSet.put(GROUPS_WEEK_KEY + week, groups.stream().collect(Collectors.counting()));
	return mapToSet;

    }

}
