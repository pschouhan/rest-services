/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.jira;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.sprint.Sprint;
import com.ericsson.cifwk.metrics.sprint.SprintRepository;

@Service
public class JiraService {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String TOTAL = "total";
    private static final String COMPLETED = "completed";

    @Autowired
    private ServerDateTime serverDateTime;

    @Autowired
    private JiraRepository jiraRepository;

    @Autowired
    private SprintRepository sprintRepository;

    /**
     * Obtains Total of committed story points in the sprint and the quantity of
     * story points currently done (total of burned SP).
     *
     * @return Map <total> key for total of committed SP, <completed> key for
     *         currently burned SP
     */
    public Map<String, String> getTotalAndCompletedVelocityForSprint(final String sprintName) {
        logger.debug("Sprint name: {}", sprintName);
        Sprint sprint = null;
        if (StringUtils.trimToNull(sprintName) != null) {
            sprint = sprintRepository.findByName(sprintName);
        }
        if (sprint == null) {
            sprint = getCurrentSprint();
        }
        final double completed = jiraRepository.findSprintBurnDown(sprint.getName());
        final double total = jiraRepository.findSprintCommitment(sprint.getName());
        logger.debug("Sprint :{} , total commitment :{} & completed velocity :{}",
                sprint.getName(), total, completed);
        return new HashMap<String, String>() {
            private static final long serialVersionUID = 1L;
            {
                put(TOTAL, String.valueOf(total));
                put(COMPLETED, String.valueOf(completed));
            }
        };
    }

    private Sprint getCurrentSprint() {
        return sprintRepository.findFirstByDateTime(serverDateTime.getCurrentDateTime().getMillis());
    }
}
