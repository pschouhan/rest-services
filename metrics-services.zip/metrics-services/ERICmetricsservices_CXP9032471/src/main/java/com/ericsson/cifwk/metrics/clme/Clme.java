/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.clme;

import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * CLME entity.
 */
public class Clme implements Comparable<Clme> {

    public enum KgbStatus {
        PASSED, FAILED, NOT_STARTED;
    }

    public enum MessageType {
        DEL, OBS, COM, KGB, CDB
    }

    private String masterVersion;
    private String result;
    private String groupId;
    private String artifactId;
    private String version;
    private boolean completedEvent;
    private String eventTime;
    private int nodes;
    private String teAllureLogUrl;
    private String drop;
    private String finishedLevel;
    private String startedLevel;
    private boolean durationKnown;
    private long duration;
    private String finishedEventTime;
    private KgbStatus kgbStatus = KgbStatus.NOT_STARTED;
    private MessageType messageType;

    public MessageType getMessageType() {
        return messageType;
    }

    public void setMessageType(final MessageType messageType) {
        this.messageType = messageType;
    }

    public String getFinishedEventTime() {
        return finishedEventTime;
    }

    public void setFinishedEventTime(final String finishedEventTime) {
        this.finishedEventTime = finishedEventTime;
    }

    public String getFinishedLevel() {
        return finishedLevel;
    }

    public String getStartedLevel() {
        return startedLevel;
    }

    public boolean isDurationKnown() {
        return durationKnown;
    }

    public KgbStatus getKgbStatus() {
        return kgbStatus;
    }

    public void setKgbStatus(final KgbStatus kgbStatus) {
        this.kgbStatus = kgbStatus;
    }

    public long getDuration() {
        return duration;
    }

    public void setFinishedLevel(final String finishedLevel) {
        this.finishedLevel = finishedLevel;
    }

    public void setStartedLevel(final String startedLevel) {
        this.startedLevel = startedLevel;
    }

    public void setDurationKnown(final boolean durationKnown) {
        this.durationKnown = durationKnown;
    }

    public void setDuration(final long duration) {
        this.duration = duration;
    }

    public int getNodes() {
        return nodes;
    }

    public void setNodes(final int nodes) {
        this.nodes = nodes;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(final String eventTime) {
        this.eventTime = eventTime;
    }

    public String getMasterVersion() {
        return masterVersion;
    }

    public void setMasterVersion(final String masterVersion) {
        this.masterVersion = masterVersion;
    }

    public String getResult() {
        return result;
    }

    public void setResult(final String result) {
        this.result = result;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(final String groupId) {
        this.groupId = groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(final String version) {
        this.version = version;
    }

    public boolean isCompletedEvent() {
        return completedEvent;
    }

    public void setCompletedEvent(final boolean completedEvent) {
        this.completedEvent = completedEvent;
    }

    public String getDrop() {
        return drop;
    }

    public void setDrop(final String drop) {
        this.drop = drop;
    }

    public String getTeAllureLogUrl() {
        return teAllureLogUrl;
    }

    public void setTeAllureLogUrl(final String teAllureLogUrl) {
        this.teAllureLogUrl = teAllureLogUrl;
    }

    @Override
    public int compareTo(final Clme mteVO) {
        if ("".equals(StringUtils.trimToEmpty(getVersion().trim()))) {
            return 1;
        }
        if ("".equals(StringUtils.trimToEmpty(mteVO.getVersion().trim()))) {
            return -1;
        }
        if (getVersion().equals(mteVO.getVersion())) {
            return 0;
        } else {
            final String[] mteArray1 = getVersion().split("\\.");
            final String[] mteArray2 = mteVO.getVersion().split("\\.");
            if (mteArray1.length > mteArray2.length) {
                return compareValues(mteArray1, mteArray2);
            } else {
                return compareValues(mteArray2, mteArray1);
            }
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(masterVersion, artifactId, version, groupId);
    }

    @Override
    public boolean equals(final Object obj) {
        final Clme other = (Clme) obj;
        return masterVersion.equals(other.getMasterVersion()) && artifactId.equals(other.getArtifactId())
                && version.equals(other.getVersion()) && groupId.equals(other.getGroupId());
    }

    private Integer compareValues(final String[] array1, final String[] array2) {
        for (int i = 0; i < array1.length; i++) {
            final Integer v1 = Integer.parseInt(array1[i]);
            final Integer v2 = Integer.parseInt(array2[i]);
            if (v1 != v2) {
                return v1 - v2;
            }
        }
        return 0;
    }

    @JsonIgnore
    public long getEventTimeInMillis() {
        final DateTime dateTime = new DateTime(eventTime, DateTimeZone.UTC);
        return dateTime.getMillis();
    }

    @JsonIgnore
    public long getFinishedEventTimeInMillis() {
        final DateTime dateTime = new DateTime(finishedEventTime, DateTimeZone.UTC);
        return dateTime.getMillis();
    }

}
