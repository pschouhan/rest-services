/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.multiclme;

import java.util.List;
import java.util.Map;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.FilteredQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;



@Repository
public class MultiClmeRepositoryImpl implements MultiClmeRepository{

    private static final String DROP = "drop";
    private static final String EVENT_TIME = "eventTime";
    private static final String SUCCESS = "SUCCESS";
    private static final String DEPLOY_ENM_UG = "deploy_enm_ug_status";
    private static final String DEPLOY_ENM_II = "deploy_enm_ii_status";
    private static final String DEPLOY_MICRO_ENM_II = "deploy_micro_enm_ii_status";
    private static final String WORKINGBASELINE = "workingBaseline";
    private static final String DROP_REGEX = "[0-9]+(\\.[0-9]+)";
    private static final String FAILURE = "FAILURE";
    //private static final String TEST_LOOP = "testLoop";
    private static final String RESULT = "result";
    //private static final String UG_STATUS = "ug_status";



    @Value("${es.index}")
    private String index;

    @Value("${es.index.type.multiclme}")
    private String type;

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    private MultiClmeExtractors extractors;

    @Override
    public List<MultiClme> findMTEDetails(final long from, final long to, final Object... drops) {
        final BoolQueryBuilder mteboolQuery = QueryBuilders
                .boolQuery()
                .must(QueryBuilders.termsQuery(DROP, drops));

        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(mteboolQuery)
                .withFilter(FilterBuilders.rangeFilter(EVENT_TIME).from(from).to(to))
            .withFilter(FilterBuilders.existsFilter(DEPLOY_ENM_UG)).withPageable(new PageRequest(0, Integer.MAX_VALUE))
            .withSort(SortBuilders.fieldSort(EVENT_TIME).order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, MultiClme.class);
    }
    
    @Override
    public List<MultiClme> findMaintrackPhysicalKGB(final long startTime, final long endTime, final Object... drops) {
        final FilteredQueryBuilder mteboolQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
            FilterBuilders.andFilter(FilterBuilders.termsFilter(DROP, drops),
                FilterBuilders.rangeFilter(EVENT_TIME).from(startTime).to(endTime),
                FilterBuilders.termFilter(WORKINGBASELINE, SUCCESS)));


        final SearchQuery query = new NativeSearchQueryBuilder()
            .withIndices(index)
            .withTypes("multiclme")
            .withQuery(mteboolQuery)
            .withPageable(new PageRequest(0, Integer.MAX_VALUE))
            .withSort(SortBuilders.fieldSort(EVENT_TIME).order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query,  MultiClme.class);
    }
    
    @Override
    public List<MultiClme> findUGStatusDetails(final long startTime, final long endTime, final Object... drops) {
        final FilteredQueryBuilder mteboolQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
            FilterBuilders.andFilter(FilterBuilders.termsFilter(DROP, drops),
                FilterBuilders.rangeFilter(EVENT_TIME).from(startTime).to(endTime),
                FilterBuilders.termFilter(DEPLOY_ENM_UG, SUCCESS)));


        final SearchQuery query = new NativeSearchQueryBuilder()
            .withIndices(index)
            .withTypes("multiclme")
            .withQuery(mteboolQuery)
            .withPageable(new PageRequest(0, Integer.MAX_VALUE))
            .withSort(SortBuilders.fieldSort(EVENT_TIME).order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query,  MultiClme.class);
    }

    @Override
    public List<MultiClme> findMaintrackPhysicalIIKGB(final long startTime, final long endTime, final Object... drops) {
        final FilteredQueryBuilder mteboolQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), 
        	FilterBuilders.andFilter(FilterBuilders.termsFilter(DROP, drops),
                FilterBuilders.rangeFilter(EVENT_TIME).from(startTime).to(endTime),
                FilterBuilders.termFilter(DEPLOY_ENM_II, SUCCESS)));


        final SearchQuery query = new NativeSearchQueryBuilder()
            .withIndices(index)
            .withTypes("multiclme")
            .withQuery(mteboolQuery)
            .withPageable(new PageRequest(0, Integer.MAX_VALUE))
            .withSort(SortBuilders.fieldSort(EVENT_TIME).order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query,  MultiClme.class);
    }

    @Override
    public List<MultiClme> findMaintrackMicroENMII(final long startTime, final long endTime, final Object... drops) {
        final FilteredQueryBuilder mteboolQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), 
        	FilterBuilders.andFilter(FilterBuilders.termsFilter(DROP, drops),
                FilterBuilders.rangeFilter(EVENT_TIME).from(startTime).to(endTime),
                FilterBuilders.termFilter(DEPLOY_MICRO_ENM_II, SUCCESS)));


        final SearchQuery query = new NativeSearchQueryBuilder()
            .withIndices(index)
            .withTypes("multiclme")
            .withQuery(mteboolQuery)
            .withPageable(new PageRequest(0, Integer.MAX_VALUE))
            .withSort(SortBuilders.fieldSort(EVENT_TIME).order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query,  MultiClme.class);
    }

    @Override
    public List<Map<String, Object>> findMTEPhysicalTrendInDrops(String testLoop, final Object... drops) {
        final FilteredQueryBuilder filterQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.regexpFilter(DROP, DROP_REGEX),
                        FilterBuilders.termsFilter(testLoop, SUCCESS, FAILURE),
                        FilterBuilders.termsFilter(DROP, drops)));
        final AggregationBuilder<?> aggregationBuilder = AggregationBuilders.terms(DROP).field(DROP)
                // minDoc count is added to get values for all different kinds of results ,
                // if no data is found for particular result ,this function will automatically put 0 for that
                .subAggregation(AggregationBuilders.terms(RESULT).field(testLoop).minDocCount(0));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(filterQuery)
                .addAggregation(aggregationBuilder)
                .build();

        return elasticsearchTemplate.query(query, extractors.getMteTrendAggregation());

    }
}
