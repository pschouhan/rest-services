
package com.ericsson.cifwk.metrics.group;

import java.util.List;
import java.util.Map;

import com.ericsson.cifwk.metrics.sprint.Sprint;

public interface GroupRepository {

    List<Map<String, Object>> findGroupArtifactAndTestwareCountOnDaily(final String status, final Sprint sprint);

    List<Map<String, Object>> findGroupArtifactAndTestwareCountOnDailyBetweenStatusTime(final String status,
	    final long startTime, final long endTime);

    List<Map<String, Object>> findTeamsContributedInDropByStatus(final String status, final String drop,
	    final long startTime, final long endTime);

    Map<String, Double> findAvgQueueDetails(final String drop, final long startOfDay, final long endOfDay,
	    final String key, final String field);

    List<Group> findLatestQueueDetails(final int limit, final String drop);

    List<Group> findByProductBetweenStatusTime(final long startTime, final long endTime, final String product,
	    final int limit);
    
    List<Group> findWaitingQueueDetails(final String drop);

    long countByProductBetweenStatusTime(final long startTime, final long endTime, final String product);

    Map<String, Integer> findTotalGroupArtifactAndTestwareBetweenDateTimeByStatus(final long startTime,
	    final long endTime, final String status);

    public List<Group> findGroupsBetweenStatusTimeFilteredBySprintName(final String status, final long startTime,
	    final long endTime, final String product, final Object... sprintNameList);
    
   public List<Map<String, Object>> findTestwareGroupCountOnDailyBetweenStatusTime(final String status,
            final long startTime, final long endTime);
   
   public List<Map<String, Object>> findTestwareGroupCountOnDaily(
           final String status, final Sprint sprint);
}
