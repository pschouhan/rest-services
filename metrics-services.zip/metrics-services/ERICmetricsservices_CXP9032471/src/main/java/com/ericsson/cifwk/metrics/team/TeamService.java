/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2016
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.team;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class TeamService {
	private static final String TEAMS = "teams";
	private static final String TRIBE = "parentElement";
	@Value("${team.file}")
	private String teamFile;
	@Autowired
	private TeamRepository teamRepository;

	private boolean flag = false;

	public List<Map<String, Object>> getTeamGroupByTribe() {
		final Iterable<Team> teamIterator = teamRepository.findAll();
		// Tree Map is used to sort Tribe based on alphabetical order
		final Map<String, List<Team>> tribeTeams =
				StreamSupport.stream(teamIterator.spliterator(), false).collect(
						Collectors.groupingBy(Team::getParentElement, TreeMap::new, Collectors.toList()));
		return tribeTeams.entrySet().stream().map(e -> convertToTribeMap(e.getKey(), e.getValue())).collect(Collectors.toList());
	}

	private Map<String, Object> convertToTribeMap(final String key, final List<Team> value) {
		// Sort team list in ascending order of team name
		final List<String> teams = value.stream().map(e -> e.getTeam()).sorted().collect(Collectors.toList());
		final Map<String, Object> tribeMap = new HashMap<>();
		tribeMap.put(TRIBE, key);
		tribeMap.put(TEAMS, teams);
		return tribeMap;
	}


	public List<Map<String, Object>> getTeamFilterGroupByTribe() {
		final Iterable<Team> teamIterator = teamRepository.findAll();
		// Tree Map is used to sort Tribe based on alphabetical order

		final List<Team> allTeamList =new ArrayList<Team> ();

		Team allTeam = new Team();
		allTeam.setTeam("All RA");
		allTeam.setTeam("All Teams");

		allTeamList.add(allTeam);

		final Map<String, List<Team>> tribeTeams = new HashMap<String, List<Team>>();
		tribeTeams.put("All RA", allTeamList);
		readTeamsFromFile(tribeTeams);
		tribeTeams.putAll(StreamSupport.stream(teamIterator.spliterator(), false).collect(
			Collectors.groupingBy(Team::getParentElement, TreeMap::new, Collectors.toList())));
		return tribeTeams.entrySet().stream().map(e -> convertToTribeFilterMap(e.getKey(), e.getValue())).collect(Collectors.toList());
	}

	private void readTeamsFromFile(Map<String, List<Team>> tribeTeams) {
		String line;
		String cvsSplitBy = ",";
		File f = new File(teamFile);
		if(f.exists() && !f.isDirectory()) {
			try (BufferedReader br = new BufferedReader(new FileReader(teamFile))) {

				while ((line = br.readLine()) != null) {
					final List<Team> teamList = new ArrayList<Team>();
					String[] team = line.split(cvsSplitBy);
					for (int i = 1; i < team.length; i++) {
						Team t = new Team();
						t.setTeam(team[i]);
						teamList.add(t);
					}
					tribeTeams.put(team[0], teamList);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private Map<String, Object> convertToTribeFilterMap(final String key, final List<Team> value) {
		// Sort team list in ascending order of team name

		final Map<String, Object> tribeMap = new HashMap<>();

		if(key.equalsIgnoreCase("All RA")){

			List<String> teams = value.stream().map(e -> e.getTeam()).sorted().collect(Collectors.toList());
			tribeMap.put(TRIBE, key);
			tribeMap.put(TEAMS, teams);

		}else{

			List<String> teams = new ArrayList<>(Arrays.asList("All Teams"));
			teams.addAll(value.stream().map(e -> e.getTeam()).sorted().collect(Collectors.toList()));
			tribeMap.put(TRIBE, key);
			tribeMap.put(TEAMS, teams);

		}

		return tribeMap;
	}
}
