/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.sprint;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldIndex;
import org.springframework.data.elasticsearch.annotations.FieldType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Document(indexName = "sprints", type = "sprint")
public class Sprint {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static final String WEEK = "Wk";
    // @ID Annotation is required otherwise spring doesn't allow to create Entity , Try to match name as @Id but but when inserted to db it is
    // overwritten by some alphanumeric hash code. need to investigate on this
    @Id
    @JsonIgnore
    private String id;

    @Field(type = FieldType.String, index = FieldIndex.not_analyzed)
    private String name;

    @Field(type = FieldType.Date, format = DateFormat.date_optional_time)
    private String startDate;

    @Field(type = FieldType.Date, format = DateFormat.date_optional_time)
    private String endDate;

    @Field(type = FieldType.String, index = FieldIndex.not_analyzed)
    private String release;
    
    @Field(type = FieldType.Double)
    private double committedPoints;
    
    @Field(type = FieldType.Double)
    private double completedPoints;

    public String getName() {
        return name;
    }
    
    public void setName(final String name) {
        this.name = name.trim();
    }

    public String getStartDate() {
        return startDate;
    }
    
    public void setStartDate(final String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }
    
    public void setEndDate(final String endDate) {
        this.endDate = endDate;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(final String release) {
        this.release = release.trim();
    }
    
	public double getCommittedPoints() {
		return committedPoints;
	}

	public void setCommittedPoints(final double committedPoints) {
		this.committedPoints = committedPoints;
	}
	
	public double getCompletedPoints() {
		return completedPoints;
	}

	public void setCompletedPoints(final double completedPoints) {
		this.completedPoints = completedPoints;
	}

	public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    /**
     * Method convert the given date to week day based on sprint
     *
     * @param date
     * @return String ,if first day of a first week <code>Wk.1.1</code>
     */
    @JsonIgnore
    public String getFormattedWeekDay(final DateTime date) {
        if (date == null) {
            throw new IllegalArgumentException("Given Date is null");
        }
        if (!date.isBefore(getStartDateTime()) && !date.isAfter(getEndDateTime())) {
            // +1 is given to include the finishing start day in duration
            final int sprintDay = Days.daysBetween(getStartDateTime(), date).getDays() + 1;
            final int week = (int) Math.ceil((float) sprintDay / 7);
            final int day = sprintDay - (week - 1) * 7;
            final String weekDay = WEEK + week + "." + day;
            return weekDay;
        }
        else
        {
            throw new IllegalArgumentException("Given Date is not inside the Sprint period");
        }
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (name == null ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Sprint other = (Sprint) obj;
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        return true;
    }

    /**
     * Convert startTime of a sprint to milliseconds
     *
     * @return timeinMillis
     */
    @JsonIgnore
    public long getStartTimeInMillis() {
        return getStartDateTime().getMillis();
    }

    public DateTime getStartDateTime() {
        return new DateTime(startDate, DateTimeZone.UTC);
    }

    /**
     * Convert endTime of a sprint to milliseconds
     *
     * @return timeinMillis
     */
    @JsonIgnore
    public long getEndTimeInMillis() {
        return getEndDateTime().getMillis();
    }

    public DateTime getEndDateTime() {
        return new DateTime(endDate, DateTimeZone.UTC);
    }

    @Override
    public String toString() {

        return "Sprint [name=" + name + ", startDate=" + startDate
                + ", endDate=" + endDate + ", release=" + release + "]";
    }

    /**
     * this method validate all the sprint properties , checking null ,empty string and date formats
     *
     * @return boolean <code>true</code> if it is a valid sprint. <code>false</code> otherwise.
     */
    @JsonIgnore
    public boolean isValidSprint() {
        if (name == null || name.trim().isEmpty()) {
            return false;
        } else if (startDate == null || startDate.isEmpty()) {
            return false;
        } else if (!isValidFormat(startDate)) {
            return false;
        } else if (endDate == null || startDate.isEmpty()) {
            return false;
        } else if (!isValidFormat(endDate)) {
            return false;
        } else if (release == null || release.isEmpty()) {
            return false;
        }

        return true;
    }

    /**
     * Validate the date formats for startDate and endDate
     *
     * @param value
     * @return
     */
    private boolean isValidFormat(final String value) {
        final DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'");
        try {
            fmt.parseDateTime(value);
        } catch (final Exception e) {
            logger.info("The date string doesn't match with required date format yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\' " + e.getMessage());
            return false;
        }
        return true;

    }

}
