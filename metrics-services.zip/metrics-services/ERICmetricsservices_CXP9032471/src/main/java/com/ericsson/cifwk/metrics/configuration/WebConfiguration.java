/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2015
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.configuration;

import static springfox.documentation.builders.PathSelectors.regex;

import static com.google.common.base.Predicates.or;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import com.google.common.base.Predicate;

@Configuration
public class WebConfiguration extends WebMvcConfigurationSupport {

    @Value("${mv.project.version}")
    private String version;

    @Override
    @Bean
    public RequestMappingHandlerMapping requestMappingHandlerMapping() {
        final RequestMappingHandlerMapping mapping = new RequestMappingHandlerMapping();
        mapping.setRemoveSemicolonContent(false);
        return mapping;
    }

    @Bean
    public Docket metricsServicesApi() {

        return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).select().paths(endPointPaths()).build();
    }

    @SuppressWarnings("unchecked")
    private Predicate<String> endPointPaths() {

        return or(
                // Clme
                regex("/delivery-today*"), regex("/delivery-sprint-status*"), regex("/isoRadiator-details*"),
                regex("/mtetable-details*"), regex("/kgb-physical*"), regex("/kgb-cloud*"), regex("/rvb-current*"),
                regex("/rvb-baseline*"), regex("/physical-ii-kgb*"), regex("/isoMtRadiator-details*"),
                regex("/mtep-sprint-trend*"), regex("/release-flow*"), regex("/iso-versions"),
                regex("/team-profile*"), 
                // MultiClme
                regex("/Maintrack-Radiator"),
                // Sprint
                regex("/sprint-current-details*"), regex("/sprint-details*"), regex("/sprint-names*"),
                regex("/sprint-range-details*"), regex("/sprint/.*"), regex("/sprint"),
                // Scm
                regex("/team-performance*"), regex("/commit-details*"),
                // Portal Drop
                regex("/current-maintrack-status.*"),
                // Jira
                regex("/sprint-velocity*"),
                // Group
                regex("/deliveries-trends*"), regex("/deliveries-trends-range*"), regex("/deliveries-teams*"),
                regex("/current-queue-activity*"), regex("/delivery-queue-trends*"), regex("/group-counts*"),
                regex("/queue-profile-deliveries"),regex("/current-waiting-queue*"),
                // Team
                regex("/teams*"));

    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("Metrics Service REST API")
                .description("If you need any assistance please contact a member of the Metrics & Visualisation team.")
                .version(version).build();
    }

    @Override
    protected void configureDefaultServletHandling(final DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }
}
