
package com.ericsson.cifwk.metrics.clme;

import java.util.List;
import java.util.Map;

public interface ClmeRepository {

    Integer findDeliveriesForTodayByDropAndProduct(final long from,
            final long to, final String drop, final String product);

    List<Clme> findMTEDetails(final long from, final long to, final Object... drops);


    List<Clme> findRFAList(final String groupId, final String artifactId,
            final String version);

    List<Clme> findMaintrackCurrentRVB(final Object... drops);

    List<Clme> findMaintrackBaselineRVB(final Object... drops);

    List<Clme> findMaintrackCloudKGB(final long startTime, final long endTime);
    
    List<Clme> findMaintrackMicroENM(final long startTime, final long endTime);

    List<Clme> findCautionDetails(final String masterVersion);

    List<Clme> findPhysicalIIKGB(final long startTime, final long endTime);

    List<Clme> findCautionDetailsForProductSet(final String productSet);

    List<Map<String, Object>> findDeliveryBetweenDaysByDropAndProduct(
            final long from, final long to, final String drop,
            final String product);

    List<Map<String, Object>> findMTEPhysicalTrendInDrops(final Object... drops);

    List<Clme> findTestTimeLoopDetailsByField(final String field, final Object... values);

    List<String> findIsoVersionsByDrop(final String drop);

    List<Clme> findTeamProfile(final String teamName, final long startTime, final long endTime, final String[] profileMessageTypes);

    List<String> findIsoVersionsBetweenEventTime(final long fromTime, final long endTime);

    List<Clme> findDetailsByKeyValueOrderByEventTime(final String field, final String value);

}
