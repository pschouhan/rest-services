/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.sprint;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
@Api(value = "/sprint", description = "Gets Sprint Information as sprint-details and sprint-names")
public class SprintEndPoint {

    @Autowired
    private SprintService service;

    @ApiOperation(value = "Gets current sprint-details information")
    @RequestMapping(value = "/sprint-current-details", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, String> getCurrentSprintDetails() {
        return service.getCurrentSprintDetails();
    }
    
    @ApiOperation(value = "Gets sprint-details information")
    @RequestMapping(value = "/sprint-details", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Sprint getSprintDetails(@RequestParam(required = false, value = "sprint") final String sprint) {
        return service.getSprintDetails(sprint);
    }

    @ApiOperation(value = "Gets sprint-names information till current date")
    @RequestMapping(value = "/sprint-names", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Sprint> getSprintDetailsTillToday() {
        return service.getSprintDetailsTillToday();
    }
    
    @ApiOperation(value = "Gets sprint details information by range")
    @RequestMapping(value = "/sprint-range-details", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Sprint> getSprintDetailsBySprintRange(@RequestParam(required = false, value = "from") final String from,
            @RequestParam(required = false, value = "to") final String to) {
        return service.getSprintDetailsBySprintRange(from, to);
    }

    @ApiOperation(value = "Creating a Sprint ,Date Fortmat : yyyy-MM-ddT'hh:mm:ss.SSSZ")
    @RequestMapping(value = "/sprint", method = RequestMethod.POST)
    @ResponseStatus(value = HttpStatus.CREATED)
    public @ResponseBody String createSprint(@RequestBody final Sprint sprint) {
        return service.createSprint(sprint);
    }

    @ApiOperation(value = "Updating a Sprint with given name, DateFormat :yyyy-MM-ddT'hh:mm:ss.SSSZ")
    @RequestMapping(value = "/sprint/{name}/", method = RequestMethod.PUT)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody String updateSprint(@PathVariable("name") final String name, @RequestBody final Sprint sprint) {
       return service.updateSprint(name, sprint);
    }

    @ApiOperation(value = "Deleting a Sprint with given name ")
    @RequestMapping(value = "/sprint/{name}/", method = RequestMethod.DELETE)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody String deleteSprint(@PathVariable("name") final String name) {
        return service.deleteSprint(name);
    }

    @ApiOperation(value = "Gets sprint-names information till current date")
    @RequestMapping(value = "/sprints", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody String getAllSprints() {
        return service.getAllSprints();
    }

    @ApiOperation(value = "Gets sprint-names information for a number of sprints till current date")
    @RequestMapping(value = "/sprints-recent", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Sprint> getSprintDetailsForXSprintsTillToday(@RequestParam(required = true, value = "size") final int size) {
        return service.getSprintDetailsForXSprintsTillToday(size);
    }
}
