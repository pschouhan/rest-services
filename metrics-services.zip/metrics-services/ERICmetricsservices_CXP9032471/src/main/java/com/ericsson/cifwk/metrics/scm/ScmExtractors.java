/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.scm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Component;

@Component
public class ScmExtractors {

    private static final String COMMIT = "commit";
    private static final String TEAM = "team";
    private static final String TEAMS = "teams";

    public ResultsExtractor<List<Map<String, String>>> getTeamPerformanceExtractor() {
        return new ResultsExtractor<List<Map<String, String>>>() {
            @Override
            public List<Map<String, String>> extract(final SearchResponse response) {
                final List<Map<String, String>> list = new ArrayList<Map<String, String>>();
                final Aggregations aggregations = response.getAggregations();
                final Terms terms = aggregations.get(TEAMS);
                final Collection<Terms.Bucket> buckets = terms.getBuckets();
                for (final Terms.Bucket bucket : buckets) {
                    final String team = bucket.getKeyAsText().toString();
                    final int commitCount = (int) bucket.getDocCount();
                    final Map<String, String> map = new HashMap<String, String>() {
                        private static final long serialVersionUID = -5475847030292950310L;
                        {
                            put(TEAM, team);
                            put(COMMIT, String.valueOf(commitCount));
                        }
                    };
                    list.add(map);
                }
                return list;
            }
        };
    }

}
