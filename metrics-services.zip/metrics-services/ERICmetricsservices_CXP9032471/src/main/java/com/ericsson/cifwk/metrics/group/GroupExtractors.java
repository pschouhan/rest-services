/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.group;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.WordUtils;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram.Bucket;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Component;

import com.ericsson.cifwk.metrics.sprint.Sprint;

@Component
public class GroupExtractors {

    private static final String TEAM_NAME = "teamName";
    private static final String DATE_TIME = "dateTime";
    private static final String GROUP_COUNT = "groupCount";
    private static final String ARTIFACT_COUNT = "artifactCount";
    private static final String TESTWARE_COUNT = "testwareCount";
    private static final String WEEK_DAY = "weekDay";
    private static final String DAY = "day";
    private static final String TEAMS = "teams";
    private static final String DAILY = "daily";
    private static final String DATE_FORMAT = "dd/MM";
    private static final String GROUP = "Group";
    private static final String TESTWARE_GROUP = "TestwareGroup";

    public ResultsExtractor<List<Map<String, Object>>> dailyStatusExtractor(final Sprint sprint, final String status) {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
                final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final Aggregations aggregations = response.getAggregations();
                final DateHistogram daily = aggregations.get(DAILY);
                @SuppressWarnings("unchecked")
                final List<DateHistogram.Bucket> buckets = (List<DateHistogram.Bucket>) daily
                        .getBuckets();
                buckets.stream().forEach((bucket) -> {
                    final Sum sumArtifact = (Sum) bucket.getAggregations().getAsMap().get(ARTIFACT_COUNT);
                    final Sum sumTestware = (Sum) bucket.getAggregations().getAsMap().get(TESTWARE_COUNT);
                    final Map<String, Object> map = new HashMap<String, Object>();
                    final String dateString = bucket.getKeyAsText().string();
                    final String weekDay = sprint.getFormattedWeekDay(new DateTime(dateString, DateTimeZone.UTC));
                    final int testwareCount = (int) sumTestware.getValue();
                    final int artifactCount = (int) sumArtifact.getValue();
                    final int groupCount = (int) bucket.getDocCount();
                    map.put(WEEK_DAY, weekDay);
                    map.put(status.toLowerCase().concat(WordUtils.capitalize(TESTWARE_COUNT)), testwareCount);
                    map.put(status.toLowerCase().concat(WordUtils.capitalize(ARTIFACT_COUNT)), artifactCount);
                    map.put(status.toLowerCase().concat(WordUtils.capitalize(GROUP_COUNT)), groupCount);
                    map.put(DATE_TIME, dateString);
                    maps.add(map);
                });
                return maps;
            }
        };
    }
    
    public ResultsExtractor<List<Map<String, Object>>> testwareGroupCountExtractor(final String status) {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
                final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final Aggregations aggregations = response.getAggregations();
                final DateHistogram daily = aggregations.get(DAILY);
                @SuppressWarnings("unchecked")
                final List<DateHistogram.Bucket> dateBuckets = (List<DateHistogram.Bucket>) daily
                        .getBuckets();
                dateBuckets.stream().forEach((dateBucket) -> {
                    final Map<String, Object> map = new HashMap<String, Object>();
                    final Terms terms = dateBucket.getAggregations().get("testwareGroup");
                    final Collection<Terms.Bucket> termBuckets = terms.getBuckets();
                    termBuckets.stream().forEach((termBucket) -> {
                        System.out.println(termBucket.getKey());
                        final String groupKey = termBucket.getKey().equals("false") ? GROUP : TESTWARE_GROUP;
                        final int groupCount = (int) termBucket.getDocCount();
                        map.put("has"+WordUtils.capitalize(status.toLowerCase()).concat(groupKey), groupCount);
                    });
                    final String dateString = dateBucket.getKeyAsText().string();
                    final String day = getCountDate(dateBucket);
                    map.put(DATE_TIME, dateString);
                    map.put(DAY, day);
                    maps.add(map);
                });
                return maps;
            }
        };
    }
 
    
    public ResultsExtractor<List<Map<String, Object>>> dailyStatusExtractor(final String status) {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
                final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final Aggregations aggregations = response.getAggregations();
                final DateHistogram daily = aggregations.get(DAILY);
                @SuppressWarnings("unchecked")
                final List<DateHistogram.Bucket> buckets = (List<DateHistogram.Bucket>) daily
                        .getBuckets();
                buckets.stream().forEach((bucket) -> {
                    final Sum sumArtifact = (Sum) bucket.getAggregations().getAsMap().get(ARTIFACT_COUNT);
                    final Sum sumTestware = (Sum) bucket.getAggregations().getAsMap().get(TESTWARE_COUNT);
                    final Map<String, Object> map = new HashMap<String, Object>();
                    final String dateString = bucket.getKeyAsText().string();
                    final String day = getCountDate(bucket);
                    final int testwareCount = (int) sumTestware.getValue();
                    final int artifactCount = (int) sumArtifact.getValue();
                    final int groupCount = (int) bucket.getDocCount();
                    map.put(status.toLowerCase().concat(WordUtils.capitalize(TESTWARE_COUNT)), testwareCount);
                    map.put(status.toLowerCase().concat(WordUtils.capitalize(ARTIFACT_COUNT)), artifactCount);
                    map.put(status.toLowerCase().concat(WordUtils.capitalize(GROUP_COUNT)), groupCount);
                    map.put(DATE_TIME, dateString);
                    map.put(DAY, day); 
                    maps.add(map);
                });
                return maps;
            }
        };
    }

    public ResultsExtractor<List<Map<String, Object>>> groupTeamExtractor() {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
                final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final Aggregations aggregations = response.getAggregations();
                final Terms terms = aggregations.get(TEAMS);
                final Collection<Terms.Bucket> buckets = terms.getBuckets();
                buckets.stream().forEach((bucket) -> {
                    final Map<String, Object> map = new HashMap<String, Object>();
                    final String team = bucket.getKeyAsText().toString();
                    final int groupCount = (int) bucket.getDocCount();
                    map.put(TEAM_NAME, team);
                    map.put(GROUP_COUNT, groupCount);
                    maps.add(map);
                });
                return maps;
            }
        };
    }

    public ResultsExtractor<Map<String, Double>> getAverageExtractor(
            final String key) {
        return new ResultsExtractor<Map<String, Double>>() {
            @Override
            public Map<String, Double> extract(final SearchResponse response) {
                final Aggregations aggregations = response.getAggregations();
                final Avg average = aggregations.get(key);
                return new HashMap<String, Double>() {
                    private static final long serialVersionUID = -99656928088180949L;
                    {
                        put(key, average.getValue());
                    }
                };
            }
        };
    }

    /**
     * Extract Aggregations from the <code>SearchResponse</code>> and create map
     *
     * @return Map contains count for group artifacts and testware
     */
    public ResultsExtractor<Map<String, Integer>> getTotalCountExtractor() {
        return new ResultsExtractor<Map<String, Integer>>() {
            @Override
            public Map<String, Integer> extract(final SearchResponse response) {
                final Aggregations aggregations = response.getAggregations();
                final Sum testware = aggregations.get(TESTWARE_COUNT);
                final Sum artifacts = aggregations.get(ARTIFACT_COUNT);
                return new HashMap<String, Integer>() {
                    private static final long serialVersionUID = -5165012885031325914L;

                    {
                        put(GROUP_COUNT, (int) response.getHits().totalHits());
                        put(TESTWARE_COUNT, (int) testware.getValue());
                        put(ARTIFACT_COUNT, (int) artifacts.getValue());
                    }
                };
            }
        };
    }
    
	private String getCountDate(Bucket bucket){
		Date date = bucket.getKeyAsDate().toDate();
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		return dateFormat.format(date);
	}


}
