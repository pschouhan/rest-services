/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.portaldrop;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.sprint.Sprint;
import com.ericsson.cifwk.metrics.sprint.SprintRepository;

@Service
public class PortalDropService {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String OPEN = "open";

    @Autowired
    private PortalDropRepository portalDropRepository;

    @Autowired
    private SprintRepository sprintRepository;

    @Autowired
    private ServerDateTime serverDateTime;

    @Value("${product}")
    private String product;

    /**
     * Obtains current maintrack status.
     * Source: CIPortal.
     * Possible status: Open, Limited, Closed.
     * When status Closed reason of closing is retrieved.
     *
     * @return maintrack status information object
     */
    public PortalDrop getPortalStatus() {
        final List<PortalDrop> drops = portalDropRepository.findFirstByDropAndProduct(getCurrentSprint().getName(), product);
        PortalDrop portalDrop = new PortalDrop();
        if (drops.isEmpty()) {
            portalDrop.setStatus(OPEN);
        } else {
            portalDrop = drops.get(0);
        }
        logger.debug("portal drop:{}", portalDrop);
        return portalDrop;
    }

    private Sprint getCurrentSprint() {
        return sprintRepository.findFirstByDateTime(serverDateTime.getCurrentDateTime().getMillis());
    }
}
