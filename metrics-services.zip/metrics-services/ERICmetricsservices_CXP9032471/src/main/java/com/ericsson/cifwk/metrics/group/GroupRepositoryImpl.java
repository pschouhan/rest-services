/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2015
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.group;

import java.util.List;
import java.util.Map;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.FilteredQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.metrics.MetricsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.SumBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;

import com.ericsson.cifwk.metrics.sprint.Sprint;

@Repository
public class GroupRepositoryImpl implements GroupRepository {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String STATUS = "status";
    private static final String DROP = "drop";
    private static final String TEAMS = "teams";
    private static final String ARTIFACT_COUNT = "artifactCount";
    private static final String TESTWARE_COUNT = "testwareCount";
    private static final String STATUS_TIME = "statusTime";
    private static final String ARTIFACT_IN_GROUP = "artifactsInGroup";
    private static final String TESTWARE_IN_GROUP = "testwareInGroup";
    private static final String DAILY = "daily";
    private static final String GROUP_TEAM = "groupTeam";
    private static final String PRODUCT = "product";
    private static final String DROP_REGEX = "[0-9]+(\\.[0-9]+)";
    private static final String STATUS_CREATED = "CREATED";
    private static final String STATUS_MODIFIED = "MODIFIED";
    private static final String STATUS_RESTORED = "RESTORED";
    private static final String TESTWARE_GROUP = "testwareGroup";
    
    @Value("${es.index}")
    private String index;

    @Value("${es.index.type.group}")
    private String type;

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    private GroupExtractors groupExtractor;

    @Override

    public List<Map<String, Object>> findGroupArtifactAndTestwareCountOnDaily(
            final String status, final Sprint sprint) {
        logger.debug(
                "Query params to Find Group, Artifact, and Testware Count On Daily for Sprint, status:{}, drop:{}, from:{}, to:{}",
                status, sprint.getName(), String.valueOf(sprint.getStartTimeInMillis()), String.valueOf(sprint.getEndTimeInMillis()));
        final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(STATUS, status),
                        FilterBuilders.termFilter(DROP, sprint.getName()), 
                        FilterBuilders.rangeFilter(STATUS_TIME).from(sprint.getStartTimeInMillis()).to(sprint.getEndTimeInMillis())));
        final MetricsAggregationBuilder<?> aggregateArtifactcount = AggregationBuilders
                .sum(ARTIFACT_COUNT).field(ARTIFACT_IN_GROUP);
        final MetricsAggregationBuilder<?> aggregateTestwarecount = AggregationBuilders
                .sum(TESTWARE_COUNT).field(TESTWARE_IN_GROUP);
        final AggregationBuilder<?> dailyDateHistogram = AggregationBuilders
                .dateHistogram(DAILY).field(STATUS_TIME).minDocCount(0)
                .extendedBounds(sprint.getStartTimeInMillis(), sprint.getEndTimeInMillis()).interval(DateHistogram.Interval.DAY)
                .subAggregation(aggregateArtifactcount)
                .subAggregation(aggregateTestwarecount);
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index).withTypes(type).withQuery(filteredQuery)
                .addAggregation(dailyDateHistogram).build();
        return elasticsearchTemplate.query(query,
                groupExtractor.dailyStatusExtractor(sprint,status));
    }
    
    @Override

    public List<Map<String, Object>> findTestwareGroupCountOnDaily(
            final String status, final Sprint sprint){
    	 logger.debug(
                 "Query params to Find Group, Artifact, and Testware Count On Daily for Sprint, status:{}, drop:{}, from:{}, to:{}",
                 status, sprint.getName(), String.valueOf(sprint.getStartTimeInMillis()), String.valueOf(sprint.getEndTimeInMillis()));
         final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(
                 QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                         FilterBuilders.termFilter(STATUS, status),
                         FilterBuilders.termFilter(DROP, sprint.getName()), 
                         FilterBuilders.rangeFilter(STATUS_TIME).from(sprint.getStartTimeInMillis()).to(sprint.getEndTimeInMillis())));
         final MetricsAggregationBuilder<?> aggregateArtifactcount = AggregationBuilders
                 .sum(ARTIFACT_COUNT).field(ARTIFACT_IN_GROUP);
         final MetricsAggregationBuilder<?> aggregateTestwarecount = AggregationBuilders
                 .sum(TESTWARE_COUNT).field(TESTWARE_IN_GROUP);
         final AggregationBuilder<?> dailyDateHistogram = AggregationBuilders
                 .dateHistogram(DAILY).field(STATUS_TIME).minDocCount(0)
                 .extendedBounds(sprint.getStartTimeInMillis(), sprint.getEndTimeInMillis()).interval(DateHistogram.Interval.DAY)
                 .subAggregation(AggregationBuilders.terms(TESTWARE_GROUP)
                                .field(TESTWARE_GROUP)
                                .subAggregation(aggregateArtifactcount)
                                .subAggregation(aggregateTestwarecount)
                        );
         final SearchQuery query = new NativeSearchQueryBuilder()
                 .withIndices(index).withTypes(type).withQuery(filteredQuery)
                 .addAggregation(dailyDateHistogram).build();
         return elasticsearchTemplate.query(query,
                 groupExtractor.testwareGroupCountExtractor(status));
    }

    @Override
    public List<Map<String, Object>> findGroupArtifactAndTestwareCountOnDailyBetweenStatusTime(final String status,
	    final long startTime, final long endTime) {
	logger.debug(
		"Query params to Find Group, Artifact, and Testware Count On Daily between status time, status:{}, from:{}, to:{}",
		status, String.valueOf(startTime), String.valueOf(endTime));
	final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
		FilterBuilders.andFilter(FilterBuilders.termFilter(STATUS, status),
			FilterBuilders.rangeFilter(STATUS_TIME).from(startTime).to(endTime)));
	final MetricsAggregationBuilder<?> aggregateArtifactcount = AggregationBuilders.sum(ARTIFACT_COUNT)
		.field(ARTIFACT_IN_GROUP);
	final MetricsAggregationBuilder<?> aggregateTestwarecount = AggregationBuilders.sum(TESTWARE_COUNT)
		.field(TESTWARE_IN_GROUP);
	final AggregationBuilder<?> dailyDateHistogram = AggregationBuilders.dateHistogram(DAILY).field(STATUS_TIME)
		.minDocCount(0).extendedBounds(startTime, endTime).interval(DateHistogram.Interval.DAY)
		.subAggregation(aggregateArtifactcount).subAggregation(aggregateTestwarecount);
	final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(filteredQuery).addAggregation(dailyDateHistogram).build();
	return elasticsearchTemplate.query(query, groupExtractor.dailyStatusExtractor(status));
    }
    
    
    
   
   
    @Override
    public List<Map<String, Object>> findTestwareGroupCountOnDailyBetweenStatusTime(final String status,
            final long startTime, final long endTime) {
        logger.debug(
                "Query params to Find Group, Artifact, and Testware Count On Daily between status time, status:{}, from:{}, to:{}",
                status, String.valueOf(startTime), String.valueOf(endTime));
        final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
                FilterBuilders.andFilter(FilterBuilders.termFilter(STATUS, status),
                        FilterBuilders.rangeFilter(STATUS_TIME).from(startTime).to(endTime)));
        final AggregationBuilder<?> dailyDateHistogram =
                AggregationBuilders
                        .dateHistogram(DAILY)
                        .field(STATUS_TIME)
                        .minDocCount(0)
                        .extendedBounds(startTime, endTime)
                        .interval(DateHistogram.Interval.DAY)
                        .subAggregation(AggregationBuilders.terms(TESTWARE_GROUP)
                                .field(TESTWARE_GROUP)
                        );
        final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
                .withQuery(filteredQuery).addAggregation(dailyDateHistogram).build();
        return elasticsearchTemplate.query(query, groupExtractor.testwareGroupCountExtractor(status));
    }
  
    
    

    @Override
    public List<Group> findGroupsBetweenStatusTimeFilteredBySprintName(final String status, final long startTime,
	    final long endTime, final String product, final Object... sprintNameList) {
	logger.debug(
		"Query params to Find Group, Artifact, and Testware Count according to the selected date range and the selected Sprint list between status time, status:{}, from:{}, to:{}, SprintList:{}",
		status, String.valueOf(startTime), String.valueOf(endTime), concatString(sprintNameList));
	final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
		FilterBuilders.andFilter(FilterBuilders.termFilter(STATUS, status),
			FilterBuilders.termsFilter(DROP, sprintNameList),
			FilterBuilders.regexpFilter(DROP, DROP_REGEX),
			FilterBuilders.termsFilter(PRODUCT, product),
			FilterBuilders.rangeFilter(STATUS_TIME).from(startTime).to(endTime)));
	final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(filteredQuery).withPageable(new PageRequest(0, Integer.MAX_VALUE))
		.withSort(SortBuilders.fieldSort(STATUS_TIME).order(SortOrder.ASC)).build();
	return elasticsearchTemplate.queryForList(query, Group.class);
    }

    private String concatString(Object[] sprintNameList) {
	StringBuffer sb=new StringBuffer();
	for(Object sprint:sprintNameList){
	sb.append((String)sprint+",");
	}
	return sb.toString().substring(0,sb.toString().length()-1);
    }

    @Override
    public List<Map<String, Object>> findTeamsContributedInDropByStatus(final String status, final String drop,
	    final long startTime, final long endTime) {
	logger.debug("Query params to Find Teams Contributed In Drop By Status, status:{}, drop:{}, from:{}, to:{}",
		status, drop, String.valueOf(startTime), String.valueOf(endTime));
	final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
		FilterBuilders.andFilter(FilterBuilders.termFilter(STATUS, status),
			FilterBuilders.termFilter(DROP, drop),
			FilterBuilders.rangeFilter(STATUS_TIME).from(startTime).to(endTime)));
	final AggregationBuilder<?> aggregationBuilder = AggregationBuilders.terms(TEAMS).field(GROUP_TEAM);
	final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(filteredQuery).addAggregation(aggregationBuilder).withPageable(new PageRequest(0, 10))
		.build();
	return elasticsearchTemplate.query(query, groupExtractor.groupTeamExtractor());
    }

    @Override
    public Map<String, Double> findAvgQueueDetails(final String drop, final long startOfDay, final long endOfDay,
	    final String key, final String field) {
	logger.debug(
		"Query params to Find Average Queue Details, drop:{}, startOfDay:{}, endOfDay:{}, key:{}, field:{}",
		drop, String.valueOf(startOfDay), String.valueOf(endOfDay), key, field);
	final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
		FilterBuilders.andFilter(FilterBuilders.termFilter(DROP, drop),
			FilterBuilders.rangeFilter(STATUS_TIME).from(startOfDay).to(endOfDay)));
	final MetricsAggregationBuilder<?> aggregationBuilder = AggregationBuilders.avg(key).field(field);
	final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(filteredQuery).addAggregation(aggregationBuilder).build();
	return elasticsearchTemplate.query(query, groupExtractor.getAverageExtractor(key));
    }

    @Override
    public List<Group> findLatestQueueDetails(final int limit, final String drop) {
	logger.debug("Query params to Find Latest Queue Details, limit:{}, drop:{}", drop, String.valueOf(limit), drop);
	final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
		FilterBuilders.andFilter(FilterBuilders.termFilter(DROP, drop)));
	final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(filteredQuery).withPageable(new PageRequest(0, limit))
		.withSort(SortBuilders.fieldSort(STATUS_TIME).order(SortOrder.DESC)).build();
	return elasticsearchTemplate.queryForList(query, Group.class);
    }

    @Override
    public long countByProductBetweenStatusTime(final long startTime, final long endTime, final String product) {
	logger.debug("countByProductBetweenStatusTime, from:{},to:{}, product:{}", startTime, endTime, product);
	final BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery().must(QueryBuilders.termQuery(PRODUCT, product));

	final SearchQuery countQuery = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(queryBuilder).withFilter(FilterBuilders.rangeFilter(STATUS_TIME).from(startTime).to(endTime))
		.build();
	final long dataCount = elasticsearchTemplate.count(countQuery);
	logger.debug("countByProductBetweenStatusTime :{}", dataCount);
	return dataCount;
    }

    @Override
    public List<Group> findByProductBetweenStatusTime(final long startTime, final long endTime, final String product,
	    final int limit) {

	logger.debug("findByProductBetweenStatusTime, from:{},to:{}, product:{}", startTime, endTime, product);
	final BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery().must(QueryBuilders.termQuery(PRODUCT, product));

	final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(queryBuilder).withPageable(new PageRequest(0, limit))
		.withFilter(FilterBuilders.rangeFilter(STATUS_TIME).from(startTime).to(endTime))
		.withSort(SortBuilders.fieldSort(STATUS_TIME).order(SortOrder.ASC)).build();
	final List<Group> groups = elasticsearchTemplate.queryForList(query, Group.class);
	logger.debug("Queue Details: {}", groups);
	return groups;
    }

    @Override
    public Map<String, Integer> findTotalGroupArtifactAndTestwareBetweenDateTimeByStatus(final long startTime,
	    final long endTime, final String status) {
	final SumBuilder aggregateArtifactcount = AggregationBuilders.sum(ARTIFACT_COUNT).field(ARTIFACT_IN_GROUP);
	final SumBuilder aggregateTestwarecount = AggregationBuilders.sum(TESTWARE_COUNT).field(TESTWARE_IN_GROUP);
	final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
		FilterBuilders.andFilter(FilterBuilders.termFilter(STATUS, status),
			FilterBuilders.rangeFilter(STATUS_TIME).from(startTime).to(endTime)));
	final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
		.withQuery(filteredQuery).addAggregation(aggregateTestwarecount).addAggregation(aggregateArtifactcount)
		.build();
	final Map<String, Integer> countMap = elasticsearchTemplate.query(query,
		groupExtractor.getTotalCountExtractor());
	logger.debug("Total Group,Artifact,Testware: {}", countMap);
	return countMap;
    }
   
	@Override
	public List<Group> findWaitingQueueDetails(final String drop) {
		logger.debug("Query params to Find Waiting Queue Details:  drop:{}", drop);
		final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
				FilterBuilders.andFilter(FilterBuilders.termFilter(DROP, drop), FilterBuilders.termsFilter(STATUS,
						new String[] { STATUS_CREATED, STATUS_MODIFIED, STATUS_RESTORED })));
		final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
				.withQuery(filteredQuery).withPageable(new PageRequest(0, Integer.MAX_VALUE))
				.withSort(SortBuilders.fieldSort(STATUS_TIME).order(SortOrder.DESC)).build();
		return elasticsearchTemplate.queryForList(query, Group.class);
	}
}
