/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.aue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.Aggregations;
//import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Component;

@Component
public class AueExtractors {

    private static final String ARTIFACT= "artifact";
    private static final String COUNT= "count";
    
    
        
    
    public ResultsExtractor<List<Map<String, Object>>> getartifactVOExtractor() {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
            	final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final Aggregations aggregations = response.getAggregations();
                final Terms terms = aggregations.get(ARTIFACT);
                //@SuppressWarnings("unchecked")
                final List<Terms.Bucket> buckets = (List<Terms.Bucket>) terms.getBuckets();
                for (final Terms.Bucket bucket : buckets) {
                	final String artifact = bucket.getKeyAsText().toString();
                	final int artifactCount = (int) bucket.getDocCount();
                    final Map<String, Object> map = new HashMap<String, Object>() {
                        private static final long serialVersionUID = -4908911391050681159L;
                        {
                            put(ARTIFACT, artifact);   
                            put(COUNT, artifactCount);
                            
                        }
                    };
                    maps.add(map);
                }
                return maps;
            }
        };
    }
}