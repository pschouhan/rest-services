/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.aue;

import java.util.Objects;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Aue implements Comparable<Aue>{
	

    /**
		 * @author emytvel
		 *
		 */
	public class MessageType {

	}

	
    private String artifactId;
   
    private String eventTime;
    

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(final String eventTime) {
        this.eventTime = eventTime;
    }

    
    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

     @Override
    public int hashCode() {
        return Objects.hash(artifactId);
    }

    @Override
    public boolean equals(final Object obj) {
        final Aue other = (Aue) obj;
        return artifactId.equals(other.getArtifactId());
                
    }

    @JsonIgnore
    public long getEventTimeInMillis() {
        final DateTime dateTime = new DateTime(eventTime, DateTimeZone.UTC);
        return dateTime.getMillis();
    }

	@Override
	public int compareTo(Aue arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

}
