/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.multiclme;

import java.util.List;
import java.util.Map;

public interface MultiClmeRepository {

    List<MultiClme> findMTEDetails(final long from, final long to, final Object... drops);
    List<MultiClme> findUGStatusDetails(final long startTime, final long endTime, final Object... status);
    List<MultiClme> findMaintrackPhysicalKGB(final long startTime, final long endTime, final Object... drops);
    List<MultiClme> findMaintrackPhysicalIIKGB(final long startTime, final long endTime, final Object... drops);
    List<MultiClme> findMaintrackMicroENMII(final long startTime, final long endTime, final Object... drops);
    List<Map<String, Object>> findMTEPhysicalTrendInDrops(final String testLoop, final Object... drops);

}
