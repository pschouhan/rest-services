/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.releaseinfo;

import java.util.*;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.cifwk.metrics.domain.ServerDateTime;

@Service
public class ReleaseInfoService {

	private static final String WEEKS = "weeks";
	private static final String DAYS = "days";
	private static final String ACHIEVED = "achieved";

	@Autowired
	private ReleaseInfoRepository releaseInfoRepository;

	@Autowired
	private ServerDateTime serverDateTime;

	public List<ReleaseInfoVO> getCoutdownInfo() {

		ReleaseInfoVO releaseInfoVO = new ReleaseInfoVO();

		List<ReleaseInfoVO> releaseInfoVOList = new ArrayList<>();

		final long today = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay().getMillis();

		final List<ReleaseInfo> releaseInfoList = releaseInfoRepository.getReleaseInfo();

		ReleaseInfo releaseInfo = releaseInfoList.get(0);
		DateTime gaDateTime = new DateTime(releaseInfo.getGa(), DateTimeZone.UTC);
		DateTime rfaDateTime = new DateTime(releaseInfo.getRfa(), DateTimeZone.UTC);
		DateTime rfsDateTime = new DateTime(releaseInfo.getRfs(), DateTimeZone.UTC);

		Map<String, String> gaTimeDiff = getTimeDiff(gaDateTime, today);
		releaseInfoVO.setRemainingWeeksForGa(gaTimeDiff.get(WEEKS));
		releaseInfoVO.setRemainingDaysForGa(gaTimeDiff.get(DAYS));

		Map<String, String> rfaTimeDiff = getTimeDiff(rfaDateTime, today);
		releaseInfoVO.setRemainingWeeksForRfa(rfaTimeDiff.get(WEEKS));
		releaseInfoVO.setRemainingDaysForRfa(rfaTimeDiff.get(DAYS));

		Map<String, String> rfsTimeDiff = getTimeDiff(rfsDateTime, today);
		releaseInfoVO.setRemainingWeeksForRfs(rfsTimeDiff.get(WEEKS));
		releaseInfoVO.setRemainingDaysForRfs(rfsTimeDiff.get(DAYS));

		releaseInfoVO.setGaDate(releaseInfo.getGa());
		releaseInfoVO.setRfaDate(releaseInfo.getRfa());
		releaseInfoVO.setRfsDate(releaseInfo.getRfs());
		releaseInfoVO.setRelease(releaseInfo.getRelease());

		releaseInfoVOList.add(releaseInfoVO);

		return releaseInfoVOList;
	}

	public Map<String, String> getTimeDiff(DateTime dateTime, long today) {

		Map<String, String> timeDiffInWeeksAndDays = new HashMap<>();
		long timeDiff = dateTime.getMillis() - today;

		if (timeDiff > 0) {
			long seconds = (timeDiff / 1000) | 0;
			timeDiff -= seconds * 1000;

			long minutes = (seconds / 60) | 0;
			seconds -= minutes * 60;

			long hours = (minutes / 60) | 0;
			minutes -= hours * 60;

			long days = (hours / 24) | 0;
			hours -= days * 24;

			long weeks = (days / 7) | 0;
			days -= weeks * 7;

			timeDiffInWeeksAndDays.put(WEEKS, String.valueOf(weeks));
			timeDiffInWeeksAndDays.put(DAYS, String.valueOf(days));

		} else {
			timeDiffInWeeksAndDays.put(WEEKS, ACHIEVED);
			timeDiffInWeeksAndDays.put(DAYS, ACHIEVED);
		}

		return timeDiffInWeeksAndDays;
	}
}
