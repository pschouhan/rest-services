package com.ericsson.cifwk.metrics.sprint;

/**
 * Created by lmirbe on 27/05/16.
 */
public class Sprints {

    String allSprints = "";

    public void addSprint(final String name, final String release, final String start, final String end ) {
        this.allSprints += "Name: "+name;
        this.allSprints += " Release: "+release;
        this.allSprints += " StartDate: "+start;
        this.allSprints += " EndDate: "+end;
        this.allSprints += "\n";
    }

    public String getSprints() {
        return allSprints;
    }


}
