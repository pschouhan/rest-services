/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.releaseinfo;

public class ReleaseInfoVO {
	private String rfaDate;
	private String remainingWeeksForRfa;
	private String remainingDaysForRfa;
	private String rfsDate;
	private String remainingWeeksForRfs;
	private String remainingDaysForRfs;
	private String gaDate;
	private String remainingWeeksForGa;
	private String remainingDaysForGa;
	private String release;

	public String getRfaDate() {
		return rfaDate;
	}

	public void setRfaDate(String rfaDate) {
		this.rfaDate = rfaDate;
	}

	public String getRemainingWeeksForRfa() {
		return remainingWeeksForRfa;
	}

	public void setRemainingWeeksForRfa(String remainingWeeksForRfa) {
		this.remainingWeeksForRfa = remainingWeeksForRfa;
	}

	public String getRemainingDaysForRfa() {
		return remainingDaysForRfa;
	}

	public void setRemainingDaysForRfa(String remainingDaysForRfa) {
		this.remainingDaysForRfa = remainingDaysForRfa;
	}

	public String getRfsDate() {
		return rfsDate;
	}

	public void setRfsDate(String rfsDate) {
		this.rfsDate = rfsDate;
	}

	public String getRemainingWeeksForRfs() {
		return remainingWeeksForRfs;
	}

	public void setRemainingWeeksForRfs(String remainingWeeksForRfs) {
		this.remainingWeeksForRfs = remainingWeeksForRfs;
	}

	public String getRemainingDaysForRfs() {
		return remainingDaysForRfs;
	}

	public void setRemainingDaysForRfs(String remainingDaysForRfs) {
		this.remainingDaysForRfs = remainingDaysForRfs;
	}

	public String getGaDate() {
		return gaDate;
	}

	public void setGaDate(String gaDate) {
		this.gaDate = gaDate;
	}

	public String getRemainingWeeksForGa() {
		return remainingWeeksForGa;
	}

	public void setRemainingWeeksForGa(String remainingWeeksForGa) {
		this.remainingWeeksForGa = remainingWeeksForGa;
	}

	public String getRemainingDaysForGa() {
		return remainingDaysForGa;
	}

	public void setRemainingDaysForGa(String remainingDaysForGa) {
		this.remainingDaysForGa = remainingDaysForGa;
	}

	public String getRelease() {
		return release;
	}

	public void setRelease(String release) {
		this.release = release;
	}
}
