/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2015
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.group;

import org.joda.time.DateTime;

public class Group {

	public enum GroupKgbStatus {
		PASSED, FAILED, IN_PROGRESS, NOT_STARTED;
	}

	private int artifactsInGroup;
	private int queueLength;
	private int artifactsInQueue;
	private String queueId;
	private String status;
	private String statusTime;
	private String product;
	private String drop;
	private int testwareInGroup;
	private boolean hasMissingDependencies = false;
	private GroupKgbStatus groupKgbStatus = GroupKgbStatus.NOT_STARTED;
	private long timeInQueue;

	public long getTimeInQueue() {
		return timeInQueue;
	}

	public void setTimeInQueue(final long timeInQueue) {
		this.timeInQueue = timeInQueue;
	}

	public GroupKgbStatus getGroupKgbStatus() {
		return groupKgbStatus;
	}

	public void setGroupKgbStatus(final GroupKgbStatus groupKgbStatus) {
		this.groupKgbStatus = groupKgbStatus;
	}

	public boolean getHasMissingDependencies() {
		return hasMissingDependencies;
	}

	public void setHasMissingDependencies(final boolean hasMissingDependencies) {
		this.hasMissingDependencies = hasMissingDependencies;
	}

	public int getArtifactsInGroup() {
		return artifactsInGroup;
	}

	public void setArtifactsInGroup(final int artifactsInGroup) {
		this.artifactsInGroup = artifactsInGroup;
	}

	public int getQueueLength() {
		return queueLength;
	}

	public void setQueueLength(final int queueLength) {
		this.queueLength = queueLength;
	}

	public int getArtifactsInQueue() {
		return artifactsInQueue;
	}

	public void setArtifactsInQueue(final int artifactsInQueue) {
		this.artifactsInQueue = artifactsInQueue;
	}

	public String getQueueId() {
		return queueId;
	}

	public void setQueueId(final String queueId) {
		this.queueId = queueId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String status) {
		this.status = status;
	}

	public String getStatusTime() {
		return statusTime;
	}

	public void setStatusTime(final String statusTime) {
		this.statusTime = statusTime;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(final String product) {
		this.product = product;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(final String drop) {
		this.drop = drop;
	}

	public long getStatusTimeInMillies() {
		return new DateTime(statusTime).getMillis();
	}

	public Integer getTestwareInGroup() {
		return testwareInGroup;
	}

	public void setTestwareInGroup(final Integer testwareInGroup) {
		this.testwareInGroup = testwareInGroup;
	}

}
