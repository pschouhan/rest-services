
package com.ericsson.cifwk.metrics.scm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.elasticsearch.common.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.exception.MetricsServiceException;
import com.ericsson.cifwk.metrics.sprint.Sprint;
import com.ericsson.cifwk.metrics.sprint.SprintRepository;

@Service
public class ScmService {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String COMMIT_FOR_TODAY = "commitsForToday";

    @Autowired
    private ScmRepository repository;

    @Autowired
    private SprintRepository sprintRepository;

    @Autowired
    private ServerDateTime serverDateTime;

    /**
     * Obtains the Team performance about commits per sprint, giving team name
     * and its commits count for the current sprint. When no team name found,
     * teams count will be sum and retrieved in "no name" team name. Uses Sprint
     * service to get all current Sprint Information.
     *
     * @return list of teams and its commits count for the sprint.
     */
    public List<Map<String, String>> getTeamPerformance(final String sprintName) {
        Sprint sprint = null;

        if (StringUtils.trimToNull(sprintName) == null) {
            // sprintName is empty or null
            sprint = getCurrentSprint();
        } else {
            // tries to find the sprint by given name
            sprint = sprintRepository.findByName(sprintName);
            if (sprint == null) {
                throw new MetricsServiceException("Can't find Team Performance due to invalid sprint name");
            }
        }

        final List<Map<String, String>> performance =
                repository.findTeamPerformanceBetweenTime(sprint.getStartTimeInMillis(), sprint.getEndTimeInMillis());
        logger.debug("Top 10 Perfoming Teams:{}", performance);
        return performance;
    }

    /**
     * Obtains total of hits representing the teams commit count for today.
     * Key used in map : commitsForToday
     *
     * @return Map <commitsForToday> commit count for the day
     */
    public Map<String, String> getCommitDetailsForToday() {
        final long today = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay().getMillis();
        final long tomorrow = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay().plusDays(1).getMillis();
        final int count = repository.findCommitDetailsBetweenTime(today, tomorrow);
        final HashMap<String, String> map = new HashMap<String, String>() {
            private static final long serialVersionUID = 1L;
            {
                put(COMMIT_FOR_TODAY, String.valueOf(count));
            }
        };
        logger.debug("Commit Count For Today :{}", map);
        return map;
    }

    private Sprint getCurrentSprint() {
        return sprintRepository.findFirstByDateTime(serverDateTime.getCurrentDateTime().getMillis());
    }
}
