
package com.ericsson.cifwk.metrics.scm;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
@Api(value = "/scm", description = "Gets information of team performance and Commit Details")
public class ScmEndPoint {

    @Autowired
    private ScmService scmAggregationService;

    @ApiOperation(value = "Gets a list of team performance details ")
    @RequestMapping(value = "/team-performance", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, String>> getTeamPerformance(
            final String sprint) {
        return scmAggregationService.getTeamPerformance(sprint);
    }

    @ApiOperation(value = "Gets a map of commit details")
    @RequestMapping(value = "/commit-details", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, String> getCommitDetails() {
        return scmAggregationService.getCommitDetailsForToday();
    }

}
