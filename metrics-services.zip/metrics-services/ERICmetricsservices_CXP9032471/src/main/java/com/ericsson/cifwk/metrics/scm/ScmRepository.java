
package com.ericsson.cifwk.metrics.scm;

import java.util.List;
import java.util.Map;

public interface ScmRepository {

    List<Map<String, String>> findTeamPerformanceBetweenTime(final long from, final long to);

    int findCommitDetailsBetweenTime(final long from, final long to);
}
