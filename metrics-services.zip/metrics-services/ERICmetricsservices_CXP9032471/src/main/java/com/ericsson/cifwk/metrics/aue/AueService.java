/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.aue;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.ericsson.cifwk.metrics.domain.ServerDateTime;

@Service
public class AueService {

    @Value("${product}")
    private String product;

    @Autowired
    private AueRepository AueRepository;

    @Autowired
    private ServerDateTime serverDateTime;
    
    
    public List<Map<String, Object>> getArtifactUploaded() {
        final long fromInMillis = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long toInMillis = serverDateTime.getCurrentDateTime().getMillis();
    	 final List<Map<String, Object>> artifactsUploaded = AueRepository.findArtifactsBetweenDays(fromInMillis, toInMillis);
    	 return artifactsUploaded;
      } 
}