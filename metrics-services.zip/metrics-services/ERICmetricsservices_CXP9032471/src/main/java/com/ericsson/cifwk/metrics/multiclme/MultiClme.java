/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.multiclme;

import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.ericsson.cifwk.metrics.multiclme.MultiClme;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class MultiClme implements Comparable<MultiClme>{
	

    private String masterVersion;
    private String workingBaseline;
    private String groupId;
    private String artifactId;
    private String artifactVersion;
    private String eventTime;
    private String drop;
    private String Deploy_ENM_II_status;
    private String Deploy_ENM_Micro_II_status;
    private String Deploy_ENM_II_teAllureLogUrl;
    private String Deploy_ENM_Micro_II_teAllureLogUrl;
    private String Deploy_ENM_UG_status;
    private String Deploy_ENM_UG_teAllureLogUrl;
    private String RFA_status;
    private String RFA_teAllureLogUrl;
    private String UG_Availability_status;
    private String UG_Availability_teAllureLogUrl;
    private String UG_Performance_status;
    private String UG_Performance_teAllureLogUrl;
    private String product;


    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(final String eventTime) {
        this.eventTime = eventTime;
    }

    public String getMasterVersion() {
        return masterVersion;
    }

    public void setMasterVersion(final String masterVersion) {
        this.masterVersion = masterVersion;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(final String groupId) {
        this.groupId = groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(final String artifactId) {
        this.artifactId = artifactId;
    }

    public String getDrop() {
        return drop;
    }

    public void setDrop(final String drop) {
        this.drop = drop;
    }

	public String getWorkingBaseline() {
		return workingBaseline;
	}

	public void setWorkingBaseline(String workingBaseline) {
		this.workingBaseline = workingBaseline;
	}

	public String getDeploy_ENM_II_status() {
		return Deploy_ENM_II_status;
	}

	public void setDeploy_ENM_II_status(String deploy_ENM_II_status) {
		Deploy_ENM_II_status = deploy_ENM_II_status;
	}
	
	public String getDeploy_ENM_Micro_II_status() {
		return Deploy_ENM_Micro_II_status;
	}

	public void setDeploy_ENM_Micro_II_status(String deploy_micro_enm_ii_status) {
		Deploy_ENM_Micro_II_status = deploy_micro_enm_ii_status;
	}

	public String getDeploy_ENM_II_teAllureLogUrl() {
		return Deploy_ENM_II_teAllureLogUrl;
	}

	public void setDeploy_ENM_II_teAllureLogUrl(String deploy_ENM_II_teAllureLogUrl) {
		Deploy_ENM_II_teAllureLogUrl = deploy_ENM_II_teAllureLogUrl;
	}
	
	public String getDeploy_ENM_Micro_II_teAllureLogUrl() {
		return Deploy_ENM_Micro_II_teAllureLogUrl;
	}

	public void setDeploy_ENM_Micro_II_teAllureLogUrl(String deploy_ENM_Micro_II_teAllureLogUrl) {
		Deploy_ENM_Micro_II_teAllureLogUrl = deploy_ENM_Micro_II_teAllureLogUrl;
	}

	public String getDeploy_ENM_UG_status() {
		return Deploy_ENM_UG_status;
	}

	public void setDeploy_enm_ug_status(String deploy_enm_ug_status) {
		Deploy_ENM_UG_status = deploy_enm_ug_status;
	}

	public String getDeploy_ENM_UG_teAllureLogUrl() {
		return Deploy_ENM_UG_teAllureLogUrl;
	}

	public void setDeploy_enm_ug_teAllureLogUrl(String deploy_ENM_UG_teAllureLogUrl) {
		Deploy_ENM_UG_teAllureLogUrl = deploy_ENM_UG_teAllureLogUrl;
	}

	public String getRFA_status() {
		return RFA_status;
	}

	public void setRFA_status(String rfa_status) {
		RFA_status = rfa_status;
	}

	public String getRFA_teAllureLogUrl() {
		return RFA_teAllureLogUrl;
	}

	public void setRFA_teAllureLogUrl(String rFA_teAllureLogUrl) {
		RFA_teAllureLogUrl = rFA_teAllureLogUrl;
	}

	public String getUG_Availability_status() {
		return UG_Availability_status;
	}

	public void setUg_availability_status(String ug_availability_status) {
		UG_Availability_status = ug_availability_status;
	}

	public String getUG_Availability_teAllureLogUrl() {
		return UG_Availability_teAllureLogUrl;
	}

	public void setUg_availability_teAllureLogUrl(String ug_availability_teAllureLogUrl) {
		UG_Availability_teAllureLogUrl = ug_availability_teAllureLogUrl;
	}

	public String getUG_Performance_status() {
		return UG_Performance_status;
	}

	public void setUg_performance_status(String ug_performance_status) {
		UG_Performance_status = ug_performance_status;
	}

	public String getUG_Performance_teAllureLogUrl() {
		return UG_Performance_teAllureLogUrl;
	}

	public void setUg_performance_teAllureLogUrl(String uG_Performance_teAllureLogUrl) {
		UG_Performance_teAllureLogUrl = uG_Performance_teAllureLogUrl;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getArtifactVersion() {
		return artifactVersion;
	}

	public void setArtifactVersion(String artifactVersion) {
		this.artifactVersion = artifactVersion;
	}

	@Override
    public int compareTo(final MultiClme mteVO) {
        if ("".equals(StringUtils.trimToEmpty(getArtifactVersion().trim()))) {
            return 1;
        }
        if ("".equals(StringUtils.trimToEmpty(mteVO.getArtifactVersion().trim()))) {
            return -1;
        }
        if (getArtifactVersion().equals(mteVO.getArtifactVersion())) {
            return 0;
        } else {
            final String[] mteArray1 = getArtifactVersion().split("\\.");
            final String[] mteArray2 = mteVO.getArtifactVersion().split("\\.");
            if (mteArray1.length > mteArray2.length) {
                return compareValues(mteArray1, mteArray2);
            } else {
                return compareValues(mteArray2, mteArray1);
            }
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(masterVersion, artifactId, artifactVersion, groupId);
    }

    @Override
    public boolean equals(final Object obj) {
        final MultiClme other = (MultiClme) obj;
        return masterVersion.equals(other.getMasterVersion()) && artifactId.equals(other.getArtifactId())
                && artifactVersion.equals(other.getArtifactVersion()) && groupId.equals(other.getGroupId());
    }

    private Integer compareValues(final String[] array1, final String[] array2) {
        for (int i = 0; i < array1.length; i++) {
            final Integer v1 = Integer.parseInt(array1[i]);
            final Integer v2 = Integer.parseInt(array2[i]);
            if (v1 != v2) {
                return v1 - v2;
            }
        }
        return 0;
    }

    @JsonIgnore
    public long getEventTimeInMillis() {
        final DateTime dateTime = new DateTime(eventTime, DateTimeZone.UTC);
        return dateTime.getMillis();
    }

}
