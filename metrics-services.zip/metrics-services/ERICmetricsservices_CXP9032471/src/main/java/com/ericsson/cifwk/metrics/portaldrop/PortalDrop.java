/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.portaldrop;

/**
 * This class holds current Maintrack Status.
 * Contains
 * eventId: Id of the event that is updating the maintrack status
 * eventTime: Time stamp of the event
 * status: maintrack status (open, limited, closed)
 * reason: if maintrack in status closed contains reason why maintrack is closed.
 */
public class PortalDrop {

    private String eventId;
    private String eventTime;
    private String status;
    private String reason;
    private String drop;

	public PortalDrop() {}

    public String getEventId() {
        return eventId;
    }

    public String getEventTime() {
        return eventTime;
    }

    public String getStatus() {
        return status;
    }

    public String getReason() {
        return reason;
    }

    public void setEventId(final String eventId) {
        this.eventId = eventId;
    }

    public void setEventTime(final String eventTime) {
        this.eventTime = eventTime;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public void setReason(final String reason) {
        this.reason = reason;
    }
    
	public String getDrop() {
		return drop;
	}

	public void setDrop(String drop) {
		this.drop = drop;
	}

    @Override
    public String toString() {
        return "PortalDrop [eventTime=" + eventTime + ", status=" + status + ", reason=" + reason + "]";
    }

}
