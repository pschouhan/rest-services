
package com.ericsson.cifwk.metrics.clme;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.FilteredQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;


@Repository
public class ClmeRepositoryImpl implements ClmeRepository {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String DROP = "drop";
    private static final String PRODUCT = "product";
    private static final String EVENT_TIME = "eventTime";
    private static final String STARTED_LEVEL = "startedLevel";
    private static final String FINISHED_LEVEL = "finishedLevel";
    private static final String FINISHED_LEVELS = "finishedLevels";
    private static final String DAILY = "daily";
    private static final String MESSAGE_TYPE = "messageType";
    private static final String DELIVERED = "DEL";
    private static final String MESSAGE_TYPE_CDB = "CDB";
    private static final String MTE_CL_STARTED = "CDB_MTE-P_STARTED";
    private static final String MTE_CL_COMPLETED = "CDB_MTE-P_COMPLETED";
    private static final String RFA_CL_STARTED = "CDB_RFA_STARTED";
    private static final String RFA_CL_COMPLETED = "CDB_RFA_COMPLETED";
    private static final String RVB_CL_STARTED = "CDB_MTE-RVB_STARTED";
    private static final String RVB_CL_COMPLETED = "CDB_MTE-RVB_COMPLETED";
    private static final String DEPLOY_COMPLETED = "CDB_ENM_DEPLOY_COMPLETED";
    private static final String ISO_BUILD_COMPLETED = "CDB_ISO_BUILD_COMPLETED";
    private static final String SUCCESS = "SUCCESS";
    private static final String COMPLETED_EVENT = "completedEvent";
    private static final String RESULT = "result";
    private static final String GROUP_ID = "groupId";
    private static final String ARTIFACT_ID = "artifactId";
    private static final String VERSION = "version";
    private static final String REGEX_DELIVERIES = "@&~(ERICTAF.+)"; // Anything except String beginning with "ERICTAF"
    private static final String MASTER_VERSION = "masterVersion";
    private static final String VERSION_REGEX = "[0-9]+(\\.[0-9]+)+(\\.[0-9]+)";
    private static final String DROP_REGEX = "[0-9]+(\\.[0-9]+)";
    private static final String ISO_MTE_CL_V_COMPLETED = "CDB_MTE-V_COMPLETED";
    private static final String ISO_Deploy_ENM_Micro_II_COMPLETED_SUCCESS = "CDB_Deploy-ENM-Micro-II_COMPLETED_SUCCESS";
    private static final String ISO_II_MTE_CL_P_COMPLETED = "CDB_II-MTE-P_COMPLETED";
    private static final String CAUTION_COMPLETED = "CDB_Caution_COMPLETED";
    private static final String DURATION_KNOWN = "durationKnown";
    private static final String FAILURE = "FAILURE";
    private static final String TEAM = "team";

    @Value("${es.index}")
    private String index;

    @Value("${es.index.type.clme}")
    private String type;

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    private ClmeExtractors extractors;

    @Override
    public Integer findDeliveriesForTodayByDropAndProduct(final long from,
            final long to, final String drop, final String product) {
        logger.debug(
                "Query params to Find Deliveries for Today By Drop & Product, from:{}, to:{}, drop:{}, product:{}",
                String.valueOf(from), String.valueOf(to), drop, product);
        final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(MESSAGE_TYPE, DELIVERED),
                        FilterBuilders.termFilter(DROP, drop),
                        FilterBuilders.termFilter(PRODUCT, product),
                        FilterBuilders.regexpFilter(ARTIFACT_ID, REGEX_DELIVERIES),
                        FilterBuilders.rangeFilter(EVENT_TIME).from(from)
                                .to(to)));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withTypes(type).withIndices(index).withQuery(filteredQuery)
                .build();
        return elasticsearchTemplate.query(query,
                extractors.getQueryResultCountExtractor());
    }

    @Override
    public List<Map<String, Object>> findDeliveryBetweenDaysByDropAndProduct(
            final long from, final long to, final String drop,
            final String product) {
        logger.debug(
                "Query params to Find Delivery Between Days By Drop & Product, from:{}, to:{}, drop:{}, product:{}",
                String.valueOf(from), String.valueOf(to), drop, product);
        final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(MESSAGE_TYPE, DELIVERED),
                        FilterBuilders.termFilter(DROP, drop),
                        FilterBuilders.termFilter(PRODUCT, product),
                        FilterBuilders.regexpFilter(ARTIFACT_ID, REGEX_DELIVERIES),
                        FilterBuilders.rangeFilter(EVENT_TIME).from(from)
                                .to(to)));
        final AggregationBuilder<?> dailyDateHistogarm = AggregationBuilders
                .dateHistogram(DAILY).field(EVENT_TIME).minDocCount(0)
                .extendedBounds(from, to).interval(DateHistogram.Interval.DAY);
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index).withTypes(type).withQuery(filteredQuery)
                .addAggregation(dailyDateHistogarm).build();
        return elasticsearchTemplate.query(query,
                extractors.getDeliveryVOExtractor());
    }

    @Override
    public List<Clme> findMTEDetails(final long from, final long to, final Object... drops) {
        final BoolQueryBuilder mteboolQuery = QueryBuilders
                .boolQuery()
                .must(QueryBuilders.termQuery(MESSAGE_TYPE, MESSAGE_TYPE_CDB))
                .must(QueryBuilders.termsQuery(DROP, drops))
                .should(QueryBuilders.termQuery(STARTED_LEVEL,
                        MTE_CL_STARTED))
                .should(QueryBuilders.termQuery(FINISHED_LEVEL,
                        MTE_CL_COMPLETED)).minimumShouldMatch("1");
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(mteboolQuery)
                .withFilter(
                        FilterBuilders.rangeFilter(EVENT_TIME).from(from)
                                .to(to))
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<Clme> findRFAList(final String groupId,
            final String artifactId, final String version) {
        final BoolQueryBuilder mteboolQuery = QueryBuilders
                .boolQuery()
                .must(QueryBuilders.termQuery(MESSAGE_TYPE, MESSAGE_TYPE_CDB))
                .must(QueryBuilders.termQuery(GROUP_ID, groupId))
                .must(QueryBuilders.termQuery(ARTIFACT_ID, artifactId))
                .must(QueryBuilders.termQuery(VERSION, version))
                .should(QueryBuilders.termQuery(STARTED_LEVEL,
                        RFA_CL_STARTED))
                .should(QueryBuilders.termQuery(FINISHED_LEVEL,
                        RFA_CL_COMPLETED)).minimumShouldMatch("1");
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(mteboolQuery)
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }


    @Override
    public List<Clme> findMaintrackCurrentRVB(final Object... drops) {
        final BoolQueryBuilder mteboolQuery = QueryBuilders
                .boolQuery()
                .must(QueryBuilders.termQuery(MESSAGE_TYPE, MESSAGE_TYPE_CDB))
                .must(QueryBuilders.termsQuery(DROP, drops))
                .must(QueryBuilders.regexpQuery(VERSION, VERSION_REGEX))
                .should(QueryBuilders.termQuery(STARTED_LEVEL,
                        RVB_CL_STARTED))
                .should(QueryBuilders.termQuery(FINISHED_LEVEL,
                        RVB_CL_COMPLETED)).minimumShouldMatch("1");
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(mteboolQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<Clme> findMaintrackBaselineRVB(final Object... drops) {
        final BoolQueryBuilder mteboolQuery = QueryBuilders
                .boolQuery()
                .must(QueryBuilders.termQuery(MESSAGE_TYPE, MESSAGE_TYPE_CDB))
                .must(QueryBuilders.termsQuery(DROP, drops))
                .must(QueryBuilders.regexpQuery(VERSION, VERSION_REGEX))
                .must(QueryBuilders.termQuery(RESULT,
                        SUCCESS))
                .must(QueryBuilders.termQuery(COMPLETED_EVENT, true))
                .must(QueryBuilders.termQuery(FINISHED_LEVEL,
                        RVB_CL_COMPLETED));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(mteboolQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<Clme> findMaintrackCloudKGB(final long startTime, final long endTime) {
        logger.debug(
                "Query params to Find Maintrack Cloud KGB, startTime:{}, endTime:{}",
                String.valueOf(startTime), String.valueOf(endTime));

        final FilteredQueryBuilder cloudBoolQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(MESSAGE_TYPE,
                                MESSAGE_TYPE_CDB),
                        FilterBuilders.regexpFilter(VERSION, VERSION_REGEX),
                        FilterBuilders.rangeFilter(EVENT_TIME).from(startTime)
                                .to(endTime), FilterBuilders.termFilter(
                                FINISHED_LEVEL, ISO_MTE_CL_V_COMPLETED),
                        FilterBuilders.termFilter(COMPLETED_EVENT, true)));

        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(cloudBoolQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<Clme> findMaintrackMicroENM(final long startTime, final long endTime) {
        logger.debug(
                "Query params to Find Maintrack Micro ENM, startTime:{}, endTime:{}",
                String.valueOf(startTime), String.valueOf(endTime));

        final FilteredQueryBuilder microBoolQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(MESSAGE_TYPE,
                                MESSAGE_TYPE_CDB),
                        FilterBuilders.regexpFilter(VERSION, VERSION_REGEX),
                        FilterBuilders.rangeFilter(EVENT_TIME).from(startTime)
                                .to(endTime), FilterBuilders.termFilter(
                                FINISHED_LEVELS, ISO_Deploy_ENM_Micro_II_COMPLETED_SUCCESS),
                        FilterBuilders.termFilter(COMPLETED_EVENT, true)));

        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(microBoolQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    
    @Override
    public List<Clme> findCautionDetails(final String masterVersion) {
        logger.debug(
                "Query params to Find Maintrack Cloud Caution, masterVersion:{}",
                String.valueOf(masterVersion));

        final FilteredQueryBuilder cautionBoolQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(MESSAGE_TYPE,
                                MESSAGE_TYPE_CDB),
                        FilterBuilders.termFilter(MASTER_VERSION, masterVersion),
                        FilterBuilders.termFilter(
                                FINISHED_LEVEL, CAUTION_COMPLETED),
                        FilterBuilders.termFilter(COMPLETED_EVENT, true)));

        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(cautionBoolQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<Clme> findPhysicalIIKGB(final long startTime, final long endTime) {
        logger.debug(
                "Query params to Find physical II KGB, startTime:{}, endTime:{}",
                String.valueOf(startTime), String.valueOf(endTime));

        final FilteredQueryBuilder physicalIIBoolQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(MESSAGE_TYPE,
                                MESSAGE_TYPE_CDB),
                        FilterBuilders.regexpFilter(VERSION, VERSION_REGEX),
                        FilterBuilders.rangeFilter(EVENT_TIME).from(startTime)
                                .to(endTime), FilterBuilders.termFilter(
                                FINISHED_LEVEL, ISO_II_MTE_CL_P_COMPLETED),
                        FilterBuilders.termFilter(COMPLETED_EVENT, true)));

        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(physicalIIBoolQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<Clme> findCautionDetailsForProductSet(final String productSet) {
        logger.debug(
                "Query params to Find Physical II KGB Caution,productSet:{}",
                String.valueOf(productSet));

        final FilteredQueryBuilder cautionBoolQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termFilter(MESSAGE_TYPE,
                                MESSAGE_TYPE_CDB),
                        FilterBuilders.termFilter(VERSION, productSet),
                        FilterBuilders.termFilter(
                                FINISHED_LEVEL, CAUTION_COMPLETED),
                        FilterBuilders.termFilter(COMPLETED_EVENT, true)));

        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(cautionBoolQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<Map<String, Object>> findMTEPhysicalTrendInDrops(final Object... drops) {
        final FilteredQueryBuilder filterQuery = QueryBuilders.filteredQuery(
                QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.regexpFilter(DROP, DROP_REGEX),
                        FilterBuilders.termFilter(MESSAGE_TYPE, MESSAGE_TYPE_CDB),
                        FilterBuilders.termFilter(FINISHED_LEVEL, MTE_CL_COMPLETED),
                        FilterBuilders.termsFilter(DROP, drops)));
        final AggregationBuilder<?> aggregationBuilder = AggregationBuilders.terms(DROP).field(DROP)
                // minDoc count is added to get values for all different kinds of results ,
                // if no data is found for particular result ,this function will automatically put 0 for that
                .subAggregation(AggregationBuilders.terms(RESULT).field(RESULT).minDocCount(0));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(filterQuery)
                .addAggregation(aggregationBuilder)
                .build();

        return elasticsearchTemplate.query(query, extractors.getMteTrendAggregation());

    }

    @Override
    public List<Clme> findTestTimeLoopDetailsByField(final String field, final Object... values) {
        final FilteredQueryBuilder filterQuery =
                QueryBuilders.filteredQuery(
                        QueryBuilders.matchAllQuery(),
                        FilterBuilders.andFilter(
                                FilterBuilders.regexpFilter(MASTER_VERSION, VERSION_REGEX),
                                FilterBuilders.regexpFilter(DROP, DROP_REGEX),
                                FilterBuilders.termFilter(MESSAGE_TYPE, MESSAGE_TYPE_CDB),
                                FilterBuilders.termFilter(DURATION_KNOWN, true),
                                FilterBuilders.termsFilter(FINISHED_LEVEL, new String[] { MTE_CL_COMPLETED, RVB_CL_COMPLETED, RFA_CL_COMPLETED,
                                    DEPLOY_COMPLETED, ISO_BUILD_COMPLETED }),
                                FilterBuilders.termsFilter(field, values)));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(filterQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.ASC))
                .build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<String> findIsoVersionsByDrop(final String drop) {

        final FilteredQueryBuilder filterQuery =
                QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(FilterBuilders.termFilter(DURATION_KNOWN, true),
                        FilterBuilders.termFilter(DROP, drop),
                        FilterBuilders.regexpFilter(DROP, DROP_REGEX),
                        FilterBuilders.termFilter(MESSAGE_TYPE, "CDB"),
                        FilterBuilders.termsFilter(FINISHED_LEVEL, new String[] { MTE_CL_COMPLETED, RVB_CL_COMPLETED, RFA_CL_COMPLETED,
                            DEPLOY_COMPLETED, ISO_BUILD_COMPLETED }),
                        FilterBuilders.regexpFilter(MASTER_VERSION, VERSION_REGEX)));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withQuery(filterQuery)
                .build();
        final List<Clme> clmes = elasticsearchTemplate.queryForList(query, Clme.class);
        return clmes.stream().map(Clme::getMasterVersion).collect(Collectors.toList());

    }

    @Override
    public List<Clme> findTeamProfile(final String team, final long startTime, final long endTime, final String[] profileMessageTypes) {
        logger.debug("Query team profile with team :{} from:{} to :{} messagetypes:{}", team, startTime, endTime, profileMessageTypes);
        final FilteredQueryBuilder filterQuery =
                QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(
                        FilterBuilders.termsFilter(RESULT, SUCCESS, FAILURE),
                        FilterBuilders.termFilter(TEAM, team),
                        FilterBuilders.termsFilter(MESSAGE_TYPE, profileMessageTypes),
                        FilterBuilders.rangeFilter(EVENT_TIME).from(startTime).to(endTime)));

        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withQuery(filterQuery)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withSort(
                        SortBuilders.fieldSort(EVENT_TIME)
                                .order(SortOrder.ASC))
                .build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }

    @Override
    public List<String> findIsoVersionsBetweenEventTime(final long fromTime, final long endTime) {
        final FilteredQueryBuilder filterQuery =
                QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
                        FilterBuilders.andFilter(FilterBuilders.termFilter(DURATION_KNOWN, true),
                                FilterBuilders.rangeFilter(EVENT_TIME).from(fromTime).to(endTime),
                                FilterBuilders.regexpFilter(DROP, DROP_REGEX),
                                FilterBuilders.regexpFilter(MASTER_VERSION, VERSION_REGEX),
                                FilterBuilders.termFilter(MESSAGE_TYPE, MESSAGE_TYPE_CDB),
                                FilterBuilders.termsFilter(FINISHED_LEVEL, new String[] { MTE_CL_COMPLETED, RVB_CL_COMPLETED, RFA_CL_COMPLETED,
                                    DEPLOY_COMPLETED, ISO_BUILD_COMPLETED })));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withQuery(filterQuery)
                .build();
        final List<Clme> clmes = elasticsearchTemplate.queryForList(query, Clme.class);
        return clmes.stream().map(Clme::getMasterVersion).collect(Collectors.toList());
    }

    @Override
    public List<Clme> findDetailsByKeyValueOrderByEventTime(final String field, final String value) {
        final FilteredQueryBuilder filterQuery =
                QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), FilterBuilders.andFilter(FilterBuilders.termFilter(DURATION_KNOWN, true),
                        FilterBuilders.termFilter(field, value),
                        FilterBuilders.regexpFilter(DROP, DROP_REGEX),
                        FilterBuilders.regexpFilter(MASTER_VERSION, VERSION_REGEX)));
        final SearchQuery query = new NativeSearchQueryBuilder()
                .withIndices(index)
                .withTypes(type)
                .withPageable(new PageRequest(0, Integer.MAX_VALUE))
                .withQuery(filterQuery)
                .withSort(SortBuilders.fieldSort(EVENT_TIME).order(SortOrder.ASC))
                .build();
        return elasticsearchTemplate.queryForList(query, Clme.class);
    }
}
