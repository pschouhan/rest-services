package com.ericsson.cifwk.metrics.team;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class TeamScheduledTask {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private TeamRepository teamRepository ;

	@Value("${ciPortal.url}")
	private String ciPortalUrl;

	@Scheduled(cron = "0 0 0/12 * * *")
	public void updateTeamInformation() {
		final RestTemplate restTemplate = new RestTemplate();
		final ResponseEntity<Team[]> responseEntity = restTemplate.getForEntity(ciPortalUrl, Team[].class);
		final List<Team> teamList = Arrays.asList(responseEntity.getBody());
		teamRepository.deleteAll();
		teamList.stream()
		.forEach(team -> { teamRepository.save(team);
			logger.debug("Scheduled Team information with related Tribe and artifacts Update  {}", team);});
	}

}
