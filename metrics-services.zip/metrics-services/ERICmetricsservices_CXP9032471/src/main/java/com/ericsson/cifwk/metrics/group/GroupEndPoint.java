
package com.ericsson.cifwk.metrics.group;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ericsson.cifwk.metrics.exception.MetricsServiceException;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Controller
@Api(value = "/group", description = "Gets clme group information as daily status,team status and current activity details")
public class GroupEndPoint {

    @Autowired
    private GroupService groupService;

    @ApiOperation(value = "Gets information of groups as daily status for Current Sprint")
    @RequestMapping(value = "/deliveries-trends", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getGroupsDailyStatus() {
	return groupService.getGroupArtifactAndTestwareCountOnDaily();
    }

    @ApiOperation(value = "Gets information of groups as daily status for a given time range")
    @RequestMapping(value = "/deliveries-trends-range", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getGroupsDailyStatus(@RequestParam("startTime") final Long startTime,

            @RequestParam("endTime") final Long endTime) {
        if (startTime == null || endTime == null) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid URL param: for startTime/endtime");
        } else if (endTime < startTime) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid URL param: 'startTime' should be less than 'endtime'");
        } else if (startTime < 0 || endTime < 0) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid URL param: invalid date range");
        }
        return groupService.getGroupArtifactAndTestwareCountOnDailyBetweenStatusTime(startTime, endTime);
    }

    @ApiOperation(value = "Gets information of group team status")
    @RequestMapping(value = "/deliveries-teams", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getGroupTeamStatus() {
	return groupService.getDeliveredTeams();
    }

    @ApiOperation(value = "Gets information of current activity")
    @RequestMapping(value = "/current-queue-activity", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, Object> getCurrentActivity() {
	return groupService.getCurrentQueueActivity();
    }

    @ApiOperation(value = "Gets trend information of delivery queue")
    @RequestMapping(value = "/delivery-queue-trends", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, Object> getQueueTrends(@RequestParam("startTime") final Long startTime,
	    @RequestParam("endTime") final Long endTime) {
	if (startTime == null || endTime == null) {
	    throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(),
		    "Invalid URL param: for startTime/endtime");
	} else if (endTime < startTime) {
	    throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(),
		    "Invalid URL param: 'startTime' should be less than 'endtime'");
	} else if (startTime < 0 || endTime < 0) {
	    throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid URL param: invalid date range");
	}
	return groupService.getQueueTrendBetweenTime(startTime, endTime);
    }

    @ApiOperation(value = "Gets total count for group artifacts and testware ")
    @RequestMapping(value = "/group-counts", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, Object> getTotalCountsForArtifactGroupAndTestware(
	    @RequestParam("startTime") final Long startTime, @RequestParam("endTime") final Long endTime,
	    @RequestParam(required = true, value = "status") final String status) {
	if (status.trim().isEmpty()) {
	    throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid URL param: for status");
	} else if (startTime == null || endTime == null) {
	    throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(),
		    "Invalid URL param: for startTime/endtime");
	} else if (endTime < startTime) {
	    throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(),
		    "Invalid URL param: 'startTime' should be less than 'endtime'");
	} else if (startTime < 0 || endTime < 0) {
	    throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid URL param: invalid date range");
	}
	return groupService.getTotalCountForDeliveries(startTime, endTime, status);
    }

    @ApiOperation(value = "Gets information for the profile deliveries chart")
    @RequestMapping(value = "/queue-profile-deliveries", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> geQueueProfileActivities(
	    @RequestParam(required = false, value = "from") final String startSprint,
	    @RequestParam(required = false, value = "to") final String endSprint) {
	
	return groupService.getProfileActivities(startSprint, endSprint);
    }
        
	@ApiOperation(value = "Gets information of current waiting queue")
	@RequestMapping(value = "/current-waiting-queue", method = RequestMethod.GET)
	@ResponseStatus(value = HttpStatus.OK)
	public @ResponseBody List<Group> getCurrentWaitingQueue() {
		return groupService.getCurrentWaitingQueue();
	}
}
