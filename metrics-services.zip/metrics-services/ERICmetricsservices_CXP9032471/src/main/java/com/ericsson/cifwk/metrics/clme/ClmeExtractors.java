/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.clme;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.joda.time.format.DateTimeFormat;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Component;

@Component
public class ClmeExtractors {

    private static final String DELIVERY_COUNT = "deliveryCount";
    private static final String WEEK_DAY = "weekDay";
    private static final String DATE_STRING = "dateString";
    private static final String DAILY = "daily";

    public ResultsExtractor<Integer> getQueryResultCountExtractor() {
        return new ResultsExtractor<Integer>() {
            @Override
            public Integer extract(final SearchResponse response) {
                return (int) response.getHits().getTotalHits();
            }
        };
    }

    public ResultsExtractor<List<Map<String, Object>>> getDeliveryVOExtractor() {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
                final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final Aggregations aggregations = response.getAggregations();
                final DateHistogram daily = aggregations.get(DAILY);
                @SuppressWarnings("unchecked")
                final List<DateHistogram.Bucket> buckets = (List<DateHistogram.Bucket>) daily
                        .getBuckets();
                for (final DateHistogram.Bucket bucket : buckets) {
                    final int deliveryCount = (int) bucket.getDocCount();
                    final String dateString = bucket.getKeyAsText().string();
                    final String weekDay = DateTimeFormat.forPattern("EEEE").print(bucket.getKeyAsDate());
                    final Map<String, Object> map = new HashMap<String, Object>() {
                        private static final long serialVersionUID = -4908911391050681159L;
                        {
                            put(DATE_STRING, dateString);
                            put(WEEK_DAY, weekDay);
                            put(DELIVERY_COUNT, deliveryCount);
                        }
                    };
                    maps.add(map);
                }
                return maps;
            }
        };
    }

    public ResultsExtractor<List<Map<String, Object>>> getMteTrendAggregation() {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
                final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final String drop = "drop";
                final String result = "result";
                final String sprint = "sprint";
                final String total = "total";
                final Terms dropTerms = response.getAggregations().get(drop);
                final Collection<Terms.Bucket> buckets = dropTerms.getBuckets();
                for (final Bucket dropBucket : buckets) {
                    final Terms resultTerms = dropBucket.getAggregations().get(result);
                    final Map<String, Object> map = new HashMap<>();
                    map.put(sprint, dropBucket.getKey());
                    map.put(total, dropBucket.getDocCount());
                    map.putAll(resultTerms.getBuckets().stream().collect(Collectors.toMap(Bucket::getKey, Bucket::getDocCount)));
                    maps.add(map);
                }
                return maps;
            }
        };
    }
}
