
package com.ericsson.cifwk.metrics.clme;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
@Api(value = "/clme",
        description = "Resource for obtaining information related to Confidence Level Modified Events such as ISO and deliveries details")
public class ClmeEndPoint {

    @Autowired
    private ClmeService clmeService;

    @ApiOperation(value = "Gets the number of deliveries for today")
    @RequestMapping(value = "/delivery-today", method = RequestMethod.GET)
    public @ResponseBody Map<String, Integer> getDeliveredCountForToday() {
        return clmeService.getDeliveriesForToday();
    }

    @ApiOperation(value = "Gets a list of deliveries information in the sprint")
    @RequestMapping(value = "/delivery-sprint-status", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getDeliveredCountTillToday(final String sprint) {
        return clmeService.getDeliveryDetailsForSprint(sprint);
    }

    /**
     * @deprecated this is deprecated , replaced by {@link #getRadiatorIsoDetails(String)}
     */
    @Deprecated
    @ApiOperation(value = "Gets a top 4 list of latest ISO maintrack details")
    @RequestMapping(value = "/isoRadiator-details", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<ISOMaintrackVO> getMaintrackRadiatorIsoDetails() {
        return clmeService.getMaintrackRadiatorIsoDetails();
    }

    /**
     * @deprecated this is deprecated , replaced by {@link #getRadiatorIsoDetails(String)}
     */
    @Deprecated
    @ApiOperation(value = "Gets a top 10 list of latest ISO maintrack details in last 3 weeks")
    @RequestMapping(value = "/mtetable-details", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<ISOMaintrackVO> getMaintrackDetails() {
        return clmeService.getMaintrackTableDetails();
    }


    @ApiOperation(
            value = "Gets Cloud KGB (represented by the highest ISO revision that has passed the maintrack entry loop which don't have caution status)")
    @RequestMapping(value = "/kgb-cloud", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody
            Map<String, String> getMaintrackRadiatorCloudKGB() {
        return clmeService.getMaintrackRadiatorISOForCloudKGB();
    }
    
    @ApiOperation(
            value = "Gets Cloud KGB (represented by the highest ISO revision that has passed the maintrack entry loop which don't have caution status)")
    @RequestMapping(value = "/micro-ii-kgb", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody
            Map<String, String> getMaintrackRadiatorMicroENM() {
        return clmeService.getMaintrackRadiatorISOForMicroENM();
    }

    @ApiOperation(value = "Gets Maintrack radiator ISO information for current RVB")
    @RequestMapping(value = "/rvb-current", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, String> getMaintrackRadiatorCurrentRVB() {
        return clmeService.getMaintrackRadiatorISOForCurrentRVB();
    }

    @ApiOperation(value = "Gets Maintrack radiator ISO information for baseline  RVB")
    @RequestMapping(value = "/rvb-baseline", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, String> getMaintrackRadiatorBaselineRVB() {
        return clmeService.getMaintrackRadiatorISOForBaselineRVB();
    }

    @ApiOperation(value = "Gets a top 4 list for radiator and 30 for mte table of latest ISO maintrack details")
    @RequestMapping(value = "/isoMtRadiator-details", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<ISOMaintrackVO> getRadiatorIsoDetails(@RequestParam(required = false, value = "details") final String details) {
        return clmeService.getMTRadiatorIsoDetails(details);
    }

    @ApiOperation(value = "Gets Sprint wise MTE-P trend ")
    @RequestMapping(value = "/mtep-sprint-trend", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getMtePhysicalTrendBySprint(@RequestParam(required = false, value = "from") final String from,
            @RequestParam(required = false, value = "to") final String to) {
        return clmeService.getMTEPhysicalTrendBySprint(from, to);
    }
    
    @ApiOperation(value = "Get all Maintrack test loops")
    @RequestMapping(value = "/maintrack-testloops", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<String> getMaintrackTestLoops() {
        return clmeService.getAllMaintrackTestLoops();
    }
    
    @ApiOperation(value = "Gets List of map with duration of differnt loops in a test flow based by iso ")
    @RequestMapping(value = "/release-flow", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getTestTimeLoopDetailsByIso(@RequestParam(required = false, value = "from") final String from,
            @RequestParam(required = false, value = "to") final String to) {
        return clmeService.getTestTimeLoopDetailsByIso(from, to);
    }

    @ApiOperation(value = "Gets List of iso versions based on sprint or without sprint restriction ")
    @RequestMapping(value = "/iso-versions", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<String> getIsoVersionList(@RequestParam(required = true, value = "drop") final String drop) {
        return clmeService.getIsoVersionList(drop);
    }

    @ApiOperation(value = "Gets List of iso versions based on sprint or without sprint restriction ")
    @RequestMapping(value = "/team-profile", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getTeamProfileBwtweenEventTime(@RequestParam(required = true, value = "team") final String team,
            @RequestParam(required = false, value = "from") final Long from, @RequestParam(required = false, value = "to") final Long to) {
        return clmeService.getTeamProfileBetweenEventTime(team, from, to);
    }
}
