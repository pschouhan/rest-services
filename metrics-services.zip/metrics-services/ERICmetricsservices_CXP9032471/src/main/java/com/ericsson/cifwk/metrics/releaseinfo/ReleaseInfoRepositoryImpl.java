/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.releaseinfo;

import java.util.List;

import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;

@Repository
public class ReleaseInfoRepositoryImpl implements ReleaseInfoRepository {

	private String index = "release";

	private String type = "releaseinfo";

	@Autowired
	private ElasticsearchTemplate elasticsearchTemplate;

	@Override
	public List<ReleaseInfo> getReleaseInfo() {
		final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
				.withSort(SortBuilders.fieldSort("timestamp").order(SortOrder.DESC)).build();

		return elasticsearchTemplate.queryForList(query, ReleaseInfo.class);
	}

}
