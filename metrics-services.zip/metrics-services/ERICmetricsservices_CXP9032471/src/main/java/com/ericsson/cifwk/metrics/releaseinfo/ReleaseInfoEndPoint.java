/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.releaseinfo;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.ApiOperation;

@Controller
public class ReleaseInfoEndPoint {

	@Autowired
	private ReleaseInfoService releaseInfoService;

	@ApiOperation(value = "Coutdown for RFA, RFS and GA")
	@RequestMapping(value = "/release-milestone", method = RequestMethod.GET)
	public @ResponseBody List<ReleaseInfoVO> getDeliveredCountForToday() {
		return releaseInfoService.getCoutdownInfo();
	}

}
