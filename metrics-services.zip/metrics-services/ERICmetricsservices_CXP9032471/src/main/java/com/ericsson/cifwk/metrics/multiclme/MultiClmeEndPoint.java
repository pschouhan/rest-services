/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.multiclme;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class MultiClmeEndPoint {
	
    @Autowired
    private MultiClmeService multiClmeService;
    
    @ApiOperation(value = "Gets a top 4 list of latest ISO maintrack details")
    @RequestMapping(value = "/Maintrack-Radiator", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<ISOMaintrackVO> getMaintrackRadiatorIsoDetails(@RequestParam(required = false, value = "details") final String details) {
        return multiClmeService.getMaintrackRadiatorIsoDetails(details);
    	}
    
    @ApiOperation(value = "Gets the success status of deploy_enm_ug_status")
    @RequestMapping(value = "/ug-status", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, Integer> getUGStatusDetails() {
    	return multiClmeService.getDeploy_ENM_UG_status();
    }
    
    @ApiOperation(value = "Gets Physical KGB (represented by the highest ISO revision that has passed the maintrack entry loop)")
    @RequestMapping(value = "/kgb-physical", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, String> getMaintrackRadiatorKGB() {
    	return multiClmeService.getMaintrackRadiatorISOForKGBPhysical();
    }

    @ApiOperation(value = "Gets Physical II KGB based on highest product set without caution status")
    @RequestMapping(value = "/physical-ii-kgb", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, String> getMaintrackRadiatorPhysicalII() {
        return multiClmeService.getMaintrackRadiatorISOForKGBPhysicalII();
    }
    
    @ApiOperation(value = "Gets Micro ENM II KGB based on highest product set without caution status")
    @RequestMapping(value = "/micro-ii", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody Map<String, String> getMaintrackRadiatorMicroENMII() {
        return multiClmeService.getMaintrackRadiatorISOForMicroENMII();
    }

    @ApiOperation(value = "Gets Sprint wise MTE-P trend ")
    @RequestMapping(value = "/maintrack-testruns-trends", method = RequestMethod.GET)
    @ResponseStatus(value = HttpStatus.OK)
    public @ResponseBody List<Map<String, Object>> getMtePhysicalTrendBySprint(@RequestParam(required = false, value = "from") final String from,
            @RequestParam(required = false, value = "to") final String to, @RequestParam(required = false, value = "testLoop") String testLoop) {
        return multiClmeService.getMTEPhysicalTrendBySprint(from, to, testLoop);
    }

}
