/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.exception;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

public class MetricsServiceException extends RuntimeException {

	private static final long serialVersionUID = 5122596700297845065L;

	private final Integer statusCode;

	public MetricsServiceException(final Integer statusCode,
			final String message) {
		super(message);
		this.statusCode = statusCode;
	}

	public MetricsServiceException(final String message, final Exception e) {
		super(message, e);
		statusCode = INTERNAL_SERVER_ERROR.value();
	}

	public MetricsServiceException(final String message) {
		super(message);
		statusCode = INTERNAL_SERVER_ERROR.value();
	}

	public Integer getStatusCode() {
		return statusCode;
	}
}
