
package com.ericsson.cifwk.metrics.sprint;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface SprintRepository extends ElasticsearchRepository<Sprint, String> {

    public Sprint findByName(final String name);

    /**
     * Returns Only Sprints that finished or ongoing till the given time, this method excludes future sprints
     *
     * @param timeInMillies
     * @param pageable
     * @return list of sprints
     */
    @Query("{\"bool\":{\"must\":[{\"range\": {\"startDate\": {\"lte\":?0}}}]}}")
    public List<Sprint> findByDateTimeTillToday(final long timeInMillies, final Pageable pageable);

    /**
     * Returns all the sprint between the given time range
     *
     * @param startTimeInMillies
     * @param endTimeInMillies
     * @param pageable
     * @return list of sprints
     */
    @Query("{\"bool\":{\"must\":[{\"range\": {\"startDate\": {\"lte\":?0,\"gte\":?1}}}]}}")
    public List<Sprint> findBetweenTime(final long startTimeInMillies, final long endTimeInMillies, final Pageable pageable);

    /**
     * Return the current sprint entity in given time
     *
     * @param timeInMillies
     *            current time in milliseconds
     * @return
     */
    @Query("{\"bool\":{\"must\":[{\"range\": {\"startDate\": {\"lte\":?0}}},{\"range\": {\"endDate\": {\"gte\":?0}}}]}}")
    public Sprint findFirstByDateTime(final long timeInMillies);

}
