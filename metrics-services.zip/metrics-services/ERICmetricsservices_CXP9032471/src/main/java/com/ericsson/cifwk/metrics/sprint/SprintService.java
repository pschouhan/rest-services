/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.sprint;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import java.lang.*;


import org.elasticsearch.common.lang3.ObjectUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.exception.MetricsServiceException;
import com.google.common.base.Strings;

@Service
public class SprintService {

    private static final String TODAY = "today";

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private static final String DAYS_FINISHED = "daysFinished";
    private static final String DAYS_REMAINING = "daysRemaining";
    private static final String DURATION = "duration";
    private static final String END = "end";
    private static final String START = "start";
    private static final String SPRINT = "sprint";
    private static final String COMMITTED_POINTS = "committedPoints";
    private static final String COMPLETED_POINTS = "completedPoints";
    private static final String START_DATE = "startDate";
    private static final String SUCCESSFUL = "Successful\n";

    @Autowired
    private SprintRepository sprintRepository;

    @Autowired
    private ServerDateTime serverDateTime;

    /**
     * Obtains and calculates the Current Sprint details:
     * sprint name, sprint duration (in days), start & end date, and sprint remaining and sprint elapsed days.
     *
     * @return Sprint details information object.
     */
    public Map<String, String> getCurrentSprintDetails() {
        final Sprint sprint = getCurrentSprint();
        logger.debug("Current Sprint:{}", sprint);
        final DateTime startDateTime = new DateTime(sprint.getStartTimeInMillis(), DateTimeZone.UTC);
        final DateTime endDateTime = new DateTime(sprint.getEndTimeInMillis(), DateTimeZone.UTC);
        final DateTime currentTime = serverDateTime.getCurrentDateTime();
        final long startDate = startDateTime.getMillis();
        final long endDate = endDateTime.getMillis();
        final int daysRemaining = Days.daysBetween(currentTime, endDateTime).getDays();
        // +1 is given to include the current days
        final int daysFinished = Days.daysBetween(startDateTime, currentTime).getDays() + 1;
        // +1 is given to include the finishing start day in duration
        final int duration = Days.daysBetween(startDateTime, endDateTime).getDays() + 1;
        final double committedPoints = sprint.getCommittedPoints();
        final double completedPoints = sprint.getCompletedPoints();
        final DateTimeFormatter dtf = DateTimeFormat.forPattern("dd/MM/yyyy");
        final Map<String, String> map = new HashMap<String, String>() {
            private static final long serialVersionUID = 3992371105056124581L;
            {
                put(SPRINT, sprint.getName());
                put(START, String.valueOf(startDate));
                put(END, String.valueOf(endDate));
                put(DURATION, String.valueOf(duration));
                put(DAYS_REMAINING, String.valueOf(daysRemaining));
                put(DAYS_FINISHED, String.valueOf(daysFinished));
                put(TODAY, dtf.print(currentTime));
                put(COMMITTED_POINTS, String.valueOf(committedPoints));
                put(COMPLETED_POINTS, String.valueOf(completedPoints));
            }
        };
        logger.debug("Sprint information as map : {}", map);
        return map;
    }
    
	/**
	 * Obtains a Sprint object with details on a given sprint name
	 *
	 * @param sprintName
	 * @return Sprint
	 */
	public Sprint getSprintDetails(final String sprintName) {
		if (Strings.isNullOrEmpty(sprintName)) {
			logger.debug("Going to load Default Sprint Current Sprint");
			return getCurrentSprint();
		}
		final Sprint sprint = sprintRepository.findByName(sprintName);
		if (sprint == null) {
			// if failed to find the sprint details with given name
			throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Can't find given sprint name");
		}
		return sprint;
	}

    /**
     * Returns Only Sprint that finished or ongoing till the current time, this method excludes future sprints
     *
     * @return <code>List</code> of sprints
     */
    public List<Sprint> getSprintDetailsTillToday() {
        final long currentTimeInMilles = serverDateTime.getCurrentDateTime().getMillis();
        // To make a Pageable request we should provide size of the page , so here a safe size is been given as 500
        // TODO : investigate about how to achieve the same functionality without using paging
        return sprintRepository.findByDateTimeTillToday(currentTimeInMilles,
            new PageRequest(0, 500, new Sort(Direction.DESC, "startDate")));
    }
    
	/**
	 * Obtains a List of Sprints with details on a given sprint range
	 *
	 * @param startingSprint
	 * @param endingSprint
	 * @return <code>List</code> of sprints
	 */
	public List<Sprint> getSprintDetailsBySprintRange(
			final String startingSprint, final String endingSprint) {
		if (Strings.isNullOrEmpty(startingSprint) && Strings.isNullOrEmpty(endingSprint)) {
			logger.debug("Going to load Default Sprint Range Data");
			// both params should be null for default condition
			return getDefaultSprintRange();
		} else if (Strings.isNullOrEmpty(startingSprint) || Strings.isNullOrEmpty(endingSprint)) {
			throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid sprint range has been provided");
		}
		final Sprint startSprint = sprintRepository.findByName(startingSprint);
		final Sprint endSprint = sprintRepository.findByName(endingSprint);
		if (startSprint == null || endSprint == null) {
			// if failed to find the sprint details with given names
			throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Can't find given sprint names ");
		} else if (startSprint.getStartTimeInMillis() > endSprint
				.getEndTimeInMillis()) {
			throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Undefined/Incorrect Sprint range");
		}
		return sprintRepository.findBetweenTime(endSprint.getStartTimeInMillis(), startSprint.getStartTimeInMillis(),
            new PageRequest(0, Integer.MAX_VALUE, new Sort(Direction.ASC, START_DATE)));
	}

	private List<Sprint> getDefaultSprintRange() {
		final int defaultLimit = 5;
		final List<Sprint> sprints = sprintRepository.findByDateTimeTillToday(
            serverDateTime.getCurrentDateTime().getMillis(),
            new PageRequest(0, defaultLimit, new Sort(Direction.DESC, START_DATE)));
		final List<Sprint> sortedSprint = new ArrayList<>(sprints);
		Collections.reverse(sortedSprint);
		return sortedSprint;
	}

    /**
     * Create a sprint with given details
     *
     * @param sprint
     * @throws Exception
     *             if sprint cannot be found by its name in the repository or the sprint details are invalid
     */
    public String createSprint(final Sprint sprint) {
        if (!sprint.isValidSprint()) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "The give sprint details is incomplete or corrupted");
        }
        verifyDateRange(sprint);
        if (sprintRepository.findByName(sprint.getName()) != null) {
            throw new MetricsServiceException(HttpStatus.CONFLICT.value(), "Sprint " + sprint.getName() + " already exists");
        }
        sprintRepository.save(sprint);
        return SUCCESSFUL;
    }

    private void verifyDateRange(Sprint sprint) {
        Iterable<Sprint> sprints = sprintRepository.findAll();
        sprints.forEach(item -> {
            try {
                DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
                Date existingStartDate = format.parse(item.getStartDate());
                Date existingEndDate = format.parse(item.getEndDate());
                Date newStartDate = format.parse(sprint.getStartDate());
                Date newEndDate = format.parse(sprint.getEndDate());
                if ((newStartDate.after(existingStartDate) && newStartDate.before(existingEndDate)) && !sprint.getName()
                    .equals(item.getName())) {
                    throw new MetricsServiceException(HttpStatus.CONFLICT.value(),
                        "Invalid date range, overlaps with sprint " + item.getName());
                }
                if ((newEndDate.after(existingStartDate) && newEndDate.before(existingEndDate)) && !sprint.getName()
                    .equals(item.getName())) {
                    throw new MetricsServiceException(HttpStatus.CONFLICT.value(),
                        "Invalid date range, overlaps with sprint " + item.getName());
                }

                if ((existingStartDate.after(newStartDate) && existingStartDate.before(newEndDate)) && !sprint.getName()
                    .equals(item.getName())) {
                    throw new MetricsServiceException(HttpStatus.CONFLICT.value(),
                        "Invalid date range, overlaps with sprint " + item.getName());
                }

                if ((existingEndDate.after(newStartDate) && existingStartDate.before(newEndDate)) && !sprint.getName()
                    .equals(item.getName())) {
                    throw new MetricsServiceException(HttpStatus.CONFLICT.value(),
                        "Invalid date range, overlaps with sprint " + item.getName());
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Update the sprint with given name
     *
     * @param name
     *            of sprint to updated
     * @param sprint
     *            object with all properties
     * @throws Exception
     *             if sprint cannot be found by its name in the repository or the sprint details are invalid
     */
    public String updateSprint(final String name, final Sprint sprint) {
        // There is no direct update method in repository , so first find the existing document
        // Validating the updated sprint details are correct or not
        if (!sprint.isValidSprint() || ObjectUtils.notEqual(name, sprint.getName())) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "The give sprint details is incomplete or corrupted");
        }
        verifyDateRange(sprint);
        final Sprint dbSprint = sprintRepository.findByName(name);
        if (dbSprint == null) {
            throw new MetricsServiceException(HttpStatus.NOT_FOUND.value(), "Can't find the sprint with name " + name);
        }
        // There is no direct way to update elastic search index through spring elastic search repo so first delete the existing one and insert it as
        // a new entry . Delete the existing document
        sprintRepository.delete(dbSprint);
        // Saving the updated details as new entry
        sprintRepository.save(sprint);
        return SUCCESSFUL;
    }

    /**
     * Delete sprint with given name
     *
     * @param name
     *            of sprint
     * @throws Exception
     *             if sprint cannot be found by its name in the repository
     */
    public String deleteSprint(final String name) {
        final Sprint dbSprint = sprintRepository.findByName(name);
        if (dbSprint == null) {
            throw new MetricsServiceException(HttpStatus.NOT_FOUND.value(), "Can't find the sprint with name " + name);
        }
        sprintRepository.delete(dbSprint);
        return SUCCESSFUL;
    }

    private Sprint getCurrentSprint() {
        int offset = 24 * 60 * 60 * 1000; //1 day in Milliseconds
        int tries = 10;
        int tryCount = 0;
        Long currentTimeInMilliseconds = serverDateTime.getCurrentDateTime().getMillis();
        Sprint sprint = sprintRepository.findFirstByDateTime(currentTimeInMilliseconds);
        //find closest next sprint
        while (tryCount <= tries && sprint == null) {
            tryCount++;
            sprint = sprintRepository.findFirstByDateTime(currentTimeInMilliseconds + (offset * tryCount));
        }
        tryCount = 0;
        //find closest previous sprint
        while (tryCount <= tries && sprint == null) {
            tryCount++;
            sprint = sprintRepository.findFirstByDateTime(currentTimeInMilliseconds - (offset * tryCount));
        }
        if (sprint == null) {
            throw new MetricsServiceException("Failed to Identify Current Sprint");
        }
        return sprint;
    }

    public String getAllSprints() {
        Sprints ret = new Sprints();
        Iterable<Sprint> sprints = sprintRepository.findAll();
        sprints.forEach(item -> {
            ret.addSprint(item.getName(),item.getRelease(), item.getStartDate(), item.getEndDate());
        });
        return ret.allSprints;

    }

    public List<Sprint> getSprintDetailsForXSprintsTillToday(int size) {
        final long currentTimeInMilles = serverDateTime.getCurrentDateTime().getMillis();
        return sprintRepository.findByDateTimeTillToday(currentTimeInMilles,
            new PageRequest(0, size, new Sort(Direction.DESC, "startDate")));
    }

}
