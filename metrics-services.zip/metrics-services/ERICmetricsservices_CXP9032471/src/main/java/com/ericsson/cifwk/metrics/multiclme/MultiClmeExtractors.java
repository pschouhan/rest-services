/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.multiclme;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms.Bucket;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.stereotype.Component;

@Component
public class MultiClmeExtractors {
    private static final String FAILURE = "FAILURE";
    private static final String SUCCESS = "SUCCESS";

    public ResultsExtractor<List<Map<String, Object>>> getMteTrendAggregation() {
        return new ResultsExtractor<List<Map<String, Object>>>() {
            @Override
            public List<Map<String, Object>> extract(final SearchResponse response) {
                final List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
                final String drop = "drop";
                final String result = "result";
                final String sprint = "sprint";
                final String total = "total";
                final Terms dropTerms = response.getAggregations().get(drop);
                final Collection<Terms.Bucket> buckets = dropTerms.getBuckets();
                for (final Bucket dropBucket : buckets) {
                    final Terms resultTerms = dropBucket.getAggregations().get(result);
                    final Map<String, Object> map = new HashMap<>();
                    map.put(sprint, dropBucket.getKey());
                    map.put(total, dropBucket.getDocCount());
                    map.putAll(resultTerms.getBuckets().stream().collect(Collectors.toMap(Bucket::getKey, Bucket::getDocCount)));
                    if (map.get(SUCCESS) == null) {
                        map.put(SUCCESS, 0);
                    }
                    if (map.get(FAILURE) == null) {
                        map.put(FAILURE, 0);
                    }
                    maps.add(map);
                }
                return maps;
            }
        };
    }
}
