
package com.ericsson.cifwk.metrics.scm;

import java.util.List;
import java.util.Map;

import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.FilteredQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;

@Repository
public class ScmRepositoryImpl implements ScmRepository {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static final String TEAMS = "teams";
    private static final String EVENT_TIME = "eventTime";
    private static final String TEAM = "team";

    @Value("${es.index}")
    private String index;

    @Value("${es.index.type.scm}")
    private String type;

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    private ScmExtractors extractors;

    @Override
    public List<Map<String, String>> findTeamPerformanceBetweenTime(final long from, final long to) {
        logger.debug("Team peformance between from:{} to:{}", from, to);
        final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
                FilterBuilders.rangeFilter(EVENT_TIME).from(from).to(to));
        final AggregationBuilder<?> aggregationBuilder = AggregationBuilders.terms(TEAMS).field(TEAM);
        final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
                .withQuery(filteredQuery).addAggregation(aggregationBuilder).withPageable(new PageRequest(0, 10)).build();
        return elasticsearchTemplate.query(query, extractors.getTeamPerformanceExtractor());
    }

    @Override
    public int findCommitDetailsBetweenTime(final long from, final long to) {
        logger.debug("Commit Details between from:{} to:{}", from, to);
        final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(),
                FilterBuilders.rangeFilter(EVENT_TIME).from(from).to(to));
        final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type)
                .withQuery(filteredQuery).build();
        return (int) elasticsearchTemplate.count(query);
    }

}
