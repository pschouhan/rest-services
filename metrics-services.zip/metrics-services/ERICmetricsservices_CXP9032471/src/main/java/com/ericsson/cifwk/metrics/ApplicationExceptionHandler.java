/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2015
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics;

import static org.springframework.http.ResponseEntity.status;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.ericsson.cifwk.metrics.exception.MetricsServiceException;

/**
 * Handles exceptions from the application.
 */
@ControllerAdvice
public class ApplicationExceptionHandler {

    private static final String ERROR = "error";

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @ExceptionHandler(MetricsServiceException.class)
    public ResponseEntity<Map<String, Object>> defaultErrorHandler(final HttpServletRequest req, final MetricsServiceException e)
            throws Exception {
        logger.info(e.getMessage());
        return status(e.getStatusCode()).body(getResponseError(e));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> defaultErrorHandler(final HttpServletRequest req, final Exception e) throws Exception {
        logger.error(e.getMessage(), e);
        return status(500).body(getResponseError(e));
    }

    private Map<String, Object> getResponseError(final Exception e) {
        return new HashMap<String, Object>() {
            private static final long serialVersionUID = 1L;
            {
                put(ERROR, e.getMessage());
            }
        };
    }
}
