/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.multiclme;

import java.util.*;

import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.exception.MetricsServiceException;
import com.ericsson.cifwk.metrics.sprint.Sprint;
import com.ericsson.cifwk.metrics.sprint.SprintRepository;
import com.google.common.base.Strings;

@Service
public class MultiClmeService {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static final int MTG_RADIATOR_LIMIT = 4;
    private static final int MTG_MTE_LIMIT = 10;
    private static final int defaultLimit = 2;
    private static final String START_DATE = "startDate";
    private static final String URL_REGEX = "\\b(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";
    private static final String DROP = "drop";
    private static final String CURRENT_ISO_KGB_PHYSICAL = "currentIsoKGBPhysical";
    private static final String CURRENT_PRODUCT_KGB_PHYSICAL = "currentProductKGBPhysical";
    private static final String CURRENT_PRODUCT_II_PHYSICAL = "physicalIIKGB";
    private static final String CURRENT_PRODUCT_MICRO_ENM_II = "microIIKGB";
    private static final String DEPLOY_UG_STATUS = "ugSuccessStatus";
    private static final String MESSAGE_NO_KGB = "Not Set";
    //private static final String MESSAGE_NO_UG = "Not Set";
    private static final String MTE = "mte";
    private static final int MTG_MTE_ALLURE_LIMIT = 30;
    private static final String SPRINT_REGEX = "[0-9]+(\\.[0-9]+)";
	


    @Value("${product}")
    private String product;

    @Autowired
    private MultiClmeRepository multiClmeRepository;

    @Autowired
    private SprintRepository sprintRepository;

    @Autowired
    private ServerDateTime serverDateTime;
    
    /**
     * Obtains a map with details of MTE-P loops trends on a given sprint range
     *
     * @param startingSprint
     * @param endingSprint
     * @return List of map with MTE physical trend information
     */
    public List<Map<String, Object>> getMTEPhysicalTrendBySprint(
            final String startingSprint, final String endingSprint,
            final String loop) {
        final String loopWithStatus = loop + "_status";
        if (Strings.isNullOrEmpty(startingSprint)
                && Strings.isNullOrEmpty(endingSprint)) {
            logger.debug("Going to load Default Sprint Range Trend Data");
            // both params should be null for default condition
            return sortMTETrendByDrop(defaultMTEPhysicalTrendBySprint());
        } else if (Strings.isNullOrEmpty(startingSprint)
                || Strings.isNullOrEmpty(endingSprint)) {
            throw new MetricsServiceException(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Invalid sprint range has been provided");
        }
        // Pattern to match sprint names
        if (!matchPattern(startingSprint, SPRINT_REGEX)
                || !matchPattern(endingSprint, SPRINT_REGEX)) {
            // If sprint names doesn't follow pattern
            throw new MetricsServiceException(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Invalid sprint names");
        }

        final Sprint startSprint = sprintRepository.findByName(startingSprint);
        final Sprint endSprint = sprintRepository.findByName(endingSprint);
        if (startSprint == null || endSprint == null) {
            // if failed to find the sprint details with given names
            throw new MetricsServiceException(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Can't find given sprint names ");
        } else if (startSprint.getStartTimeInMillis() > endSprint
                .getEndTimeInMillis()) {
            throw new MetricsServiceException(
                    HttpStatus.INTERNAL_SERVER_ERROR.value(),
                    "Undefined/Incorrect Sprint range");
        }

        return sortMTETrendByDrop(getMTEPhysicalTrendBySprint(startSprint,
                endSprint, loopWithStatus));
    }

    private List<Map<String, Object>> sortMTETrendByDrop(final List<Map<String, Object>> trends) {
        return trends.stream().sorted(new Comparator<Map<String, Object>>() {
            @Override
            public int compare(final Map<String, Object> o1, final Map<String, Object> o2) {
                final String sprint = "sprint";
                final String[] sprintArray1 = o1.get(sprint).toString().split("\\.");
                final String[] sprintArray2 = o2.get(sprint).toString().split("\\.");
                if (sprintArray1.length > sprintArray2.length) {
                    return compareValues(sprintArray1, sprintArray2);
                } else {
                    return compareValues(sprintArray2, sprintArray1);
                }
            }
        }.reversed()).collect(Collectors.toList());
    }

    private Integer compareValues(final String[] array1, final String[] array2) {
        for (int i = 0; i < array1.length; i++) {
            final Integer v1 = Integer.parseInt(array1[i]);
            final Integer v2 = Integer.parseInt(array2[i]);
            if (v1 != v2) {
                return v1 - v2;
            }
        }
        return 0;
    }

    public List<ISOMaintrackVO> getMaintrackRadiatorIsoDetails(String details) {
        final List<ISOMaintrackVO> radiatorIsoList = getMaintrackTableDetails();
        int size = 0;
        if (MTE.equalsIgnoreCase(details)) {
            size = radiatorIsoList.size() > MTG_MTE_ALLURE_LIMIT ? MTG_MTE_ALLURE_LIMIT : radiatorIsoList.size();
        } else {
            size = radiatorIsoList.size() > MTG_RADIATOR_LIMIT ? MTG_RADIATOR_LIMIT : radiatorIsoList.size();
        }
        logger.debug("ISO List MainTrack radiator without filtering ", radiatorIsoList.toString());
        return new ArrayList<ISOMaintrackVO>(radiatorIsoList.subList(0, size));
    }
    
    public List<ISOMaintrackVO> getMaintrackTableDetails() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        // find
        final List<MultiClme> mteList = multiClmeRepository.findMTEDetails(startTime, endTime, generateSprintNameList(getSprint(defaultLimit)));
        // remove duplication
        final List<MultiClme> mteFilteredList = new ArrayList<MultiClme>(new HashSet<MultiClme>(mteList));
        // sorts
        Collections.sort(mteFilteredList);
        final List<ISOMaintrackVO> radiatorIsoList = new ArrayList<>();
        final int size = mteFilteredList.size() > MTG_MTE_LIMIT ? MTG_MTE_LIMIT : mteFilteredList.size();
        for (int i = 0; i < size; i++) {
            radiatorIsoList.add(getIsoMaintrackVO(mteFilteredList.get(i)));
        }
        logger.debug("Service retrieving Radiator ISO list:{}", radiatorIsoList.toString());
        return radiatorIsoList;
    }

    private List<Sprint> getSprint(final int defaultLimit) {
        final List<Sprint> sprints =
                sprintRepository.findByDateTimeTillToday(serverDateTime.getCurrentDateTime().getMillis(), new PageRequest(0, defaultLimit, new Sort(
                        Direction.DESC, START_DATE)));
        return sprints;
    }
    
    private Object[] generateSprintNameList(final List<Sprint> sprints) {
        // Mapping Sprint names as object from "Sprint" objects
        logger.debug("Sprint included in range: {}", sprints);
        return sprints.stream().map(new Function<Sprint, String>() {
            @Override
            public String apply(final Sprint t) {
                return t.getName();
            }
        }).collect(Collectors.toList()).toArray();
    }
    
    private ISOMaintrackVO getIsoMaintrackVO(final MultiClme mte) {
        final ISOMaintrackVO isoMaintrackVO = new ISOMaintrackVO();
        isoMaintrackVO.setIsoVersion(mte.getMasterVersion());
        isoMaintrackVO.setWorkingBaseline(mte.getWorkingBaseline());
        isoMaintrackVO.setGroupId(mte.getGroupId());
        isoMaintrackVO.setArtifactId(mte.getArtifactId());
        isoMaintrackVO.setArtifactVersion(mte.getArtifactVersion());
        isoMaintrackVO.setEventTime(mte.getEventTime());
        isoMaintrackVO.setDrop(mte.getDrop());
        isoMaintrackVO.setUg_status(mte.getDeploy_ENM_UG_status());
        isoMaintrackVO.setUg_teAllureLogUrl(checkForEmptyOrNull(mte.getDeploy_ENM_UG_teAllureLogUrl(), URL_REGEX));
        isoMaintrackVO.setUgAvailability_status(mte.getUG_Availability_status());
        isoMaintrackVO.setUgAvailability_teAllureLogUrl(
            checkForEmptyOrNull(mte.getUG_Availability_teAllureLogUrl(), URL_REGEX));
        isoMaintrackVO.setUgPerformance_status(mte.getUG_Performance_status());
        isoMaintrackVO.setUgPerformance_teAllureLogUrl(
            checkForEmptyOrNull(mte.getUG_Performance_teAllureLogUrl(), URL_REGEX));
        isoMaintrackVO.setRfa_status(mte.getRFA_status());
        isoMaintrackVO.setRfa_teAllureLogUrl(checkForEmptyOrNull(mte.getRFA_teAllureLogUrl(), URL_REGEX));
        isoMaintrackVO.setProduct(mte.getProduct());
        return isoMaintrackVO;
    }
    
    private String checkForEmptyOrNull(final String s, final String pattern){
    	if(s != null && matchPattern(s, pattern)){
    		return s;
    	}else{
    		return "";
    	}
    }
    
    private boolean matchPattern(final String s, final String pattern) {
        try {
            final Pattern patt = Pattern.compile(pattern);
            final Matcher matcher = patt.matcher(s);
            return matcher.matches();
        } catch (final RuntimeException e) {
            logger.debug("Pattern {} didn't match {}", pattern, s);
            return false;
        }
    }

    private Map<String, String> getPhysicalKGBAsMap(final List<MultiClme> physicalKGBList) {
        final Map<String, String> map = new HashMap<>();
        if (physicalKGBList.isEmpty()) {
            map.put(CURRENT_ISO_KGB_PHYSICAL, MESSAGE_NO_KGB);
            map.put(CURRENT_PRODUCT_KGB_PHYSICAL, MESSAGE_NO_KGB);
        } else {

            final Set<MultiClme> mteListWithoutDuplications = new HashSet<MultiClme>(physicalKGBList);
            final List<MultiClme> mteFilteredList = new ArrayList<MultiClme>(mteListWithoutDuplications);
            Collections.sort(mteFilteredList);
            for (final MultiClme clme : mteFilteredList) {
                final String physicalIsoMasterVersion = clme.getMasterVersion();
                map.put(CURRENT_ISO_KGB_PHYSICAL, physicalIsoMasterVersion);
                map.put(DROP, clme.getDrop());
                map.put(CURRENT_PRODUCT_KGB_PHYSICAL, clme.getArtifactVersion());
                return map;
            }
            map.put(CURRENT_ISO_KGB_PHYSICAL, MESSAGE_NO_KGB);
            map.put(CURRENT_PRODUCT_KGB_PHYSICAL, MESSAGE_NO_KGB);
            logger.debug("Service retrieving physical KGB:{}", map);
        }
        return map;
    }
    
   private Map<String, Integer> getUGStatusAsMap(final List<MultiClme> mteList) {
        final Map<String, Integer> map = new HashMap<>();
        if (mteList.isEmpty()) {
            map.put(DEPLOY_UG_STATUS, 0);
           } else {

            final List<MultiClme> ugFilteredList = new ArrayList<MultiClme>(mteList);
            for (final MultiClme clme : ugFilteredList) {
                final String ugSuccessStatus = clme.getDeploy_ENM_UG_status();
                System.out.println(ugSuccessStatus);
                
                map.put(DEPLOY_UG_STATUS, ugFilteredList.size());
                return map;
            }
            map.put(DEPLOY_UG_STATUS, 0);
            logger.debug("Service retrieving ug status:{}", map);
        }
        return map;
    } 

    /**
	 * @param ugStatus
	 * @return
	 */
	

	private Map<String, String> getPhysicalKGBIIAsMap(final List<MultiClme> physicalKGBList) {
        final Map<String, String> map = new HashMap<>();
        if (physicalKGBList.isEmpty()) {
            map.put(CURRENT_PRODUCT_II_PHYSICAL, MESSAGE_NO_KGB);

        } else {

            final Set<MultiClme> mteListWithoutDuplications = new HashSet<MultiClme>(physicalKGBList);
            final List<MultiClme> mteFilteredList = new ArrayList<MultiClme>(mteListWithoutDuplications);
            Collections.sort(mteFilteredList);
            for (final MultiClme clme : mteFilteredList) {
                map.put(DROP, clme.getDrop());
                map.put(CURRENT_PRODUCT_II_PHYSICAL, clme.getArtifactVersion());
                
                return map;
            }
            map.put(CURRENT_PRODUCT_II_PHYSICAL, MESSAGE_NO_KGB);
            logger.debug("Service retrieving physical KGB:{}", map);
        }
        return map;
    }
	
	private Map<String, String> getMicroENMIIAsMap(final List<MultiClme> microENMList) {
        final Map<String, String> map = new HashMap<>();
        if (microENMList.isEmpty()) {
            map.put(CURRENT_PRODUCT_MICRO_ENM_II, MESSAGE_NO_KGB);

        } else {

            final Set<MultiClme> mteListWithoutDuplications = new HashSet<MultiClme>(microENMList);
            final List<MultiClme> mteFilteredList = new ArrayList<MultiClme>(mteListWithoutDuplications);
            Collections.sort(mteFilteredList);
            for (final MultiClme clme : mteFilteredList) {
                map.put(DROP, clme.getDrop());
                map.put(CURRENT_PRODUCT_MICRO_ENM_II, clme.getDeploy_ENM_Micro_II_status());
                
                return map;
            }
            map.put(CURRENT_PRODUCT_MICRO_ENM_II, MESSAGE_NO_KGB);
            logger.debug("Service retrieving micro ENM II", map);
        }
        return map;
    }
    /**
     * Obtains Physical KGB from highest ISO revision that has passed the maintrack entry loop considering last 3 weeks.
     *
     * @return Physical Known Good Baseline ISO version. If no data found, Not set message is returned.
     */
    public Map<String, String> getMaintrackRadiatorISOForKGBPhysical() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        final List<MultiClme> mteList = multiClmeRepository.findMaintrackPhysicalKGB(startTime, endTime, generateSprintNameList(getSprint(defaultLimit)));
        return getPhysicalKGBAsMap(mteList);
    }
    
    public Map<String, Integer> getDeploy_ENM_UG_status() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        final List<MultiClme> mteList = multiClmeRepository.findUGStatusDetails(startTime, endTime, generateSprintNameList(getSprint(defaultLimit)));
        return getUGStatusAsMap(mteList);
    }

    public Map<String, String> getMaintrackRadiatorISOForKGBPhysicalII() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        final List<MultiClme> mteList = multiClmeRepository.findMaintrackPhysicalIIKGB(startTime, endTime, generateSprintNameList(getSprint(defaultLimit)));
        return getPhysicalKGBIIAsMap(mteList);
    }
    
    public Map<String, String> getMaintrackRadiatorISOForMicroENMII() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        final List<MultiClme> mteList = multiClmeRepository.findMaintrackMicroENMII(startTime, endTime, generateSprintNameList(getSprint(defaultLimit)));
        return getMicroENMIIAsMap(mteList);
    }                                                                                      

    private List<Map<String, Object>> defaultMTEPhysicalTrendBySprint() {
        final String defaultTestLoop = "deploy_enm_ug_status";
        final int defaultLimit = 5;
        final List<Sprint> sprints =
                sprintRepository.findByDateTimeTillToday(serverDateTime.getCurrentDateTime().getMillis(), new PageRequest(0, defaultLimit, new Sort(
                        Direction.DESC, START_DATE)));
        return getMTEPhysicalTrendBySprint(sprints.stream().reduce((first, second) -> second).get(), sprints.stream().findFirst().get(), defaultTestLoop);
    }

    private List<Map<String, Object>> getMTEPhysicalTrendBySprint(final Sprint start, final Sprint end, final String loopWithStatus) {
        logger.debug("Sprint Range  Start:{} \n End:{}", start, end);
        // Finding sprints between the given sprint range
        final List<Sprint> sprintInRange = sprintRepository.findBetweenTime(end.getStartTimeInMillis(), start.getStartTimeInMillis(),
                new PageRequest(0, Integer.MAX_VALUE, new Sort(Direction.DESC, START_DATE)));
        return multiClmeRepository
                .findMTEPhysicalTrendInDrops(loopWithStatus, generateSprintNameList(sprintInRange));
    }

}
