/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2016
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.sprint;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ericsson.cifwk.metrics.jira.JiraService;

@Component
public class SprintScheduledTask {
    private static final String TOTAL = "total";
    private static final String COMPLETED = "completed";
    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private SprintService service;

    @Autowired
    private JiraService jiraService;

    @Scheduled(cron = "0 0 0/12 * * *")
    public void updateSprintVelocity() {
        final List<Sprint> sprints = service.getSprintDetailsTillToday();
        for (final Sprint sprint : sprints) {
            final Map<String, String> sprintVelocity = jiraService.getTotalAndCompletedVelocityForSprint(sprint.getName());
            sprint.setCommittedPoints(Double.parseDouble(sprintVelocity.get(TOTAL)));
            sprint.setCompletedPoints(Double.parseDouble(sprintVelocity.get(COMPLETED)));
            service.updateSprint(sprint.getName(), sprint);
            logger.debug("Scheduled Sprint Velocity Update performed for Sprint: {}", sprint.getName());
        }
    }
}
