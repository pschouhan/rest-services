/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2016
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.team;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Mapping;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Document(indexName = "ci-events", type = "teams")
@Mapping(mappingPath = "/team-mapping.json")
public class Team {
	@Id
	@JsonIgnore
	private String id;

	private String parentElement;

	private String team;

	private List<String> artifacts;

	public List<String> getArtifacts() {
		return artifacts;
	}

	public void setArtifacts(final List<String> artifacts) {
		this.artifacts = artifacts;
	}

	public Team() {
	}

	public String getTeam() {
		return team;
	}

	public String getParentElement() {
		return parentElement;
	}

	public void setTeam(final String team) {
		this.team = team;
	}

	public void setParentElement(final String parentElement) {
		this.parentElement = parentElement;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ( team == null ? 0:team.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Team other = (Team) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}
}
