/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.portaldrop;

import java.util.List;

import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;

@Repository
public class PortalDropRepositoryImpl implements PortalDropRepository {
    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static final String COMPONENT_TYPE = "componentType";
    private static final String PRODUCT = "product";
    private static final String DROP = "Drop";
    private static final String EVENT_TIME = "eventTime";

    @Value("${es.index}")
    private String index;

    @Value("${es.index.type.portaldrop}")
    private String type;

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Override
    public List<PortalDrop> findFirstByDropAndProduct(final String drop, final String product) {
        logger.debug("Portal Status for Drop:{} ,Product:{}", drop, product);

        final BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery()
                .must(QueryBuilders.termQuery(PRODUCT, product))
                .must(QueryBuilders.termQuery(DROP.toLowerCase(), drop))
                .must(QueryBuilders.termQuery(COMPONENT_TYPE, DROP));

        final SearchQuery query = new NativeSearchQueryBuilder().withIndices(index).withTypes(type).withQuery(queryBuilder).
                withPageable(new PageRequest(0, 1)).withSort(SortBuilders.fieldSort(EVENT_TIME).order(SortOrder.DESC)).build();
        return elasticsearchTemplate.queryForList(query, PortalDrop.class);
    }
}
