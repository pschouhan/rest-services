
package com.ericsson.cifwk.metrics.clme;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ericsson.cifwk.metrics.clme.Clme.MessageType;
import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.exception.MetricsServiceException;
import com.ericsson.cifwk.metrics.sprint.Sprint;
import com.ericsson.cifwk.metrics.sprint.SprintRepository;
import com.google.common.base.Strings;

@Service
public class ClmeService {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private static final String MASTER_VERSION = "masterVersion";
    private static final String DROP = "drop";
    private static final int MTG_RADIATOR_LIMIT = 4;
    private static final int MTG_MTE_LIMIT = 10;
    private static final int MTG_MTE_ALLURE_LIMIT = 30;
    private static final int defaultLimit = 2;
    private static final String DELIVERIES_TODAY = "deliveriesToday";
    private static final String CURRENT_ISO_KGB_PHYSICAL = "currentIsoKGBPhysical";
    private static final String CURRENT_PRODUCT_KGB_PHYSICAL = "currentProductKGBPhysical";
    private static final String MESSAGE_NO_KGB = "Not Set";
    private static final String FAILURE = "FAILURE";
    private static final String PROGRESS = "IN PROGRESS";
    private static final String SUCCESS = "SUCCESS";
    private static final String CURRENT_NODES = "currentNodes";
    private static final String CURRENT_STATUS = "currentStatus";
    private static final String BASELINE_NODES = "baselineNodes";
    private static final String BASELINE_RVB_ISO_VERSION = "baselineRVBIsoVersion";
    private static final String BASELINE_RVB_PRODUCT_VERSION = "baselineRVBProductVersion";
    private static final String BASELINE_STATUS = "baselineStatus";
    private static final String CURRENT_ISO_KGB_CLOUD = "currentIsoKGBCloud";
    private static final String CURRENT_PRODUCT_KGB_CLOUD = "currentProductKGBCloud";
    private static final String CURRENT_ISO_MICRO_ENM = "currentIsoMicroENM";
    private static final String CURRENT_PRODUCT_MICRO_ENM = "microIIKGB";
    private static final String CURRENT_RVB_ISO_VERSION = "currentRVBIsoVersion";
    private static final String CURRENT_RVB_PRODUCT_VERSION = "currentRVBProductVersion";
    private static final String PHYSICAL_II_KGB = "physicalIIKGB";
    private static final String MTE = "mte";
    private static final String SPRINT_REGEX = "[0-9]+(\\.[0-9]+)";
    private static final String URL_REGEX = "\\b(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";
    private static final String START_DATE = "startDate";
    private static final String MTE_CL_COMPLETED = "CDB_MTE-P_COMPLETED";
    private static final String RFA_CL_COMPLETED = "CDB_RFA_COMPLETED";
    private static final String RVB_CL_COMPLETED = "CDB_MTE-RVB_COMPLETED";
    private static final String DEPLOY_COMPLETED = "CDB_ENM_DEPLOY_COMPLETED";
    private static final String ISO_BUILD_COMPLETED = "CDB_ISO_BUILD_COMPLETED";
    private static final String DURATION = "duration";
    private static final String START_TIME = "startTime";
    private static final String FINISHED_TIME = "finishedTime";
    private static final String VERSION_REGEX = "[0-9]+(\\.[0-9]+)+(\\.[0-9]+)";

    @Value("${product}")
    private String product;
    
    @Value("${testloop.ug}")
    private String ug;
    
    @Value("${testloop.rfa250}")
    private String rfa;
    
    @Value("${testloop.ugAvailability}")
    private String ugAvailability;
    
    @Value("${testloop.ugPerformance}")
    private String ugPerformance;

    @Autowired
    private ClmeRepository clmeRepository;

    @Autowired
    private SprintRepository sprintRepository;

    @Autowired
    private ServerDateTime serverDateTime;

    /**
     * Obtains the number of today's deliveries.
     *
     * @return number of what have been delivered today.
     */
    public Map<String, Integer> getDeliveriesForToday() {
        final long startOfDay = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay().getMillis();
        final long endOfDay = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay().plusDays(1).minusMillis(1).getMillis();
        final int deliveriesToday =
                clmeRepository.findDeliveriesForTodayByDropAndProduct(startOfDay, endOfDay, getCurrentSprint().getName(), product);
        final Map<String, Integer> map = new HashMap<>();
        map.put(DELIVERIES_TODAY, deliveriesToday);
        logger.debug("Service retrieving Deliveries Today:{}", deliveriesToday);
        return map;
    }

    /**
     * Retrieves Maintrack radiator ISO information for current RVB: from highest ISO revision with biggest number of nodes in an Started RVB event.
     *
     * @return map with Current ISO version and product set with associated number of nodes.
     */
    public Map<String, String> getMaintrackRadiatorISOForCurrentRVB() {
        final Map<String, String> currentRVBMap = new HashMap<String, String>();
        // find
        final List<Clme> currentRVBList = clmeRepository.findMaintrackCurrentRVB(generateSprintNameList(getSprint(defaultLimit)));
        final List<Clme> currentSortedRvbList = new ArrayList<>();
        currentSortedRvbList.addAll(currentRVBList);
        // sort based on product set
        Collections.sort(currentSortedRvbList);
        final List<Clme> currentRadiatorRVBList = new ArrayList<Clme>();
        if (currentSortedRvbList.size() > 0) {
            final String masterVersion = currentSortedRvbList.get(0).getMasterVersion();
            for (final Clme clmeList : currentSortedRvbList) {
                if (clmeList.getMasterVersion().equals(masterVersion)) {
                    currentRadiatorRVBList.add(clmeList);
                }
            }
            // Sort based on nodes
            final List<Clme> currentFinalRVBList = sortOnNodes(currentRadiatorRVBList);
            logger.debug("currentFinalRVBList {}", currentFinalRVBList);
            currentRVBMap.putAll(getClmeAsMap(currentFinalRVBList.get(0)));
            logger.debug("RVB Details {}", currentRVBMap);
        } else {
            logger.debug(MESSAGE_NO_KGB);
            currentRVBMap.put(CURRENT_RVB_ISO_VERSION, MESSAGE_NO_KGB);
            currentRVBMap.put(CURRENT_RVB_PRODUCT_VERSION, MESSAGE_NO_KGB);

        }
        return currentRVBMap;

    }

    /**
     * Retrieves Maintrack radiator ISO information for baseline RVB from highest ISO revision with biggest number of nodes in an Completed RVB event.
     *
     * @return map with baseline ISO version and product set with associated number of nodes.
     */

    public Map<String, String> getMaintrackRadiatorISOForBaselineRVB() {
        final List<Clme> rvbBaselineList = clmeRepository.findMaintrackBaselineRVB(generateSprintNameList(getSprint(defaultLimit)));
        final Map<String, String> map = new HashMap<String, String>();
        if (rvbBaselineList.isEmpty()) {
            logger.debug(MESSAGE_NO_KGB);
            map.put(BASELINE_RVB_ISO_VERSION, MESSAGE_NO_KGB);
            map.put(BASELINE_RVB_PRODUCT_VERSION, MESSAGE_NO_KGB);
        } else {
            final List<Clme> rvbSortedList = new ArrayList<>(rvbBaselineList);
            Collections.sort(rvbSortedList);
            final List<Clme> baselineRVBList = new ArrayList<Clme>();
            final String masterVersion = rvbSortedList.get(0).getMasterVersion();
            for (final Clme clmeList : rvbSortedList) {
                if (clmeList.getMasterVersion().equals(masterVersion)) {
                    baselineRVBList.add(clmeList);
                }
            }
            // Sort based on nodes
            final List<Clme> baselineListForRVB = sortOnNodes(baselineRVBList);
            final Clme baseline = baselineListForRVB.get(0);
            map.put(BASELINE_STATUS, baseline.getResult());
            map.put(BASELINE_NODES, Integer.toString(baseline.getNodes()));
            map.put(BASELINE_RVB_ISO_VERSION, baseline.getMasterVersion());
            map.put(BASELINE_RVB_PRODUCT_VERSION, baseline.getVersion());
            map.put(DROP, baseline.getDrop());
        }
        return map;
    }

    /**
     * Generates a list of deliveries count, one element per day for the elapsed sprint time.
     *
     * @param sprintName
     *            a name of the sprint
     * @return list of deliveries information objects.
     * @throws Exception
     *             if sprint cannot be found by its name in the repository
     */

    public List<Map<String, Object>> getDeliveryDetailsForSprint(final String sprintName) {
        logger.debug("Sprint name : {}", sprintName);

        Sprint sprint = null;
        if (StringUtils.trimToNull(sprintName) == null) {
            // sprintName is empty or null
            sprint = getCurrentSprint();
        } else {
            // tries to find the sprint by given name
            sprint = sprintRepository.findByName(sprintName);
            if (sprint == null) {
                throw new MetricsServiceException("Can't find Delivery Details due to invalid sprint name");
            }
        }

        // 'to' date depends if it is the current sprint or not.
        // finds if it's the current sprint
        final long fromInMillis = sprint.getStartTimeInMillis();
        long toInMillis;
        final Sprint currentSprint = getCurrentSprint();
        if (sprint.equals(currentSprint)) {
            // uses the current end time of day
            toInMillis = serverDateTime.getCurrentDateTime().withTimeAtStartOfDay().plusDays(1).minusMillis(1).getMillis();
        } else {
            // uses the sprint end time
            toInMillis = sprint.getEndTimeInMillis();
        }

        final List<Map<String, Object>> deliveryDetails = clmeRepository.findDeliveryBetweenDaysByDropAndProduct(fromInMillis, toInMillis,
                sprint.getName(), product);
        logger.debug("Delivery details for sprint :{} is {}", sprintName, deliveryDetails.toString());
        return deliveryDetails;
    }

    /**
     * Generates a top 4 list of latest Maintrack radiator ISO details.
     *
     * @return list of ISO Maintrack objects: gav, overall ISO result, product, MTE and RFA loops information
     */
    public List<ISOMaintrackVO> getMaintrackRadiatorIsoDetails() {
        final List<ISOMaintrackVO> radiatorIsoList = getMaintrackTableDetails();
        final int size = radiatorIsoList.size() > MTG_RADIATOR_LIMIT ? MTG_RADIATOR_LIMIT : radiatorIsoList.size();
        for (int i = 0; i < size; i++) {
            final ISOMaintrackVO maintrackVO = radiatorIsoList.get(i);
            final String groupId = maintrackVO.getGroupId();
            final String artifactId = maintrackVO.getArtifactId();
            final String version = maintrackVO.getProductVersion();
            final List<Clme> rfalist = clmeRepository.findRFAList(groupId, artifactId, version);
            if (!rfalist.isEmpty()) {
                maintrackVO.setRfa(getRFAStatus(rfalist.get(0)));
            }
        }
        logger.debug("ISO List MainTrack radiator without filtering ", radiatorIsoList.toString());
        return new ArrayList<ISOMaintrackVO>(radiatorIsoList.subList(0, size));
    }

    /**
     * @deprecated this is deprecated , replaced by {@link #getIsoMaintrackTableDetails()}
     */
    @Deprecated
    public List<ISOMaintrackVO> getMaintrackTableDetails() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        // find
        final List<Clme> mteList = clmeRepository.findMTEDetails(startTime, endTime, generateSprintNameList(getSprint(defaultLimit)));
        // remove duplication
        final List<Clme> mteFilteredList = new ArrayList<Clme>(new HashSet<Clme>(mteList));
        // sorts
        Collections.sort(mteFilteredList);
        final List<ISOMaintrackVO> radiatorIsoList = new ArrayList<>();
        final int size = mteFilteredList.size() > MTG_MTE_LIMIT ? MTG_MTE_LIMIT : mteFilteredList.size();
        for (int i = 0; i < size; i++) {
            radiatorIsoList.add(getIsoMaintrackVO(mteFilteredList.get(i)));
        }
        logger.debug("Service retrieving Radiator ISO list:{}", radiatorIsoList.toString());
        return radiatorIsoList;
    }

    /**
     * Generates a top 30 list of latest Maintrack radiator ISO details in last 3 weeks.
     *
     * @return list of ISO Maintrack objects: gav, overall, product, MTE, RFA and allure report link loops information
     */
    private List<ISOMaintrackVO> getIsoMaintrackTableDetails() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        // find
        final List<Clme> mteList = clmeRepository.findMTEDetails(startTime, endTime, generateSprintNameList(getSprint(defaultLimit)));
        // remove duplication
        final List<Clme> mteFilteredList = new ArrayList<Clme>(new HashSet<Clme>(mteList));
        // sorts
        Collections.sort(mteFilteredList);
        final List<ISOMaintrackVO> radiatorIsoList = new ArrayList<>();
        final int size = mteFilteredList.size() > MTG_MTE_ALLURE_LIMIT ? MTG_MTE_ALLURE_LIMIT : mteFilteredList.size();
        for (int i = 0; i < size; i++) {
            radiatorIsoList.add(getIsoMaintrackVO(mteFilteredList.get(i)));
        }
        logger.debug("Service retrieving Radiator ISO list:{}", radiatorIsoList.toString());
        return radiatorIsoList;
    }


    /**
     * Converts a CLME object in a Map which contains the information of the current ISO
     *
     * @param rvb
     *            a clme object which contains the RVB from which extract currentNodes, currentIsoVersion, currentStatus
     * @return map with RVB ISO version and current product set version with associated number of nodes, the keys of the map are currentNodes,
     *         currentIsoVersion, currentStatus
     */
    private Map<String, String> getClmeAsMap(final Clme rvb) {

        final Map<String, String> map = new HashMap<String, String>();
        if (rvb.getMasterVersion().isEmpty()) {
            logger.debug(MESSAGE_NO_KGB);
            map.put(CURRENT_RVB_ISO_VERSION, MESSAGE_NO_KGB);
            map.put(CURRENT_RVB_PRODUCT_VERSION, MESSAGE_NO_KGB);
        } else {
            final String currentNodes = Integer.toString(rvb.getNodes());
            final String currentIsoVerion = rvb.getMasterVersion();
            final String result = rvb.getResult();
            String currrentStatus = FAILURE;
            if (SUCCESS.equals(result) && rvb.isCompletedEvent()) {
                currrentStatus = SUCCESS;
            } else if (SUCCESS.equals(result) && !rvb.isCompletedEvent()) {
                currrentStatus = PROGRESS;
            }
            map.put(CURRENT_STATUS, currrentStatus);
            map.put(CURRENT_RVB_ISO_VERSION, currentIsoVerion);
            map.put(CURRENT_RVB_PRODUCT_VERSION, rvb.getVersion());
            map.put(CURRENT_NODES, currentNodes);
            map.put(DROP, rvb.getDrop());
            logger.debug("Clme As a Map {}", map);
        }
        return map;
    }



    private Map<String, String> getCloudKGBDetailAsMap(final List<Clme> cloudKGBList) {
        final Map<String, String> map = new HashMap<String, String>();
        if (cloudKGBList.isEmpty()) {
            map.put(CURRENT_ISO_KGB_CLOUD, MESSAGE_NO_KGB);
        } else {
            final Set<Clme> cloudKGBListWithoutDuplications = new HashSet<Clme>(cloudKGBList);
            final List<Clme> cloudKGBFilteredList = new ArrayList<Clme>(cloudKGBListWithoutDuplications);
            Collections.sort(cloudKGBFilteredList);
            for (final Clme clme : cloudKGBFilteredList) {
                final String cloudIsoMasterVersion = clme.getMasterVersion();
                if (clme.getResult().equalsIgnoreCase(SUCCESS)) {

                    final List<Clme> cloudCautionKGBList = clmeRepository.findCautionDetails(cloudIsoMasterVersion);
                    if (cloudCautionKGBList.isEmpty()) {
                        map.put(CURRENT_ISO_KGB_CLOUD, cloudIsoMasterVersion);
                        map.put(CURRENT_PRODUCT_KGB_CLOUD, clme.getVersion());
                        map.put(DROP, clme.getDrop());
                        return map;
                    }
                }
            }
        }
        map.put(CURRENT_ISO_KGB_CLOUD, MESSAGE_NO_KGB);
        map.put(CURRENT_PRODUCT_KGB_CLOUD, MESSAGE_NO_KGB);
        logger.debug("Service retrieving Cloud KGB:{}", map);
        return map;
    }
    
    private Map<String, String> getMicroENMDetailAsMap(final List<Clme> microENMList) {
        final Map<String, String> map = new HashMap<String, String>();
        if (microENMList.isEmpty()) {
            map.put(CURRENT_ISO_MICRO_ENM, MESSAGE_NO_KGB);
        } else {
            final Set<Clme> microENMListWithoutDuplications = new HashSet<Clme>(microENMList);
            final List<Clme> microENMFilteredList = new ArrayList<Clme>(microENMListWithoutDuplications);
            Collections.sort(microENMFilteredList);
            for (final Clme clme : microENMFilteredList) {
                final String microENMMasterVersion = clme.getMasterVersion();
                if (clme.getResult().equalsIgnoreCase(SUCCESS)) {

                    final List<Clme> microCautionENMList = clmeRepository.findCautionDetails(microENMMasterVersion);
                    if (microCautionENMList.isEmpty()) {
                        map.put(DROP, clme.getDrop());
                        map.put(CURRENT_ISO_MICRO_ENM, microENMMasterVersion);
                        map.put(CURRENT_PRODUCT_MICRO_ENM, clme.getVersion());
                        return map;
                    }
                }
            }
        }
        map.put(CURRENT_ISO_MICRO_ENM, MESSAGE_NO_KGB);
        map.put(CURRENT_PRODUCT_MICRO_ENM, MESSAGE_NO_KGB);
        logger.debug("Service retrieving Micro ENM:{}", map);
        return map;
    }

    /**
     * Obtains Cloud KGB from highest ISO revision that has passed the maintrack entry loop considering last 3 weeks.
     *
     * @return Cloud Known Good Baseline ISO version. If no data found, No KGB set message is returned.
     */
    public Map<String, String> getMaintrackRadiatorISOForCloudKGB() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        final List<Clme> cloudKGBList = clmeRepository.findMaintrackCloudKGB(startTime, endTime);
        return getCloudKGBDetailAsMap(cloudKGBList);
    }

    public Map<String, String> getMaintrackRadiatorISOForMicroENM() {
        final long startTime = serverDateTime.getCurrentDateTime().minusWeeks(3).getMillis();
        final long endTime = serverDateTime.getCurrentDateTime().getMillis();
        final List<Clme> microENMList = clmeRepository.findMaintrackMicroENM(startTime, endTime);
        return getMicroENMDetailAsMap(microENMList);
    }
    /**
     * Creates a ISOMaintrackVO from a CLME object
     *
     * @param mte
     *            a clme object which contains the MTE from which build the isoMaintrackVO
     * @return ISOMaintrackVO object
     */

    private ISOMaintrackVO getIsoMaintrackVO(final Clme mte) {
        final ISOMaintrackVO isoMaintrackVO = new ISOMaintrackVO();
        if (SUCCESS.equals(mte.getResult()) && mte.isCompletedEvent()) {
            isoMaintrackVO.setOverall(SUCCESS);
            isoMaintrackVO.setMte(SUCCESS);
        } else if (SUCCESS.equals(mte.getResult()) && !mte.isCompletedEvent()) {
            isoMaintrackVO.setOverall(PROGRESS);
            isoMaintrackVO.setMte(PROGRESS);
        } else {
            isoMaintrackVO.setMte(FAILURE);
            isoMaintrackVO.setOverall(FAILURE);
        }
        isoMaintrackVO.setRfa("");
        isoMaintrackVO.setGroupId(mte.getGroupId());
        isoMaintrackVO.setArtifactId(mte.getArtifactId());
        isoMaintrackVO.setProductVersion(mte.getVersion());
        isoMaintrackVO.setIsoVersion(mte.getMasterVersion());
        isoMaintrackVO.setEventTime(mte.getEventTime());
        isoMaintrackVO.setDrop(mte.getDrop());
        return isoMaintrackVO;
    }

    /**
     * Obtains a RFA status from a CLME object
     *
     * @param rfa
     *            a clme object which contains the RFA from which make the status
     * @return a string with a value among FAILURE,IN PROGRESS,SUCCESS
     */

    private String getRFAStatus(final Clme rfa) {
        if (rfa == null) {
            return "";
        } else {
            if (SUCCESS.equals(rfa.getResult()) && rfa.isCompletedEvent()) {
                return SUCCESS;
            } else if (SUCCESS.equals(rfa.getResult()) && !rfa.isCompletedEvent()) {
                return PROGRESS;
            } else {
                return FAILURE;
            }
        }
    }

    /**
     * Takes in input a list of CLME object and returns in output the same list ordered by the number of nodes
     *
     * @param clmes
     *            a list of CLME to sort according to the number of the nodes
     * @return a List of CLME objects ordered by nodes
     */

    private List<Clme> sortOnNodes(final List<Clme> clmes) {
        final Comparator<Clme> nodeComparator = (final Clme clmeo1, final Clme clmeo2) -> Integer.compare(clmeo2.getNodes(), clmeo1.getNodes());
        Collections.sort(clmes, nodeComparator);
        return clmes;
    }

    private Sprint getCurrentSprint() {
        return sprintRepository.findFirstByDateTime(serverDateTime.getCurrentDateTime().getMillis());
    }

    /**
     * Generates a top 4 list for iso radiator and 30 for MTE table of latest Maintrack radiator ISO details.
     *
     * @param details
     * @return list of ISO Maintrack objects: gav, overall ISO result, product, MTE, RFA and allure report link loops information
     */
    public List<ISOMaintrackVO> getMTRadiatorIsoDetails(final String details) {
        final List<ISOMaintrackVO> radiatorIsoList = getIsoMaintrackTableDetails();
        int size = 0;
        if (MTE.equalsIgnoreCase(details)) {
            size = radiatorIsoList.size() > MTG_MTE_ALLURE_LIMIT ? MTG_MTE_ALLURE_LIMIT : radiatorIsoList.size();
        } else {
            size = radiatorIsoList.size() > MTG_RADIATOR_LIMIT ? MTG_RADIATOR_LIMIT : radiatorIsoList.size();
        }
        for (int i = 0; i < size; i++) {
            final ISOMaintrackVO maintrackVO = radiatorIsoList.get(i);
            final String groupId = maintrackVO.getGroupId();
            final String artifactId = maintrackVO.getArtifactId();
            final String version = maintrackVO.getProductVersion();
            final List<Clme> rfalist = clmeRepository.findRFAList(groupId, artifactId, version);
            if (!rfalist.isEmpty() && rfalist.get(0).getTeAllureLogUrl() != null) {
                if (matchPattern(rfalist.get(0).getTeAllureLogUrl(), URL_REGEX)) {
                    maintrackVO.setTeAllureLogUrl(rfalist.get(0).getTeAllureLogUrl());
                } else {
                    maintrackVO.setTeAllureLogUrl("");
                }
                maintrackVO.setRfa(getRFAStatus(rfalist.get(0)));
            }
        }
        logger.debug("ISO List MainTrack radiator without filtering ", radiatorIsoList.toString());
        return new ArrayList<ISOMaintrackVO>(radiatorIsoList.subList(0, size));
    }


    /**
     * Obtains a map with details of MTE-P loops trends on a given sprint range
     *
     * @param startingSprint
     * @param endingSprint
     * @return List of map with MTE physical trend information
     */
    public List<Map<String, Object>> getMTEPhysicalTrendBySprint(final String startingSprint, final String endingSprint) {

        if (Strings.isNullOrEmpty(startingSprint) && Strings.isNullOrEmpty(endingSprint)) {
            logger.debug("Going to load Default Sprint Range Trend Data");
            // both params should be null for default condition
            return sortMTETrendByDrop(defaultMTEPhysicalTrendBySprint());
        } else if (Strings.isNullOrEmpty(startingSprint) || Strings.isNullOrEmpty(endingSprint)) {
            throw new MetricsServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Invalid sprint range has been provided");
        }
        // Pattern to match sprint names
        if (!matchPattern(startingSprint, SPRINT_REGEX) || !matchPattern(endingSprint, SPRINT_REGEX)) {
            // If sprint names doesn't follow pattern
            throw new MetricsServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Invalid sprint names");
        }

        final Sprint startSprint = sprintRepository.findByName(startingSprint);
        final Sprint endSprint = sprintRepository.findByName(endingSprint);
        if (startSprint == null || endSprint == null) {
            // if failed to find the sprint details with given names
            throw new MetricsServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Can't find given sprint names ");
        } else if (startSprint.getStartTimeInMillis() > endSprint.getEndTimeInMillis()) {
            throw new MetricsServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Undefined/Incorrect Sprint range");
        }

        return sortMTETrendByDrop(getMTEPhysicalTrendBySprint(startSprint, endSprint));
    }
    
    public List<String> getAllMaintrackTestLoops(){
    	final List<String> testLoops = new ArrayList();
    	testLoops.add(ug);
    	testLoops.add(rfa);
    	testLoops.add(ugAvailability);
    	testLoops.add(ugPerformance);
    	return testLoops;
    }

    private List<Map<String, Object>> defaultMTEPhysicalTrendBySprint() {
        final int defaultLimit = 5;
        final List<Sprint> sprints =
                sprintRepository.findByDateTimeTillToday(serverDateTime.getCurrentDateTime().getMillis(), new PageRequest(0, defaultLimit, new Sort(
                        Direction.DESC, START_DATE)));
        return getMTEPhysicalTrendBySprint(sprints.stream().reduce((first, second) -> second).get(), sprints.stream().findFirst().get());
    }

    private List<Map<String, Object>> getMTEPhysicalTrendBySprint(final Sprint start, final Sprint end) {
        logger.debug("Sprint Range  Start:{} \n End:{}", start, end);
        // Finding sprints between the given sprint range
        final List<Sprint> sprintInRange = sprintRepository.findBetweenTime(end.getStartTimeInMillis(), start.getStartTimeInMillis(),
                new PageRequest(0, Integer.MAX_VALUE, new Sort(Direction.DESC, START_DATE)));
        return clmeRepository
                .findMTEPhysicalTrendInDrops(generateSprintNameList(sprintInRange));
    }

    private Object[] generateSprintNameList(final List<Sprint> sprints) {
        // Mapping Sprint names as object from "Sprint" objects
        logger.debug("Sprint included in range: {}", sprints);
        return sprints.stream().map(new Function<Sprint, String>() {
            @Override
            public String apply(final Sprint t) {
                return t.getName();
            }
        }).collect(Collectors.toList()).toArray();
    }

    private List<Map<String, Object>> sortMTETrendByDrop(final List<Map<String, Object>> trends) {
        return trends.stream().sorted(new Comparator<Map<String, Object>>() {
            @Override
            public int compare(final Map<String, Object> o1, final Map<String, Object> o2) {
                final String sprint = "sprint";
                final String[] sprintArray1 = o1.get(sprint).toString().split("\\.");
                final String[] sprintArray2 = o2.get(sprint).toString().split("\\.");
                if (sprintArray1.length > sprintArray2.length) {
                    return compareValues(sprintArray1, sprintArray2);
                } else {
                    return compareValues(sprintArray2, sprintArray1);
                }
            }
        }.reversed()).collect(Collectors.toList());
    }

    private boolean matchPattern(final String s, final String pattern) {
        try {
            final Pattern patt = Pattern.compile(pattern);
            final Matcher matcher = patt.matcher(s);
            return matcher.matches();
        } catch (final RuntimeException e) {
            logger.debug("Pattern {} didn't match {}", pattern, s);
            return false;
        }
    }

    /**
     * This method obtains a list of map with an iso version and duration and different loops included in an release flow of an iso
     *
     * @param from
     *            starting iso version
     * @param to
     *            ending iso version
     * @return
     */
    public List<Map<String, Object>> getTestTimeLoopDetailsByIso(final String from, final String to) {
        if (Strings.isNullOrEmpty(from) && Strings.isNullOrEmpty(to)) {
            logger.debug("Going to load Default iso test loop timing Data");
            // both parameters should be null for default condition
            return defaultTestLoopsTimingByISO();
        } else if (Strings.isNullOrEmpty(from) || Strings.isNullOrEmpty(to)) {
            throw new MetricsServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Invalid ISO range has been provided");
        }
        else if (!matchPattern(from, VERSION_REGEX) || !matchPattern(to, VERSION_REGEX)) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Bad request with Invalid versions");
        }
        return generateTestLoopsTiming(from, to);
    }

    private List<Map<String, Object>> generateTestLoopsTiming(final String from, final String to) {
        // TODO:: Make Changes in DB to get isos in a sorted manner, that will make following 3 queries to a single query and avoid manual sorting
        // and filtering done below
        final Clme fromIsoDetail =
                clmeRepository.findDetailsByKeyValueOrderByEventTime(MASTER_VERSION, from).stream().findFirst().get();
        final Clme toIsoDetail =
                clmeRepository.findDetailsByKeyValueOrderByEventTime(MASTER_VERSION, to).stream().findFirst().get();

        final Set<String> isoVersionSet =
                new HashSet<String>(clmeRepository.findIsoVersionsBetweenEventTime(fromIsoDetail.getEventTimeInMillis(),
                        toIsoDetail.getEventTimeInMillis()));
        // Sorting the iso list
        final List<String> isoVersions = isoVersionSet.stream().sorted(getVersionComparator().reversed()).collect(Collectors.toList());
        final int formIndex = isoVersions.indexOf(from);
        final int toIndex = isoVersions.indexOf(to);
        // This will remove the iso versions that is not present in the range,this is because we are getting all iso versions based on time range
        // there might me chance of events that associated with iso that are not in given version range, this code will filter that out
        final List<String> filteredIsoVersions = isoVersions.subList(formIndex, toIndex);
        filteredIsoVersions.add(isoVersions.get(toIndex));
        final List<Clme> clmes = clmeRepository.findTestTimeLoopDetailsByField(MASTER_VERSION, filteredIsoVersions.toArray());
        return generateReleaseFlowMap(clmes);
    }

    private List<Map<String, Object>> defaultTestLoopsTimingByISO() {
        final Sprint sprint = sprintRepository.findFirstByDateTime(serverDateTime.getCurrentDateTime().getMillis());
        final List<Clme> clmes = clmeRepository.findTestTimeLoopDetailsByField(DROP, sprint.getName());
        return generateReleaseFlowMap(clmes);
    }

    private List<Map<String, Object>> generateReleaseFlowMap(final List<Clme> clmes) {
        final List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        final Map<String, List<Clme>> isoGroups = clmes.stream().collect(Collectors.groupingBy(Clme::getMasterVersion));
        final SortedMap<String, List<Clme>> sortedMap = new TreeMap<String, List<Clme>>(getVersionComparator().reversed());
        sortedMap.putAll(isoGroups);
        for (final Entry<String, List<Clme>> entry : sortedMap.entrySet()) {
            final Map<String, Object> isoMap = new HashMap<String, Object>();
            final String iso = "iso", build = "build", deploy = "deploy", mte = "mte", rfa = "rfa", rvb = "rvb", wait = "Wait";
            isoMap.put(iso, entry.getKey());
            final List<Clme> clmes2 = entry.getValue();
            boolean hasBuildLoop = false, hasDeployLoop = false, hasMteLoop = false, hasRFALoop = false, hasRVBLoop = false;
            final Map<String, Map<String, Object>> durationMap = new HashMap<String, Map<String, Object>>();
            for (final Clme clme : clmes2) {
                if (clme.getFinishedLevel().equals(ISO_BUILD_COMPLETED)) {
                    durationMap.put(build, generateTestDurationMap(clme));
                    hasBuildLoop = true;
                } else if (clme.getFinishedLevel().equals(DEPLOY_COMPLETED)) {
                    durationMap.put(deploy, generateTestDurationMap(clme));
                    hasDeployLoop = true;
                } else if (clme.getFinishedLevel().equals(MTE_CL_COMPLETED)) {
                    durationMap.put(mte, generateTestDurationMap(clme));
                    hasMteLoop = true;
                } else if (clme.getFinishedLevel().equals(RFA_CL_COMPLETED)) {
                    durationMap.put(rfa, generateTestDurationMap(clme));
                    hasRFALoop = true;
                } else if (clme.getFinishedLevel().equals(RVB_CL_COMPLETED)) {
                    durationMap.put(rvb, generateTestDurationMap(clme));
                    hasRVBLoop = true;
                }
            }

            setDefaultValueIfLoopNotFound(build, hasBuildLoop, durationMap);
            setDefaultValueIfLoopNotFound(deploy, hasDeployLoop, durationMap);
            setDefaultValueIfLoopNotFound(mte, hasMteLoop, durationMap);
            setDefaultValueIfLoopNotFound(rfa, hasRFALoop, durationMap);
            setDefaultValueIfLoopNotFound(rvb, hasRVBLoop, durationMap);

            if (hasBuildLoop && hasDeployLoop) {
                durationMap.put(deploy + wait, generateTestWaitingMap(durationMap.get(build), durationMap.get(deploy)));
            } else {
                durationMap.put(deploy + wait, generateTestWaitingMap(null, null));
            }

            if (hasDeployLoop && hasMteLoop) {
                durationMap.put(mte + wait, generateTestWaitingMap(durationMap.get(deploy), durationMap.get(mte)));
            } else {
                durationMap.put(mte + wait, generateTestWaitingMap(null, null));
            }

            if (hasMteLoop && hasRFALoop) {
                durationMap.put(rfa + wait, generateTestWaitingMap(durationMap.get(mte), durationMap.get(rfa)));
            } else {
                durationMap.put(rfa + wait, generateTestWaitingMap(null, null));
            }

            if (hasRFALoop && hasRVBLoop) {
                durationMap.put(rvb + wait, generateTestWaitingMap(durationMap.get(rfa), durationMap.get(rvb)));
            } else {
                durationMap.put(rvb + wait, generateTestWaitingMap(null, null));
            }
            isoMap.putAll(durationMap);
            list.add(isoMap);
        }
        return list;
    }

    private void setDefaultValueIfLoopNotFound(final String loopName, final boolean loopFlag, final Map<String, Map<String, Object>> durationMap) {
        if (!loopFlag) {
            final Map<String, Object> map = new HashMap<>();
            map.put(START_TIME, 0);
            map.put(FINISHED_TIME, 0);
            map.put(DURATION, 0);
            durationMap.put(loopName, map);
        }
    }

    private Map<String, Object> generateTestWaitingMap(final Map<String, Object> loop1, final Map<String, Object> loop2) {
        final Map<String, Object> map = new HashMap<>();
        if (loop1 != null && loop2 != null) {
            final long loop1FinishedTime = (Long) loop1.get(FINISHED_TIME);
            final long loop2StartedTime = (Long) loop2.get(START_TIME);
            final Duration duration = new Duration(loop1FinishedTime, loop2StartedTime);
            map.put(START_TIME, loop1FinishedTime);
            map.put(FINISHED_TIME, loop2StartedTime);
            map.put(DURATION, duration.getStandardMinutes());
        } else {
            map.put(START_TIME, 0);
            map.put(FINISHED_TIME, 0);
            map.put(DURATION, 0);
        }
        return map;
    }

    private Map<String, Object> generateTestDurationMap(final Clme clme) {
        final Map<String, Object> map = new HashMap<>();
        map.put(START_TIME, clme.getEventTimeInMillis());
        map.put(FINISHED_TIME, clme.getFinishedEventTimeInMillis());
        map.put(DURATION, ObjectUtils.defaultIfNull(clme.getDuration(), 0));
        return map;
    }

    private List<Sprint> getSprint(final int defaultLimit) {
        final List<Sprint> sprints =
                sprintRepository.findByDateTimeTillToday(serverDateTime.getCurrentDateTime().getMillis(), new PageRequest(0, defaultLimit, new Sort(
                        Direction.DESC, START_DATE)));
        return sprints;
    }

    public List<String> getIsoVersionList(final String drop) {
        if (drop == null || !matchPattern(drop, SPRINT_REGEX)) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Request with invalid drop name ");
        }
        else if (drop.isEmpty()) {
            throw new MetricsServiceException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request with invalid drop name ");
        }
        // Set is used to remove duplicates from iso versions
        final Set<String> isoVersions = new HashSet<String>(clmeRepository.findIsoVersionsByDrop(drop));
        return new ArrayList<String>(isoVersions).stream().sorted(getVersionComparator()).collect(Collectors.toList());
    }

    private Comparator<String> getVersionComparator() {
        return new Comparator<String>() {
            @Override
            public int compare(final String o1, final String o2) {
                final String[] sprintArray1 = o1.split("\\.");
                final String[] sprintArray2 = o2.split("\\.");
                if (sprintArray1.length > sprintArray2.length) {
                    return compareValues(sprintArray1, sprintArray2);
                } else {
                    return compareValues(sprintArray2, sprintArray1);
                }
            }
        };
    }

    private Integer compareValues(final String[] array1, final String[] array2) {
        for (int i = 0; i < array1.length; i++) {
            final Integer v1 = Integer.parseInt(array1[i]);
            final Integer v2 = Integer.parseInt(array2[i]);
            if (v1 != v2) {
                return v1 - v2;
            }
        }
        return 0;
    }

    /**
     * This method obtains a map with team profile details
     *
     * @param teamName
     *            , name of team for whom the profile should generate
     * @param from
     *            ,beginning of time interval
     * @param to
     *            ,end of time interval
     * @return <code> List<Map<String, Object>> </code>
     */

    public List<Map<String, Object>> getTeamProfileBetweenEventTime(final String teamName, final Long from, final Long to) {
        if (teamName == null || teamName.trim().isEmpty()) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid Team Name");
        }
        Long startTime = from, endTime = to;
        if (startTime == null && endTime == null) {
            final Sprint sprint = sprintRepository.findFirstByDateTime(serverDateTime.getCurrentDateTime().getMillis());
            startTime = sprint.getStartTimeInMillis();
            endTime = sprint.getEndTimeInMillis();
        } else if (startTime == null || endTime == null || startTime <= 0 || endTime <= 0 || startTime > endTime) {
            throw new MetricsServiceException(HttpStatus.BAD_REQUEST.value(), "Invalid Time Range");
        }

        logger.debug("Team profile for : {} from :{},to :{}", teamName, from, to);
        final String[] profileMessageTypes =
                ArrayUtils.removeElement(Arrays.stream(MessageType.values()).map(Enum::name).toArray(String[]::new), MessageType.CDB.toString());

        final List<Clme> clmes =
                clmeRepository.findTeamProfile(teamName, startTime, endTime, profileMessageTypes);
        logger.debug("Profile details from DB :{}", clmes);
        return clmes.stream().map(clme -> generateTeamProfile(clme)).collect(Collectors.toList());
    }

    private Map<String, Object> generateTeamProfile(final Clme clme) {
        final Map<String, Object> map = new HashMap<String, Object>();
        final String time = "time", type = "type";
        map.put(time, clme.getEventTime());
        map.put(type, clme.getMessageType());
        if (MessageType.DEL.equals(clme.getMessageType())) {
            map.put(type, clme.getMessageType() + "_KGB_" + clme.getKgbStatus());
        } else if (MessageType.OBS.equals(clme.getMessageType())) {
            map.put(type, clme.getMessageType());
        } else {
            map.put(type, clme.getMessageType() + "_" + clme.getResult());
        }
        logger.debug("Profile details :{}", map);
        return map;
    }

}
