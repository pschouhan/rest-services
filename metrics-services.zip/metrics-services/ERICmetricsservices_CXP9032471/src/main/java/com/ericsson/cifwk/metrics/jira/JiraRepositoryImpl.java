/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.jira;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

@Repository
public class JiraRepositoryImpl implements JiraRepository {

    private static final String VELOCITY = "velocity";
    private static final String TOTAL = "total";
    private static final String SPRINT = "%sprintValue%";
    private static final String SPRINT_NOT_IN_FORMAT = "%sprintNIFValue%";

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Value("${jira.rest.auth.user}")
    private String jiraUser;

    @Value("${jira.rest.auth.pwd}")
    private String jiraPassword;

    @Value("${jira.url}")
    private String jiraUrl;

    @Value("${sprint.burndown}")
    private String sprintBurndownQuery;

    @Value("${sprint.commitment}")
    private String sprintCommitmentQuery;

    @Override
    public double findSprintBurnDown(final String sprint) {
        logger.debug("Burndown for Sprint : {}", sprint);
		final String query = sprintBurndownQuery.replace(SPRINT, sprint)
				.replace(SPRINT_NOT_IN_FORMAT, getSprintNotInFormat(sprint));
        final String service = "/rest/scriptrunner-jira/latest/jqlfunctions/aggregateResult?jql=";
        final Map<String, Object> response = queryJira(service, query);
        final String velocity = (String) ObjectUtils.defaultIfNull(response.get(VELOCITY), "0");
        return Double.parseDouble(velocity);
    }

    @Override
    public double findSprintCommitment(final String sprint) {
        logger.debug("Commitment for Sprint : {}", sprint);
		final String query = sprintCommitmentQuery.replace(SPRINT, sprint)
				.replace(SPRINT_NOT_IN_FORMAT, getSprintNotInFormat(sprint));
        final String service = "/rest/scriptrunner-jira/latest/jqlfunctions/aggregateResult?jql=";
        final Map<String, Object> response = queryJira(service, query);
        final String total = (String) ObjectUtils.defaultIfNull(response.get(TOTAL), "0");
        return Double.parseDouble(total);
    }

    private Map<String, Object> queryJira(final String service, final String query) {
        logger.debug("jira request for service:{} query:{}", service, query);
        final RestTemplate restTemplate = new RestTemplate();
        final String auth = jiraUser + ":" + jiraPassword;
        try {
            final String encoded = DatatypeConverter.printBase64Binary(auth.getBytes("UTF-8"));
            final HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", "Basic " + encoded);
            final HttpEntity<String> request = new HttpEntity<String>(headers);
            final URI uri = new URI(jiraUrl + service);
            final ResponseEntity<Map> responseComitted = restTemplate.exchange(uri + query, HttpMethod.GET, request, Map.class);
            return responseComitted.getBody();
        } catch (final Exception e) {
            logger.warn("Jira connection error. Service:{}, Query:{}", service, query, e);
            return new HashMap<String, Object>();
        }
    }
    
    private String getSprintNotInFormat(final String sprint){
    	final String[] consecutive = sprint.split(Pattern.quote("."));
    	if (Integer.parseInt(consecutive[1]) < 10) {
    		return sprint.replace(".", ".0");
    	}
    	return sprint;
    }

}
