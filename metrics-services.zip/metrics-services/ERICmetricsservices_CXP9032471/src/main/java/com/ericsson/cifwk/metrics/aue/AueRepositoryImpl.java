/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.aue;

import java.util.List;
import java.util.Map;

import org.elasticsearch.index.query.FilterBuilders;
import org.elasticsearch.index.query.FilteredQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;



@Repository
public class AueRepositoryImpl implements AueRepository{

	private final Logger logger = LoggerFactory.getLogger(getClass());
	private static final String ARTIFACT_ID = "artifactId";
    private static final String ARTIFACT = "artifact";
    private static final String EVENT_TIME = "eventTime";
       
	
    @Value("${es.index}")
    private String index;

    @Value("${es.index.type.aue}")
    private String type;

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    private AueExtractors extractors;

	 @Override
	    public List<Map<String, Object>> findArtifactsBetweenDays(final long from, final long to) {
		 
	        logger.debug("Query params to Find Artifacts Between Days, from:{}, to:{}",
	                String.valueOf(from), String.valueOf(to));
	        final FilteredQueryBuilder filteredQuery = QueryBuilders.filteredQuery(QueryBuilders.matchAllQuery(), 
		        	FilterBuilders.rangeFilter(EVENT_TIME).from(from).to(to));
	        final AggregationBuilder<?> aggregationBuilder = AggregationBuilders.terms(ARTIFACT).field(ARTIFACT_ID);
	          		        final SearchQuery query = new NativeSearchQueryBuilder()
	                .withIndices(index).withTypes(type).withQuery(filteredQuery)
	                .addAggregation(aggregationBuilder).withPageable(new PageRequest(0, 10)).build();
	        return elasticsearchTemplate.query(query,extractors.getartifactVOExtractor());
	    }
}