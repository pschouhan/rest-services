/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.clme;

/**
 * This class represents the model of the ENM ISO Maintrack information.
 * Includes GAV information: groupId, artifactId, isoVersion Product set MTE and
 * RFA loops status information Overall: indicates general status for the
 * specific ISO considering mte & rfa results
 */
public class ISOMaintrackVO {
	private String isoVersion;
	private String overall;
	private String groupId;
	private String artifactId;
	private String productVersion;
	private String mte;
	private String rfa;
	private String eventTime;
	private String teAllureLogUrl;

	private String drop;

	public String getEventTime() {
		return eventTime;
	}

	public void setEventTime(final String eventTime) {
		this.eventTime = eventTime;
	}

	public String getIsoVersion() {
		return isoVersion;
	}

	public void setIsoVersion(final String isoVersion) {
		this.isoVersion = isoVersion;
	}

	public String getOverall() {
		return overall;
	}

	public void setOverall(final String overall) {
		this.overall = overall;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(final String groupId) {
		this.groupId = groupId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(final String artifactId) {
		this.artifactId = artifactId;
	}

	public String getProductVersion() {
		return productVersion;
	}

	public void setProductVersion(final String productVersion) {
		this.productVersion = productVersion;
	}

	public String getMte() {
		return mte;
	}

	public void setMte(final String mte) {
		this.mte = mte;
	}

	public String getRfa() {
		return rfa;
	}

	public void setRfa(final String rfa) {
		this.rfa = rfa;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(final String drop) {
		this.drop = drop;
	}

	public String getTeAllureLogUrl() {
		return teAllureLogUrl;
	}

	public void setTeAllureLogUrl(final String teAllureLogUrl) {
		this.teAllureLogUrl = teAllureLogUrl;
	}

	@Override
	public String toString() {
		return "ISOMaintrackVO [isoVersion=" + isoVersion + ", overall=" + overall + ", groupId=" + groupId
				+ ", artifactId=" + artifactId + ", productVersion=" + productVersion + ", mte=" + mte + ", rfa=" + rfa
				+ ", eventTime=" + eventTime + ",  drop=" + drop + ", teAllureLogUrl=" + teAllureLogUrl + "]";
	}

}
