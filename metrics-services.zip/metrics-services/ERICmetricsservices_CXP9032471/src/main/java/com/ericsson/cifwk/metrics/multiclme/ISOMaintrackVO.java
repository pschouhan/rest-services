/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/
package com.ericsson.cifwk.metrics.multiclme;

public class ISOMaintrackVO {
	private String isoVersion;
	private String workingBaseline;
	private String groupId;
	private String artifactId;
	private String artifactVersion;
	private String eventTime;
	private String drop;
	private String ug_status;
	private String ug_teAllureLogUrl;
	private String rfa_status;
	private String rfa_teAllureLogUrl;
	private String ugAvailability_status;
	private String ugAvailability_teAllureLogUrl;
	private String ugPerformance_status;
	private String ugPerformance_teAllureLogUrl;
	private String product;

	public String getEventTime() {
		return eventTime;
	}

	public void setEventTime(final String eventTime) {
		this.eventTime = eventTime;
	}

	public String getIsoVersion() {
		return isoVersion;
	}

	public void setIsoVersion(final String isoVersion) {
		this.isoVersion = isoVersion;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(final String groupId) {
		this.groupId = groupId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(final String artifactId) {
		this.artifactId = artifactId;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(final String drop) {
		this.drop = drop;
	}

	public String getWorkingBaseline() {
		return workingBaseline;
	}

	public void setWorkingBaseline(String workingBaseline) {
		this.workingBaseline = workingBaseline;
	}

	public String getArtifactVersion() {
		return artifactVersion;
	}

	public void setArtifactVersion(String artifactVersion) {
		this.artifactVersion = artifactVersion;
	}

	public String getUg_status() {
		return ug_status;
	}

	public void setUg_status(String ug_status) {
		if(ug_status == null){
			this.ug_status = "";
		}
		else{
			this.ug_status = ug_status;
		}
	}

	public String getUg_teAllureLogUrl() {
		return ug_teAllureLogUrl;
	}

	public void setUg_teAllureLogUrl(String ug_teAllureLogUrl) {
		this.ug_teAllureLogUrl = ug_teAllureLogUrl;
	}

	public String getRfa_status() {
		return rfa_status;
	}

	public void setRfa_status(String rfa_status) {
		if(rfa_status == null){
			this.rfa_status = "";
		}
		else{
			this.rfa_status = rfa_status;
		}
	}

	public String getRfa_teAllureLogUrl() {
		return rfa_teAllureLogUrl;
	}

	public void setRfa_teAllureLogUrl(String rfa_teAllureLogUrl) {
		this.rfa_teAllureLogUrl = rfa_teAllureLogUrl;
	}

	public String getUgAvailability_status() {
		return ugAvailability_status;
	}

	public void setUgAvailability_status(String ugAvailability_status) {
		if(ugAvailability_status == null){
			this.ugAvailability_status = "";
		}
		else{
			this.ugAvailability_status = ugAvailability_status;
		}
	}

	public String getUgAvailability_teAllureLogUrl() {
		return ugAvailability_teAllureLogUrl;
	}

	public void setUgAvailability_teAllureLogUrl(String ugAvailability_teAllureLogUrl) {
		this.ugAvailability_teAllureLogUrl = ugAvailability_teAllureLogUrl;
	}

	public String getUgPerformance_status() {
		return ugPerformance_status;
	}

	public void setUgPerformance_status(String ugPerformance_status) {
		if(ugPerformance_status == null){
			this.ugPerformance_status = "";
		}
		else{
			this.ugPerformance_status = ugPerformance_status;
		}
	}

	public String getUgPerformance_teAllureLogUrl() {
		return ugPerformance_teAllureLogUrl;
	}

	public void setUgPerformance_teAllureLogUrl(String ugPerformance_teAllureLogUrl) {
		this.ugPerformance_teAllureLogUrl = ugPerformance_teAllureLogUrl;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ISOMaintrackVO [isoVersion=" + isoVersion + ", workingBaseline=" + workingBaseline + ", groupId="
				+ groupId + ", artifactId=" + artifactId + ", artifactVersion=" + artifactVersion + ", eventTime="
				+ eventTime + ",  drop=" + drop + ",  ug_status=" + ug_status + ",  ug_teAllureLogUrl=" + ug_teAllureLogUrl
				+ ",  rfa_status=" + rfa_status + ",  rfa_teAllureLogUrl=" + rfa_teAllureLogUrl + ",  ugAvailability_status=" + ugAvailability_status
				+ ",  ugAvailability_teAllureLogUrl=" + ugAvailability_teAllureLogUrl + ",  ugPerformance_status=" + ugPerformance_status + ",  ugPerformance_teAllureLogUrl=" + ugPerformance_teAllureLogUrl
				+ ",  product=" + product + "]";
	}

}
