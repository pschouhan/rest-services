
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class TeamProfileIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/team-profile";

    private static void assertTeamProfileData(final Map<String, Object> data, final String time, final String type) {
        Assert.assertEquals(type, data.get("type"));
        Assert.assertEquals(time, data.get("time"));
    }

    private static Map<String, Object> getJson(final String from, final int index) {
        final Map<String, Object> map = from(from).get("[" + index + "]");
        return map;
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-for-4-test.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsTeamAsArrayAndStringAndTeam_MessageTypeFilteringWillReturn6DataArray() {
        final String s = get(format("%s%s%s", basicUrl, END_POINT, "?team=Dozzers")).asString();
        assertTeamProfileData(getJson(s, 0), "2016-02-10T08:09:05.390Z", "COM_SUCCESS");
        assertTeamProfileData(getJson(s, 1), "2016-02-10T10:09:05.390Z", "KGB_SUCCESS");
        assertTeamProfileData(getJson(s, 2), "2016-02-10T11:09:05.390Z", "DEL_KGB_FAILED");
        assertTeamProfileData(getJson(s, 3), "2016-02-10T12:09:05.390Z", "DEL_KGB_PASSED");
        assertTeamProfileData(getJson(s, 4), "2016-02-11T18:09:05.390Z", "DEL_KGB_NOT_STARTED");
        assertTeamProfileData(getJson(s, 5), "2016-02-12T18:09:05.390Z", "OBS");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-for-4-test.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsTeamAsArrayAndString_MessageTypeFilteringWithTimeRangeWillReturn3DataArray() {
        final String s = get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=1455095160000", "&to=1455213600000")).asString();
        assertTeamProfileData(getJson(s, 0), "2016-02-10T10:09:05.390Z", "KGB_SUCCESS");
        assertTeamProfileData(getJson(s, 1), "2016-02-10T11:09:05.390Z", "DEL_KGB_FAILED");
        assertTeamProfileData(getJson(s, 2), "2016-02-10T12:09:05.390Z", "DEL_KGB_PASSED");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/unstable-result-test-1.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testWillSupportResultFilterWith_Success_Failure_AndReturn2Data() {
        final String s = get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=1451567105000", "&to=1456837505000")).asString();
        assertTeamProfileData(getJson(s, 0), "2016-01-01T11:09:05.000Z", "DEL_KGB_FAILED");
        assertTeamProfileData(getJson(s, 1), "2016-01-20T12:09:05.000Z", "DEL_KGB_PASSED");

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-for-4-test.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportswillNotReturnDataIngivenTimeRangeDueToNoEntryInDB() {
        when().
                get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=1451639160000", "&to=1451984760000"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/unstable-result-test.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportswillNotReturnDataIngivenTimeRangeDueToUnstableStatusInDB() {
        when().
                get(format("%s%s%s", basicUrl, END_POINT, "?team=Dozzers"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-for-4-test.json" }) })
    @ServerDateTime("01-01-2016 18:00:00")
    public void testSupportswillNotReturnDataInDefaultConditionDueToNoEntryInDB() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?team=Dozzers"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsTimeRangeValidationShouldReturnArrayWith4Data() {
        final String s = get(format("%s%s%s", basicUrl, END_POINT, "?team=Dozzers")).asString();
        assertTeamProfileData(getJson(s, 0), "2016-02-10T08:09:05.390Z", "COM_SUCCESS");
        assertTeamProfileData(getJson(s, 1), "2016-02-10T10:09:05.390Z", "KGB_SUCCESS");
        assertTeamProfileData(getJson(s, 2), "2016-02-10T12:09:05.390Z", "DEL_KGB_PASSED");
        assertTeamProfileData(getJson(s, 3), "2016-02-12T18:09:05.390Z", "OBS");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/corrupted-data.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationOnCorruptedTeamAndMessageTypeShouldReturnArrayWith3Data() {
        final String s = get(format("%s%s%s", basicUrl, END_POINT, "?team=Dozzers")).asString();
        assertTeamProfileData(getJson(s, 0), "2016-02-10T08:09:05.390Z", "COM_SUCCESS");
        assertTeamProfileData(getJson(s, 1), "2016-02-10T08:12:05.390Z", "COM_FAILURE");
        assertTeamProfileData(getJson(s, 2), "2016-02-10T10:09:05.390Z", "KGB_FAILURE");

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithNullTeamParamReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?team=")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithEmptyTeamParamReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?team=  ")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithNegativeTimeRangeParamReturn400Error() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=-1", "&to-1")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithNegativeFromTimeRangeParamReturn400Error() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=-1", "&to=1455091505000")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithNegativeToTimeRangeParamReturn400Error() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=1455091505000", "&to=-1")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithZeroTimeRangeBoundaryParamReturn400Error() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=0", "&to=0")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithZeroFromTimeRangeBoundaryParamReturn400Error() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=0", "&to=1455091505000")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithZeroToTimeRangeBoundaryParamReturn400Error() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=1455091505000", "&to=0")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithMissingToTimeRangeBoundaryParamReturn400Error() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=1455091505000")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-for-4-test.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithLargerFromTimeRangeBoundaryParamReturn400Error() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&from=1455213600000", "&to=1455095160000")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithMissingFromTimeRangeBoundaryParamReturn400Error() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?team=Dozzers", "&to=1455091505000")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testSupportsValidationWithMissingTeamParamReturn500Error() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?from=1455091505000", "&to=1455177905000")).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/team-profile/happy-out-of-sprint.json" }) })
    @ServerDateTime("14-02-2016 18:00:00")
    public void testWithNoRequreidParamReturn500Error() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

    }
}
