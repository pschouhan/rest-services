/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2015
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.group;

import static java.lang.String.format;
import static org.hamcrest.CoreMatchers.equalTo;
import java.util.Map;
import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;
import org.json.JSONArray;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.ericsson.cifwk.metrics.group.Group.GroupKgbStatus;

@SprintFixture
public class CurrentWaitingQueueIT extends AbstractIntegrationTest {

	private static final String END_POINT = "/current-waiting-queue";

	private static void assertWaitingQueueData(final Map<String, Object> data, final String status,
			final String queueId, final String drop, final int queueLength, final boolean hasMissingDependencies,
			final Integer timeInQueue, final GroupKgbStatus groupKgbStatus) {
		Assert.assertEquals(queueId, data.get("queueId"));
		Assert.assertEquals(status, data.get("status"));
		Assert.assertEquals(drop, data.get("drop"));
		Assert.assertEquals(queueLength, data.get("queueLength"));
		Assert.assertEquals(hasMissingDependencies, data.get("hasMissingDependencies"));
		Assert.assertEquals(timeInQueue, data.get("timeInQueue"));
		Assert.assertEquals(groupKgbStatus.name(), data.get("groupKgbStatus"));
	}

	private static Map<String, Object> getJson(final String from, final int index) {
		final Map<String, Object> map = from(from).get("[" + index + "]");
		return map;
	}

	@Test
	@ServerDateTime("02-03-2016 12:00:00")
	@Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json", files = {
			"/group/current-waiting-queue/current-waiting-queue-1.json" }) })
	public void testSupportsWaitingQueueShouldReturnArrayWith2Data() {
		final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
		JSONArray JSONResponseBody = new JSONArray(s);
		Assert.assertEquals(JSONResponseBody.length(), 2);
		assertWaitingQueueData(getJson(s, 0), "CREATED", "4651", "16.4", 9, false, 325, GroupKgbStatus.PASSED);
		assertWaitingQueueData(getJson(s, 1), "MODIFIED", "4652", "16.4", 11, true, 313, GroupKgbStatus.IN_PROGRESS);		
	}

	@Test
	@ServerDateTime("09-02-2016 12:00:00")
	@Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json", files = {
			"/group/current-waiting-queue/current-waiting-queue-2.json" }) })
	public void testSupportsWaitingQueueShouldReturnArrayWith3Data() {
		final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
		JSONArray JSONResponseBody = new JSONArray(s);
		Assert.assertEquals(JSONResponseBody.length(), 3);
		assertWaitingQueueData(getJson(s, 0), "MODIFIED", "4641", "16.3", 15, true, 2653, GroupKgbStatus.IN_PROGRESS);
		assertWaitingQueueData(getJson(s, 1), "MODIFIED", "4636", "16.3", 11, false, 2455, GroupKgbStatus.FAILED);
		assertWaitingQueueData(getJson(s, 2), "CREATED", "4632", "16.3", 9, true, 2213, GroupKgbStatus.NOT_STARTED);
	}

	@Test
	@ServerDateTime("02-12-2015 12:00:00")
	@Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json", files = {
			"/group/current-waiting-queue/current-waiting-queue-1.json" }) })
	public void testSupportsWaitingQueueWillNotReturnDataIFNoEntryInDB() {
		when().get(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.OK.value()).body("size()",
				equalTo(0));
	}
}
