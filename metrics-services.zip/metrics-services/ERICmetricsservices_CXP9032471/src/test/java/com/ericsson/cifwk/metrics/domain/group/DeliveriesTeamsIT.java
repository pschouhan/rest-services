
package com.ericsson.cifwk.metrics.domain.group;

import static java.lang.String.format;

import static com.jayway.restassured.RestAssured.when;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class DeliveriesTeamsIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/deliveries-teams";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/deliveries-teams/deliveries-teams-2.json" }) })
    @ServerDateTime("27-10-2015 12:00:00")
    public void testDeliveriesTeamWillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("isEmpty()", Matchers.is(false))
                .body("$", Matchers.hasSize(4))
                .body("find { it.teamName == 'Apollo' }.groupCount",
                        Matchers.equalTo(1))
                .body("find { it.teamName == 'BigTrick' }.groupCount",
                        Matchers.equalTo(1))
                .body("find { it.teamName == 'Doozers' }.groupCount",
                        Matchers.equalTo(2))
                .body("find { it.teamName == 'Teapot' }.groupCount",
                        Matchers.equalTo(1));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/deliveries-teams/deliveries-teams-5.json" }) })
    @ServerDateTime("29-10-2015 12:00:00")
    public void testNoDropInformationwillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", Matchers.equalTo(0))
                .body("isEmpty()", Matchers.is(true));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/deliveries-teams/deliveries-teams-1.json" }) })
    @ServerDateTime("26-10-2015 12:00:00")
    public void testNoSprintInformationButHasDataWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", Matchers.equalTo(0))
                .body("isEmpty()", Matchers.is(true));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/deliveries-teams/deliveries-teams-4.json" }) })
    @ServerDateTime("26-10-2015 12:00:00")
    public void testNoStatusInformationWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", Matchers.equalTo(0))
                .body("isEmpty()", Matchers.is(true));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/deliveries-teams/deliveries-teams-3.json" }) })
    @ServerDateTime("26-10-2015 12:00:00")
    public void testWrongDropInformationButHasDataWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", Matchers.equalTo(0))
                .body("isEmpty()", Matchers.is(true));

    }

}
