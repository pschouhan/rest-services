/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2016
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.team;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;

public class TeamInfoIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/teams";

    private static void assertTeamData(final Map<String, Object> data, final String ra, final List<String> teams) {
        Assert.assertEquals(teams, data.get("teams"));
        Assert.assertEquals(ra, data.get("parentElement"));
    }

    private static Map<String, Object> getJson(final String from, final int index) {
        final Map<String, Object> map = from(from).get("[" + index + "]");
        return map;
    }

    @Test
    @Fixtures(index = "ci-events", dropIndex = true, fixtures = { @Fixture(type = "teams",
            mapping = "/team/team-mapping.json", files = { "/team/teams/team.json" }) })
    public void testShouldReturnArrayOf8DataObjectsWith_ASCOrderTribe_ASCOrderTeam() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertTeamData(getJson(s, 0), "AM", Arrays.asList("Z Men"));
        assertTeamData(getJson(s, 1), "CM", Arrays.asList("E Men", "X Men", "Y Men"));
        assertTeamData(getJson(s, 2), "DE", Arrays.asList("Dharma", "Gitmo"));
        assertTeamData(getJson(s, 3), "JM", Arrays.asList("C Men"));
        assertTeamData(getJson(s, 4), "KM", Arrays.asList("D Men"));
        assertTeamData(getJson(s, 5), "OZ", Arrays.asList("B Men"));
        assertTeamData(getJson(s, 6), "PM", Arrays.asList("Dozzers", "Looney Toons"));
        assertTeamData(getJson(s, 7), "ZM", Arrays.asList("A Men"));
    }

    @Test
    @Fixtures(index = "ci-events", dropIndex = true, fixtures = { @Fixture(type = "teams",
            mapping = "/team/team-mapping.json", files = { "/common/no-data.json" }) })
    public void testShouldNotReturnNoDataDueToEmptyDB() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }
}
