
package com.ericsson.cifwk.metrics.domain.group;

import static java.lang.String.format;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class DeliveryQueueTrendIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/delivery-queue-trends";
    @Autowired
    private com.ericsson.cifwk.metrics.domain.ServerDateTime serverDateTime;

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/normal-data.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("30-11-2015 17:00:00")
    public void test_Should_Return_3months_Data() {
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0")).asString();
        final String info = from(s).get("info");
        final List<Map<String, String>> artifacts = from(s).get("data[0].data");
        final String artifact = from(s).get("data[1].label");
        final List<Map<String, String>> groups = from(s).get("data[1].data");
        final String group = from(s).get("data[0].label");
        Assert.assertEquals("valid", info);
        Assert.assertEquals("Artifacts", artifact);
        Assert.assertEquals("Groups", group);
        Assert.assertEquals(artifacts.size(), groups.size());
        Assert.assertEquals(4, artifacts.size());
        Assert.assertEquals(4, groups.size());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/more-data.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("30-11-2015 17:00:00")
    public void test_Should_Return_Too_Much_Data_To_Load() {
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0")).asString();
        final String info = from(s).get("info");
        Assert.assertEquals("Too much data to load", info);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/normal-data.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_TimePeriod() {
        final long endTime = parseTimeToMillis("30-11-2015 17:00:00");
        final long startTime = parseTimeToMillis("01-11-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        final String info = from(s).get("info");
        final List<Map<String, String>> artifacts = from(s).get("data[0].data");
        final String artifact = from(s).get("data[1].label");
        final List<Map<String, String>> groups = from(s).get("data[1].data");
        final String group = from(s).get("data[0].label");
        Assert.assertEquals("valid", info);
        Assert.assertEquals("Artifacts", artifact);
        Assert.assertEquals("Groups", group);
        Assert.assertEquals(artifacts.size(), groups.size());
        Assert.assertEquals(1, artifacts.size());
        Assert.assertEquals(1, groups.size());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/boundary-data.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("30-11-2015 23:59:00")
    public void test_Should_Return_Data_For_TimePeriod_Inside_Boundaries() {
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0")).asString();
        final String info = from(s).get("info");
        final List<Map<String, String>> artifacts = from(s).get("data[0].data");
        final String artifact = from(s).get("data[1].label");
        final List<Map<String, String>> groups = from(s).get("data[1].data");
        final String group = from(s).get("data[0].label");
        Assert.assertEquals("valid", info);
        Assert.assertEquals("Artifacts", artifact);
        Assert.assertEquals("Groups", group);
        Assert.assertEquals(artifacts.size(), groups.size());
        Assert.assertEquals(3, artifacts.size());
        Assert.assertEquals(3, groups.size());
    }

    // NO Data Scenarios
    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/common/no-data.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("30-11-2015 17:00:00")
    public void test_Should_Return_NoData_Due_To_EmptyDB() {
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0")).asString();
        final String info = from(s).get("info");
        final Object data = from(s).get("data");
        Assert.assertEquals("NO DATA", info);
        Assert.assertEquals(null, data);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("30-11-2015 17:00:00")
    public void test_Should_Return_NoData_In_Default_TimePeriod() {
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0")).asString();
        final String info = from(s).get("info");
        final Object data = from(s).get("data");
        Assert.assertEquals("NO DATA", info);
        Assert.assertEquals(null, data);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_NoData_In_Custom_TimePeriod() {
        final long endTime = parseTimeToMillis("30-11-2015 17:00:00");
        final long startTime = parseTimeToMillis("01-11-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        final String info = from(s).get("info");
        final Object data = from(s).get("data");
        Assert.assertEquals("NO DATA", info);
        Assert.assertEquals(null, data);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Larger_StartTime_than_EndTime_Params() {
        final long endTime = parseTimeToMillis("30-11-2015 17:00:00");
        final long startTime = parseTimeToMillis("01-11-2015 17:00:00");
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + endTime, "&endTime=" + startTime))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Null_Params() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=", "&endTime="))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Negative_Param_StartDate() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=-1", "&endTime="))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    public void test_Should_Return_400_Status_Due_to_Negative_Param_EndDate() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=-1"))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_500_Status_Due_to_No_Params() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-queue-trends/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_500_Status_Due_to_Invalid_ParamType() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=a", "&endTime=b"))
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    private static long parseTimeToMillis(final String dateTime) {
        final String SERVER_DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm:ss";
        final long timeInMillis =
                DateTime.parse(dateTime, DateTimeFormat.forPattern(SERVER_DATE_TIME_FORMAT)).toDateTime(DateTimeZone.UTC).getMillis();
        return timeInMillis;
    }
}
