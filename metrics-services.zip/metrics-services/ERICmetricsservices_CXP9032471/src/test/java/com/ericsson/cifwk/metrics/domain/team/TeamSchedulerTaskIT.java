
package com.ericsson.cifwk.metrics.domain.team;

import static com.jayway.restassured.RestAssured.when;
import static java.lang.String.format;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.index.query.QueryBuilders;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.ericsson.cifwk.metrics.team.Team;
import com.ericsson.cifwk.metrics.team.TeamScheduledTask;

import io.netty.handler.codec.http.HttpHeaders;

@SprintFixture
public class TeamSchedulerTaskIT extends AbstractIntegrationTest {

	private static ClientAndServer mockServer;

	@Autowired
	private TeamScheduledTask teamScheduledTask;

	@BeforeClass
	public static void tearUp() {
		mockServer = startClientAndServer(CI_MOCK_SERVER_PORT);
	}

	@AfterClass
	public static void tearDown() {
		mockServer.stop();
	}

	@Before
	public void reset() {
		mockServer.reset();
	}

	@Test
	@Fixtures(dropIndex = true, fixtures = { @Fixture(type = "teams", mapping = "/team/team-mapping.json") })
	@ServerDateTime("26-10-2015 09:00:00")
	public void shouldSaveTeamWithGivenValues() throws Exception {

		final HttpRequest requestSprintVelocity = request().withPath("/ci-portal");
		mockServer.when(requestSprintVelocity)
				.respond(response()
						.withHeaders(new Header(HttpHeaders.Names.CONTENT_TYPE,
								MediaType.APPLICATION_JSON_VALUE))
				.withBody(
						"[{\"artifacts\":[\"ERIC3gppexporttransformationprovider_CXP9031328\"],\"parentElement\":\"CM\",\"team\":\"Apollo\"}]"));

		// Execution
		teamScheduledTask.updateTeamInformation();
		// Retrieving values from DB after task execution

		final SearchQuery query = new NativeSearchQueryBuilder().withIndices("ci-events").withTypes("teams")
				.withQuery(QueryBuilders.matchAllQuery()).build();
		final List<Team> teams = queryAndWaitCount(query, Team.class, 1);
		Assert.assertEquals(1, teams.size());

		// Verification
		Assert.assertEquals("Apollo", teams.get(0).getTeam());
		Assert.assertEquals("CM", teams.get(0).getParentElement());
		List<String> artifacts = new ArrayList<>();
		artifacts.add("ERIC3gppexporttransformationprovider_CXP9031328");
		Assert.assertEquals(artifacts, teams.get(0).getArtifacts());

	}

	@Test
	@Fixtures(dropIndex = true, fixtures = { @Fixture(type = "teams", mapping = "/team/team-mapping.json") })
	@ServerDateTime("26-10-2015 09:00:00")
	public void shouldReturnNotFoundWhenMappingIsNotCorrect() {

		final HttpRequest requestSprintVelocity = request().withPath("/ci-portal");
		mockServer.when(requestSprintVelocity)
				.respond(response()
						.withHeaders(new Header(HttpHeaders.Names.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
						.withBody("{\"team\": \"CM\"}"));
		when().get(format("%S", requestSprintVelocity)).then().statusCode(HttpStatus.NOT_FOUND.value());

	}
}
