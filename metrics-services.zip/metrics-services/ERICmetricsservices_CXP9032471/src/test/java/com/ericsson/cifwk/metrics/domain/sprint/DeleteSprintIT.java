
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class DeleteSprintIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/sprint";

    @Test
    public void test_Should_Delete_Sprint_With_Status_No_Content() {
        when().delete(format("%s%s%s", basicUrl, END_POINT, "/16.1/")).then().statusCode(HttpStatus.OK.value());
    }

    @Test
    public void test_Should_Return_Status_Not_Found() {
        when().delete(format("%s%s%s", basicUrl, END_POINT, "/16.7/")).then().statusCode(HttpStatus.NOT_FOUND.value());
    }

    @Test
    public void test_Should_Not_Delete_Due_To_Empty_ResourcePath() {
        when().delete(format("%s%s%s", basicUrl, END_POINT, "")).then().statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
}
