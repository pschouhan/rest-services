
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.jayway.restassured.response.Response;

@SprintFixture
public class ReleaseFlowIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/release-flow";

    private static void assertReleaseFlowData(final String data, final Integer dataPosition, final String iso, final Integer build,
            final Integer depoly, final Integer deployWait, final Integer mtep, final Integer mtepWait, final Integer rfa, final Integer rfaWait,
            final Integer rvb, final Integer rvbWait) {
        Assert.assertEquals(from(data).get("[" + dataPosition + "].iso"), iso);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].build.duration"), build);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].deploy.duration"), depoly);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].mte.duration"), mtep);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].rvb.duration"), rvb);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].rfa.duration"), rfa);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].deployWait.duration"), deployWait);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].mteWait.duration"), mtepWait);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].rvbWait.duration"), rvbWait);
        Assert.assertEquals(from(data).get("[" + dataPosition + "].rfaWait.duration"), rfaWait);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/to-and-from-not-null.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowWhenBothMasterVersionsNotMatchWithRegEx() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=1.18.3a&to=aa.bb.cc")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/to-and-from-not-null.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowWhenMasterVersionIsNotMatchingRegEx() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=1.18.33&to=aa.bb.cc")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/release-flow/happy.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlow() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 1, 1, 1, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/release-flow/more-than-one-iso.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowWithMoreThanOneIso() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(2));
        assertReleaseFlowData(responseString, 0, "1.18.3", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 1, "1.18.4", 1, 1, 1, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/release-flow/different-sprint.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowWithExtraSprintData() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 1, 1, 1, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/release-flow/different-sprint.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("20-01-2016 12:00:00")
    public void testReleaseFlowDifferentSprint() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.2", 1, 1, 1, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/happy.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowWhenOneOutOfFromAndToIsNull() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=1.18.3&to=")).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/to-and-from-not-null.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowWhenFromAndToIsNotNull() {
        final Response response = when().get(format("%s%s%s", basicUrl, END_POINT, "?from=1.18.2&to=1.18.3"));
        response.equals(null);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/common/no-data.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowNoData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/common/no-master-version-data.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowNoMasterVersionData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/common/no-drop-data.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowNoDropData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/empty-master-version.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowEmptyMasterVersion() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 0, 1, 0, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/empty-drop.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowEmptyDrop() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 0, 1, 0, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/missing-build-loop.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowMissingBuildLoop() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 0, 1, 0, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/missing-deploy-loop.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowMissingDeployLoop() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 1, 0, 0, 1, 0, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/missing-mte-p-loop.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowMissingMtepLoop() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 1, 1, 1, 0, 0, 1, 0, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/missing-rfa-loop.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowMissingRFALoop() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 1, 1, 1, 1, 2, 0, 0, 1, 0);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/missing-rvb-loop.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowMissingRVBLoop() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 1, 1, 1, 1, 2, 1, 2, 0, 0);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/duration-unknown.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testReleaseFlowDurationUnknownNoStartedOrFinishedLevel() {
        final Response response = when().get(format("%s%s", basicUrl, END_POINT));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertReleaseFlowData(responseString, 0, "1.18.3", 0, 1, 0, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/duplicate-data.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testToRemoveDuplicates() {
        final Response response = when().get(format("%s%s%s", basicUrl, END_POINT, "?from=1.17.3&to=1.18.5"));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(5));
        assertReleaseFlowData(responseString, 0, "1.17.3", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 1, "1.17.41", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 2, "1.18.3", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 3, "1.18.4", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 4, "1.18.5", 1, 1, 1, 1, 2, 1, 2, 1, 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/release-flow/sorted-master.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("01-02-2016 12:00:00")
    public void testSortedMasterVersions() {
        final Response response = when().get(format("%s%s%s", basicUrl, END_POINT, "?from=1.16.18&to=1.18.51"));
        final String responseString = response.asString();
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(4));
        assertReleaseFlowData(responseString, 0, "1.16.18", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 1, "1.17.3", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 2, "1.17.41", 1, 1, 1, 1, 2, 1, 2, 1, 2);
        assertReleaseFlowData(responseString, 3, "1.18.51", 1, 1, 1, 1, 2, 1, 2, 1, 2);
    }
}
