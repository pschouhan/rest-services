/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

public class MockServerDateTime implements ServerDateTime {

    private DateTime dateTime = new DateTime();

    @Override
    public DateTime getCurrentDateTime() {
        return dateTime.toDateTime(DateTimeZone.UTC);
    }

    public void setDateTime(final DateTime newDateTime) {
        dateTime = newDateTime.toDateTime(DateTimeZone.UTC);
    }

    @Override
    public String toString() {
        return dateTime.toString();
    }

}
