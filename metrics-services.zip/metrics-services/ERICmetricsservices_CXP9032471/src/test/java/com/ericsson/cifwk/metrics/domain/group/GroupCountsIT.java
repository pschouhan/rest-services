
package com.ericsson.cifwk.metrics.domain.group;

import static java.lang.String.format;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class GroupCountsIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/group-counts";
    @Autowired
    private com.ericsson.cifwk.metrics.domain.ServerDateTime serverDateTime;

    @Test
    @ServerDateTime("12-12-2015 12:00:00")
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/normal-data.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_Default_TimePeriod_With_Status_Deliverd() {
        final String s = get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0", "&status=DELIVERED")).asString();
        final int artifact = from(s).get("artifactCount");
        final int group = from(s).get("groupCount");
        final int testware = from(s).get("testwareCount");
        final String startDate = from(s).getString("startDate");
        final String endDate = from(s).getString("endDate");
        Assert.assertEquals(2, artifact);
        Assert.assertEquals(2, testware);
        Assert.assertEquals(3, group);
        Assert.assertEquals("05/12/2015", startDate);
        Assert.assertEquals("03/01/2016", endDate);
    }

    @Test
    @ServerDateTime("12-12-2015 12:00:00")
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/no-delivery.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Zero_Count_for_All_Due_To_No_Delivery_In_DB() {
        final String s = get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0", "&status=DELIVERED")).asString();
        final int artifact = from(s).get("artifactCount");
        final int group = from(s).get("groupCount");
        final int testware = from(s).get("testwareCount");
        final String startDate = from(s).getString("startDate");
        final String endDate = from(s).getString("endDate");
        Assert.assertEquals(0, artifact);
        Assert.assertEquals(0, testware);
        Assert.assertEquals(0, group);
        Assert.assertEquals("05/12/2015", startDate);
        Assert.assertEquals("03/01/2016", endDate);
    }

    @Test
    @ServerDateTime("12-12-2015 12:00:00")
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/normal-data-obsoleted.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_Default_TimePeriod_With_Status_obsoleted() {
        final String s = get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0", "&status=OBSOLETED")).asString();
        final int artifact = from(s).get("artifactCount");
        final int group = from(s).get("groupCount");
        final int testware = from(s).get("testwareCount");
        final String startDate = from(s).getString("startDate");
        final String endDate = from(s).getString("endDate");
        Assert.assertEquals(1, artifact);
        Assert.assertEquals(2, testware);
        Assert.assertEquals(2, group);
        Assert.assertEquals("05/12/2015", startDate);
        Assert.assertEquals("03/01/2016", endDate);
    }

    @Test
    @ServerDateTime("12-12-2015 12:00:00")
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/normal-data-obsoleted.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_Default_TimePeriod_Status_Non_CaseSenstive() {
        final String s = get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0", "&status=ObSoLeTeD")).asString();
        final int artifact = from(s).get("artifactCount");
        final int group = from(s).get("groupCount");
        final int testware = from(s).get("testwareCount");
        final String startDate = from(s).getString("startDate");
        final String endDate = from(s).getString("endDate");
        Assert.assertEquals(1, artifact);
        Assert.assertEquals(2, testware);
        Assert.assertEquals(2, group);
        Assert.assertEquals("05/12/2015", startDate);
        Assert.assertEquals("03/01/2016", endDate);

    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/normal-data.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Zero_Count_for_All_Due_To_Delivery_In_TimePeriod() {
        final long startTime = parseTimeToMillis("24-12-2015 12:00:00");
        final long endTime = parseTimeToMillis("31-12-2015 12:00:00");
        final String s =
                get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime, "&status=DELIVERED")).asString();
        final int artifact = from(s).get("artifactCount");
        final int group = from(s).get("groupCount");
        final int testware = from(s).get("testwareCount");
        final String startDate = from(s).getString("startDate");
        final String endDate = from(s).getString("endDate");
        Assert.assertEquals(0, artifact);
        Assert.assertEquals(0, testware);
        Assert.assertEquals(0, group);
        Assert.assertEquals("24/12/2015", startDate);
        Assert.assertEquals("31/12/2015", endDate);
    }

    @Test
    @ServerDateTime("12-12-2015 12:00:00")
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/boundary-data.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_In_Boundary() {
        final String s = get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0", "&status=DELIVERED")).asString();
        final int artifact = from(s).get("artifactCount");
        final int group = from(s).get("groupCount");
        final int testware = from(s).get("testwareCount");
        final String startDate = from(s).getString("startDate");
        final String endDate = from(s).getString("endDate");
        Assert.assertEquals(1, artifact);
        Assert.assertEquals(1, testware);
        Assert.assertEquals(1, group);
        Assert.assertEquals("05/12/2015", startDate);
        Assert.assertEquals("03/01/2016", endDate);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Larger_StartTime_than_EndTime_Params() {
        final long endTime = parseTimeToMillis("30-11-2015 17:00:00");
        final long startTime = parseTimeToMillis("01-11-2015 17:00:00");
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=" + endTime, "&endTime=" + startTime, "&status=DELIVERED"))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Null_Params() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=", "&endTime=", "&status="))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_White_Space_Status() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0", "&status=  "))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Null_Status() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0", "&status="))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Negative_Param_StartDate() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=-1", "&endTime=", "&status=DELIVERED"))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    public void test_Should_Return_400_Status_Due_to_Negative_Param_EndDate() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=-1", "&status=DELIVERED"))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_500_Status_Due_to_No_Params() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-counts/out-of-time.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_500_Status_Due_to_Invalid_ParamType() {
        when().get(format("%s%s%s%s%s", basicUrl, END_POINT, "?startTime=a", "&endTime=b", "&status=DELIVERED"))
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    private static long parseTimeToMillis(final String dateTime) {
        final String SERVER_DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm:ss";
        final long timeInMillis =
                DateTime.parse(dateTime, DateTimeFormat.forPattern(SERVER_DATE_TIME_FORMAT)).toDateTime(DateTimeZone.UTC).getMillis();
        return timeInMillis;
    }

}
