/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class KgbCloudIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/kgb-cloud";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/happy-path.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testFirstDayOfThreeWeekInformationwillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.15"))
                .body("currentIsoKGBCloud", equalTo("1.15.49"))
                .body("currentProductKGBCloud", equalTo("15.0.50"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/old-sprint.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testOlderThanThreeWeekInformationWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/no-CDB.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testNoCDBInformationWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/no-finishedLevel-Complete.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testNoISOSuccessWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/completedEvent-false.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testNoCompletedEventTrueWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/latest-masterLevel.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testSortOfMasterLevelWillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.16"))
                .body("currentIsoKGBCloud", equalTo("1.15.49"))
                .body("currentProductKGBCloud", equalTo("16.0.50"));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/duplication-removal.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testDuplicationOfMasterLevelWillReturnLatestKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.15"))
                .body("currentIsoKGBCloud", equalTo("1.15.49"))
                .body("currentProductKGBCloud", equalTo("17.0.50"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/recentSuccessKGB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testFailingMostRecentKGBWillReturnLatestKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.16"))
                .body("currentIsoKGBCloud", equalTo("1.15.48"))
                .body("currentProductKGBCloud", equalTo("16.0.50"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/kgbWithNoCautionStatus.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testCloudKGBWithNoCautionStatusWillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.16"))
                .body("currentIsoKGBCloud", equalTo("1.16.3"))
                .body("currentProductKGBCloud", equalTo("1.0.3"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/kgbwithCautionStatus.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testCloudKGBWithCautionStatusWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/kgbWithOrWithoutCautionStatus.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testKGBWithCautionStatusAndWithoutCautionWillReturnExpectedResult() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("1.16.2"))
                .body("currentProductKGBCloud", equalTo("1.0.2"));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/regexAlphanumericCheck.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testAlphanumericMasterVersionRegexWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/regexStringCheck.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testMasterVersionHavingStringWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/regexWhenMasterVersionBlank.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testRegexMasterVersionBlankWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("Not Set"))
                .body("currentProductKGBCloud", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/no-Caution-CDB.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testCautionNoCDBInformationWillReturnExpectedKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("1.16.3"))
                .body("currentProductKGBCloud", equalTo("1.0.3"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/no-finishedLevel-information.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testCautionNoFinishedLevelInformationWillReturnExpectedKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("1.16.3"))
                .body("currentProductKGBCloud", equalTo("1.0.3"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/caution-completedEvent-false.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testCautionCompletedEventFalseInformationWillReturnExpectedKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("1.16.3"))
                .body("currentProductKGBCloud", equalTo("1.0.3"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/kgb-cloud/beforeAndAfterBoundary.json" }) })
    @ServerDateTime("14-11-2015 00:00:00")
    public void testBoundaryDateBeforeAndAfterWillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBCloud", equalTo("1.16.2"))
                .body("currentProductKGBCloud", equalTo("1.0.3"));
    }
}
