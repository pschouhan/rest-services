
package com.ericsson.cifwk.metrics.domain.test.fixture;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.ANNOTATION_TYPE, ElementType.METHOD, ElementType.TYPE })
public @interface SprintFixture {
    /**
     * path for json file for mapping sprint type
     * 
     * @return
     */
    String mapping() default "common/sprint-mapping.json";

    /**
     * path for json file populating sprint index
     * 
     * @return
     */
    String sprintData() default "/common/allsprints.json";

    /**
     * index name
     * 
     * @return
     */
    String index() default "sprints";

    /**
     * type name
     * 
     * @return
     */
    String type() default "sprint";

}
