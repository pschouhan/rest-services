
package com.ericsson.cifwk.metrics.domain.jira;

import static java.lang.String.format;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static com.jayway.restassured.RestAssured.when;
import io.netty.handler.codec.http.HttpHeaders;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Header;
import org.mockserver.model.Parameter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class SprintVelocityIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/sprint-velocity";
    private static final String SPRINT = "%sprintValue%";
    private static final String SPRINT_NOT_IN_FORMAT = "%sprintNIFValue%";

    private static ClientAndServer mockJiraServer;
   
    @Value("${sprint.burndown}")
    private String sprintBurndownQuery;

    @Value("${sprint.commitment}")
    private String sprintCommitmentQuery;

    @BeforeClass
    public static void tearUp() {
        mockJiraServer = startClientAndServer(JIRA_MOCK_SERVER_PORT);
    }

    @AfterClass
    public static void tearDown() {
        mockJiraServer.stop();
    }

    @Before
    public void reset() {
        mockJiraServer.reset();
    }

    @Test
    @ServerDateTime("10-11-2015 12:00:00")
    public void testCommitsForToday() {

        // Sprint Velocity
		String query = sprintBurndownQuery.replace(SPRINT, "15.16")
				.replace(SPRINT_NOT_IN_FORMAT, "15.16");
        mockJiraServer
                .when(request()
                        .withPath("/rest/scriptrunner-jira/latest/jqlfunctions/aggregateResult")
                        .withQueryStringParameters(
                                new Parameter(
                                        "jql",
                                        query
                                )
                        )
                )
                .respond(response()
                        .withHeaders(new Header(HttpHeaders.Names.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                        .withBody("{\"velocity\": \"900\"}")
                );

        // Sprint total commitment
		query = sprintCommitmentQuery.replace(SPRINT, "15.16")
				.replace(SPRINT_NOT_IN_FORMAT, "15.16");
        mockJiraServer
                .when(request()
                        .withPath("/rest/scriptrunner-jira/latest/jqlfunctions/aggregateResult")
                        .withQueryStringParameters(
                                new Parameter(
                                        "jql",
                                        query
                                )
                        )
                )
                .respond(response()
                        .withHeaders(new Header(HttpHeaders.Names.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                        .withBody("{\"total\": \"1000\"}")
                );

        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("completed", equalTo("900.0"))
                .body("total", equalTo("1000.0"));
    }

    @Test
    @ServerDateTime("10-11-2015 12:00:00")
    public void testFailureToCommunicateWithJira() {
        mockJiraServer
                .when(request()
                        .withPath("/rest/scriptrunner-jira/latest/jqlfunctions/aggregateResult")
                )
                .respond(response()
                        .withStatusCode(HttpStatus.BAD_REQUEST.value())
                );

        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("total", equalTo("0.0"))
                .body("completed", equalTo("0.0"));
    }
}
