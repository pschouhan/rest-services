package com.ericsson.cifwk.metrics.domain.group;

import static java.lang.String.format;
import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class DeliveriesTrendsRangeIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/deliveries-trends-range";

    private static void assertDeliveriesTrendData(
            final Map<String, Object> data, final String dateTime,
            final String day, final int deliveredArtifactCount, 
            final int deliveredTestwareCount, final int deliveredGroupCount, 
            final int obsoletedArtifactCount, final int obsoletedTestwareCount, final int obsoletedGroupCount) {
        Assert.assertEquals(data.get("dateTime"), dateTime);
        Assert.assertEquals(data.get("day"), day);
        Assert.assertEquals(data.get("deliveredArtifactCount"), deliveredArtifactCount);
        Assert.assertEquals(data.get("deliveredTestwareCount"), deliveredTestwareCount);
        Assert.assertEquals(data.get("deliveredGroupCount"), deliveredGroupCount);
        Assert.assertEquals(data.get("obsoletedArtifactCount"), obsoletedArtifactCount);
        Assert.assertEquals(data.get("obsoletedTestwareCount"), obsoletedTestwareCount);
        Assert.assertEquals(data.get("obsoletedGroupCount"), obsoletedGroupCount);
    }

    private static Map<String, Object> getJson(final String from, final int index) {
        final Map<String, Object> map = from(from).get("[" + index + "]");
        return map;
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends-range/deliveries-trends-range-1.json" }) })
    @ServerDateTime("31-10-2015 12:00:00")
    public void testDeliveriesTrendsWillReturnExpectedData() {
        final long startTime = parseTimeToMillis("28-10-2015 17:00:00");
        final long endTime = parseTimeToMillis("17-11-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-28T00:00:00.000Z", "28/10", 60, 1, 1, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-29T00:00:00.000Z", "29/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-30T00:00:00.000Z", "30/10", 10, 10, 1, 40, 1, 1);
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-31T00:00:00.000Z", "31/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 4), "2015-11-01T00:00:00.000Z", "01/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-02T00:00:00.000Z", "02/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-03T00:00:00.000Z", "03/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-04T00:00:00.000Z", "04/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-05T00:00:00.000Z", "05/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-06T00:00:00.000Z", "06/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-07T00:00:00.000Z", "07/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-08T00:00:00.000Z", "08/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-09T00:00:00.000Z", "09/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-10T00:00:00.000Z", "10/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-11T00:00:00.000Z", "11/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-12T00:00:00.000Z", "12/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-13T00:00:00.000Z", "13/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-14T00:00:00.000Z", "14/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-15T00:00:00.000Z", "15/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-16T00:00:00.000Z", "16/11", 70, 9, 2, 10, 5, 1);
        assertDeliveriesTrendData(getJson(s, 20), "2015-11-17T00:00:00.000Z", "17/11", 30, 25, 1, 0, 0, 0);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends-range/deliveries-trends-range-2.json" }) })
    @ServerDateTime("27-10-2015 12:00:00")
    public void testNoStatusInformationWillReturnZeroArtifactTestwareAndGroupCount() {
        final long startTime = parseTimeToMillis("27-10-2015 00:00:00");
        final long endTime = parseTimeToMillis("16-11-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", "27/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", "28/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", "29/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", "30/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", "31/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", "01/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", "02/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", "03/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", "04/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", "05/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", "06/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", "07/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", "08/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", "09/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", "10/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", "11/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", "12/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", "13/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", "14/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", "15/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 20), "2015-11-16T00:00:00.000Z", "16/11", 0, 0, 0, 0, 0, 0);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends-range/deliveries-trends-range-3.json" }) })
    @ServerDateTime("31-10-2015 12:00:00")
    public void testRangeBoundariesWillReturnExpectedData() {
        final long startTime = parseTimeToMillis("27-10-2015 00:00:00");
        final long endTime = parseTimeToMillis("16-11-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", "27/10", 60, 6, 1, 40, 4, 1);
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", "28/10", 0, 0, 0, 95, 10, 1);
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", "29/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", "30/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", "31/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", "01/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", "02/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", "03/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", "04/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", "05/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", "06/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", "07/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", "08/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", "09/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", "10/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", "11/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", "12/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", "13/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", "14/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", "15/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 20), "2015-11-16T00:00:00.000Z", "16/11", 90, 8, 1, 0, 0, 0);
    }    

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Larger_StartTime_than_EndTime_Params() {
        final long endTime = parseTimeToMillis("27-10-2015 00:00:00");
        final long startTime = parseTimeToMillis("06-12-2015 17:00:00");
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Null_Params() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=", "&endTime="))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_500_Status_Due_to_No_Params() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_500_Status_Due_to_Invalid_ParamType() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=a", "&endTime=b"))
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Negative_Param_StartDate() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=-1", "&endTime=0"))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_400_Status_Due_to_Negative_Param_EndDate() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=-1"))
                .then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/common/no-data.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("30-11-2015 17:00:00")
    public void test_Should_Return_NoData_Due_To_EmptyDB() {
        final long startTime = parseTimeToMillis("27-10-2015 00:00:00");
        final long endTime = parseTimeToMillis("06-11-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", "27/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", "28/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", "29/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", "30/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", "31/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", "01/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", "02/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", "03/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", "04/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", "05/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", "06/11", 0, 0, 0, 0, 0, 0);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-5.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("28-10-2015 17:00:00")
    public void test_Should_Return_Data_In_Default_TimePeriod() {
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0")).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", "27/10", 50, 3, 1, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", "28/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", "29/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", "30/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", "31/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", "01/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", "02/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", "03/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", "04/11", 11, 4, 1, 15, 7, 1);
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", "05/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", "06/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", "07/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", "08/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", "09/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", "10/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", "11/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", "12/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", "13/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", "14/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", "15/11", 30, 15, 2, 0, 0, 0);
    }
    
    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("28-10-2015 17:00:00")
    public void test_Should_Return_NoData_In_Default_TimePeriod() {
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=0", "&endTime=0")).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", "27/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", "28/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", "29/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", "30/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", "31/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", "01/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", "02/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", "03/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", "04/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", "05/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", "06/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", "07/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", "08/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", "09/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", "10/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", "11/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", "12/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", "13/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", "14/11", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", "15/11", 0, 0, 0, 0, 0, 0);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/group/delivery-trends-range/deliveries-trends-range-4.json" },
                    mapping = "/group/group-mapping.json") })
    public void test_Should_Return_NoData_In_Custom_TimePeriod() {
        final long endTime = parseTimeToMillis("10-10-2015 17:00:00");
        final long startTime = parseTimeToMillis("01-10-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-01T00:00:00.000Z", "01/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-02T00:00:00.000Z", "02/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-03T00:00:00.000Z", "03/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-04T00:00:00.000Z", "04/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-05T00:00:00.000Z", "05/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 5), "2015-10-06T00:00:00.000Z", "06/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 6), "2015-10-07T00:00:00.000Z", "07/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 7), "2015-10-08T00:00:00.000Z", "08/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 8), "2015-10-09T00:00:00.000Z", "09/10", 0, 0, 0, 0, 0, 0);
        assertDeliveriesTrendData(getJson(s, 9), "2015-10-10T00:00:00.000Z", "10/10", 0, 0, 0, 0, 0, 0);
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "group", files = { "/common/no-data.json" },
                    mapping = "/group/group-mapping.json") })
    @ServerDateTime("30-11-2015 17:00:00")
    public void test_Should_Return_Too_Many_Days_To_Load() {
    	final long startTime = parseTimeToMillis("07-10-2015 00:00:00");
        final long endTime = parseTimeToMillis("26-11-2015 17:00:00");
        final String s = get(format("%s%s%s%s", basicUrl, END_POINT, "?startTime=" + startTime, "&endTime=" + endTime)).asString();
        Assert.assertEquals(getJson(s, 0).get("info"), "Too many days to load");
    }
 
    private static long parseTimeToMillis(final String dateTime) {
        final String SERVER_DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm:ss";
        final long timeInMillis =
                DateTime.parse(dateTime, DateTimeFormat.forPattern(SERVER_DATE_TIME_FORMAT)).toDateTime(DateTimeZone.UTC).getMillis();
        return timeInMillis;
    }

}
