/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2016
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.test;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.IntegrationTestPropertiesListener;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.web.WebAppConfiguration;

import com.ericsson.cifwk.metrics.domain.MockServerDateTime;
import com.ericsson.cifwk.metrics.domain.MockServerDateTimeConfig;
import com.ericsson.cifwk.metrics.domain.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.es.EmbeddedElasticsearchServerConfig;
import com.jayway.restassured.RestAssured;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = { EmbeddedElasticsearchServerConfig.class, MockServerDateTimeConfig.class })
@WebAppConfiguration
@IntegrationTest({ "server.port:0", "test.basic.url:http://localhost/metrics-services",
    "sprints.filename:integration-test-sprint.json", "jira.url:http://localhost:18789", "ciPortal.url:http://localhost:18788/ci-portal" , "es.data.limit:21", "current.release:16A" })
@ActiveProfiles(value = "integration-test")
@TestExecutionListeners(listeners = { IntegrationTestPropertiesListener.class, DependencyInjectionTestExecutionListener.class,
    DirtiesContextTestExecutionListener.class, MetricsServicesTestExecutionListener.class })
public abstract class AbstractIntegrationTest {

    /**
     * This must match the port on the property 'jira.url'
     */
    protected static final int JIRA_MOCK_SERVER_PORT = 18789;
    
    protected static final int CI_MOCK_SERVER_PORT = 18788;

    @Autowired
    private ServerDateTime serverDateTime;

    @Autowired
    private ElasticsearchTemplate esTemplate;

    @Value("${local.server.port}")
    private int port;

    @Value("${test.basic.url}")
    protected String basicUrl;

    @Before
    public void before() {
        RestAssured.port = port;
    }

    @After
    public void after() {
        // resets the server time after every test
        ((MockServerDateTime) serverDateTime).setDateTime(new DateTime());
    }

    public <T> List<T> queryAndWaitCount(final SearchQuery query, final Class<T> clazz, final int count) throws Exception {
        for (int safeCount = 0; safeCount <= 20; safeCount++) {
            Thread.sleep(500);
            final List<T> list = esTemplate.queryForList(query, clazz);
            if (list.size() >= count) {
                return list;
            }
        }
        return new ArrayList<T>();
    }
}
