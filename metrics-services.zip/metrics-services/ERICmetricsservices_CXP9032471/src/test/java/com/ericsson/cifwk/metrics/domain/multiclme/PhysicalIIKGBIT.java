/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.multiclme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class PhysicalIIKGBIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/physical-ii-kgb";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/physical-ii-kgb/happy-path.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testFirstDayOfThreeWeekInformationwillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.16"))
                .body("physicalIIKGB", equalTo("15.0.50"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/physical-ii-kgb/old-sprint.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testOlderThanThreeWeekInformationWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("physicalIIKGB", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/physical-ii-kgb/no-CDB.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testNoCDBInformationWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("physicalIIKGB", equalTo("Not Set"));
    }



    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/physical-ii-kgb/latest-productVersionLevel.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testSortOfProductSetLevelWillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.16"))
                .body("physicalIIKGB", equalTo("15.0.52"));

    }
    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
        files = { "/multiclme/physical-ii-kgb/latest-productVersionLevel-dates-reversed.json" }) })
    @ServerDateTime("18-11-2015 00:00:00")
    public void testSortOfProductSetLevelReversedDatesWillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
            .statusCode(HttpStatus.OK.value())
            .body("drop", equalTo("15.16"))
            .body("physicalIIKGB", equalTo("15.0.52"));

    }


    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/physical-ii-kgb/duplication-removal.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testDuplicationOfProductSetLevelWillReturnLatestKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.16"))
                .body("physicalIIKGB", equalTo("15.0.50"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/physical-ii-kgb/recentSuccessKGB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testFailingMostRecentKGBWillReturnLatestKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.16"))
                .body("physicalIIKGB", equalTo("15.0.51"));
    }


}
