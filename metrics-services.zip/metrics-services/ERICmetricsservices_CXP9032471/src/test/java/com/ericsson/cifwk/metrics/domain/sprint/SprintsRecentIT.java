
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.core.IsCollectionContaining.hasItems;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class SprintsRecentIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/sprints-recent";

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void test_Should_Return_5Sprints() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?size=5"))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(5))
                .body("name", hasItems("16.4", "16.3", "16.2", "16.1", "15.17"))
                .body("endDate",
                        hasItems("2016-03-06T23:59:59.999Z", "2016-02-14T23:59:59.999Z", "2016-01-24T23:59:59.999Z", "2016-01-03T23:59:59.999Z",
                                "2015-12-04T23:59:59.999Z"))
                .body("startDate",
                        hasItems("2016-02-15T00:00:00.000Z", "2016-01-25T00:00:00.000Z", "2016-01-04T00:00:00.000Z", "2015-12-05T00:00:00.000Z",
                                "2015-11-16T00:00:00.000Z"));

    }

    @Test
    @ServerDateTime("15-12-2015 12:00:00")
    public void test_Should_Return_2Sprints() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?size=2"))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(2))
                .body("name", hasItems("16.1", "15.17"))
                .body("endDate",
                        hasItems("2016-01-03T23:59:59.999Z",
                                "2015-12-04T23:59:59.999Z"))
                .body("startDate",
                        hasItems("2015-12-05T00:00:00.000Z",
                                "2015-11-16T00:00:00.000Z"));

    }

    @Test
    @ServerDateTime("15-12-2015 12:00:00")
    public void test_Should_Return_4Sprints() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?size=999"))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(4))
                .body("name", hasItems("16.1", "15.17", "15.16", "15.15"))
                .body("endDate",
                        hasItems("2016-01-03T23:59:59.999Z",
                                "2015-12-04T23:59:59.999Z", "2015-11-15T23:59:59.999Z", "2015-10-26T23:59:59.999Z"))
                .body("startDate",
                        hasItems("2015-12-05T00:00:00.000Z",
                                "2015-11-16T00:00:00.000Z", "2015-10-27T00:00:00.000Z", "2015-10-06T00:00:00.000Z"));

    }

    @Test
    @ServerDateTime("15-12-2015 12:00:00")
    public void test_Should_Return_Error_Due_to_Missing_Parameter() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
}
