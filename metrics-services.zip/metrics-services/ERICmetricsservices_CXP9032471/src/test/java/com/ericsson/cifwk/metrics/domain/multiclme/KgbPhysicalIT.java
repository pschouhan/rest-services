
package com.ericsson.cifwk.metrics.domain.multiclme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class KgbPhysicalIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/kgb-physical";

  @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/happy-path.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testFirstDayOfThreeWeekInformationwillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.17"))
                .body("currentIsoKGBPhysical", equalTo("1.15.49"))
                .body("currentProductKGBPhysical", equalTo("17.0.50"));
    }

   @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/old-sprint.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testOlderThanThreeWeekInformationWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBPhysical", equalTo("Not Set"))
                .body("currentProductKGBPhysical", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/no-CDB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testNoCDBInformationWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBPhysical", equalTo("Not Set"))
                .body("currentProductKGBPhysical", equalTo("Not Set"));
    }

   @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/no-finishedLevel-Complete.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testNoISOSuccessWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBPhysical", equalTo("Not Set"))
                .body("currentProductKGBPhysical", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/completedEvent-false.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testNoCompletedEventTrueWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentIsoKGBPhysical", equalTo("Not Set"))
                .body("currentProductKGBPhysical", equalTo("Not Set"));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/latest.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testLastestWillReturnExpectedData() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.17"))
                .body("currentIsoKGBPhysical", equalTo("1.15.50"))
                .body("currentProductKGBPhysical", equalTo("17.0.51"));
    }



   @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/duplication-removal.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testDuplicationOfMasterLevelWillReturnLatestKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.17"))
                .body("currentIsoKGBPhysical", equalTo("1.15.49"))
                .body("currentProductKGBPhysical", equalTo("17.0.50"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "multiclme", mapping = "/multiclme/multiclme-mapping.json",
            files = { "/multiclme/kgb-physical/recentSuccessKGB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testFailingMostRecentKGBWillReturnLatestKGB() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("drop", equalTo("15.17"))
                .body("currentIsoKGBPhysical", equalTo("1.15.49"))
                .body("currentProductKGBPhysical", equalTo("17.0.50"));
    }

}
