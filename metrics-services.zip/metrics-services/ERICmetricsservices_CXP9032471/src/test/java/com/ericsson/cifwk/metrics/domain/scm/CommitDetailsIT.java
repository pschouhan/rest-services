
package com.ericsson.cifwk.metrics.domain.scm;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class CommitDetailsIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/commit-details";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/commit-details/commit-details-1.json" }) })
    @ServerDateTime("10-11-2015 12:00:00")
    public void testCommitsForToday() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("commitsForToday", equalTo("3"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/commit-details/commit-details-1.json" }) })
    @ServerDateTime("01-06-2015 12:00:00")
    public void testNoCommitsFoundForToday() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("commitsForToday", equalTo("0"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/commit-details/commit-details-1.json" }) })
    public void testEventTimeFieldEmpty() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("commitsForToday", equalTo("0"));
    }

}
