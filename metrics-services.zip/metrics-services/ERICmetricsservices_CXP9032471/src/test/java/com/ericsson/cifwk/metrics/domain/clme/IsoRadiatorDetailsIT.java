
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class IsoRadiatorDetailsIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/isoRadiator-details";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/iso-radiator-details/iso-radiator-details-1.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("26-11-2015 12:00:00")
    public void testIsoRadiatorDetailsReturnExpectedTop4List() {
        // happy path.
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(4))
                .root("find { it.isoVersion == '1.15.49'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.50"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"))
                .root("find { it.isoVersion == '1.15.45'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.45"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"))
                .root("find { it.isoVersion == '1.15.42'}")
                .body("overall", equalTo("FAILURE"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.42"))
                .body("mte", equalTo("FAILURE"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"))
                .root("find { it.isoVersion == '1.15.40'}")
                .body("overall", equalTo("FAILURE"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.40"))
                .body("mte", equalTo("FAILURE"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/iso-radiator-details/iso-radiator-details-2.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("26-11-2015 12:00:00")
    public void testIsoRadiatorDetailsReturnExpectedTop4ListWhenMoreThan4Data() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(4))
                .root("find { it.isoVersion == '1.15.49'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.50"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"))
                .root("find { it.isoVersion == '1.15.45'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.45"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"))
                .root("find { it.isoVersion == '1.15.42'}")
                .body("overall", equalTo("FAILURE"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.42"))
                .body("mte", equalTo("FAILURE"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"))
                .root("find { it.isoVersion == '1.15.40'}")
                .body("overall", equalTo("FAILURE"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.40"))
                .body("mte", equalTo("FAILURE"))
                .body("rfa", equalTo(""))
                .body("drop", equalTo("15.17"));

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/iso-radiator-details/iso-radiator-details-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("26-11-2015 12:00:00")
    public void testIsoRadiatorDetailsReturnExpectedRFA() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(1))
                .root("find { it.isoVersion == '1.15.49'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.50"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo("IN PROGRESS"))
                .body("drop", equalTo("15.17"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/iso-radiator-details/iso-radiator-details-4.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("26-11-2015 12:00:00")
    public void testIsoRadiatorDetailsReturnsLastRFA() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(1))
                .root("find { it.isoVersion == '1.15.49'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.50"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo("SUCCESS"))
                .body("drop", equalTo("15.17"));
    }

}
