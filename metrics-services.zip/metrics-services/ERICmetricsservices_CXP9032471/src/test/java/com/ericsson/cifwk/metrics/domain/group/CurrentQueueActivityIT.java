
package com.ericsson.cifwk.metrics.domain.group;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class CurrentQueueActivityIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/current-queue-activity";

    @Test
    @ServerDateTime("12-10-2015 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/current-queue-activity/current-queue-activity-2.json" }) })
    public void testDeliveriesTeam() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(5))
                .body("queuePercentage", equalTo(172))
                .body("artifactsInQueue", equalTo(20))
                .body("queueLength", equalTo(30))
                .body("artifactPercentage", equalTo(25))
                .body("info", equalTo("valid"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/current-queue-activity/current-queue-activity-1.json" }) })
    @ServerDateTime("09-10-2015 12:00:00")
    public void testNoDataTodayAndHasDataYesterday() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(5))
                .body("queuePercentage", equalTo(0))
                .body("artifactsInQueue", equalTo(0))
                .body("queueLength", equalTo(0))
                .body("artifactPercentage", equalTo(0))
                .body("info", equalTo("% difference not available"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/current-queue-activity/current-queue-activity-1.json" }) })
    @ServerDateTime("10-10-2015 12:00:00")
    public void testNoDataYesterdayAndHasDataToday() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(5))
                .body("queuePercentage", equalTo(0))
                .body("artifactsInQueue", equalTo(0))
                .body("queueLength", equalTo(0))
                .body("artifactPercentage", equalTo(0))
                .body("info", equalTo("% difference not available"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/current-queue-activity/current-queue-activity-1.json" }) })
    @ServerDateTime("06-10-2015 12:00:00")
    public void testNoDataTodayNorYesterday() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(5))
                .body("queuePercentage", equalTo(0))
                .body("artifactsInQueue", equalTo(0))
                .body("queueLength", equalTo(0))
                .body("artifactPercentage", equalTo(0))
                .body("info", equalTo("% difference not available"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/current-queue-activity/current-queue-activity-3.json" }) })
    @ServerDateTime("13-10-2015 12:00:00")
    public void testNoDropInformation() {
    	when().get(format("%s%s", basicUrl, END_POINT)).then()
        .statusCode(HttpStatus.OK.value()).body("size()", equalTo(5))
        .body("artifactsInQueue", equalTo(0))
        .body("queueLength", equalTo(0))
        .body("info", equalTo("% difference not available"));
    }

}
