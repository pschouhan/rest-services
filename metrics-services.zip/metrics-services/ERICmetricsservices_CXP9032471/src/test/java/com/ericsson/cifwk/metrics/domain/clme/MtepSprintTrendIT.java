
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.jayway.restassured.response.Response;

@SprintFixture
public class MtepSprintTrendIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/mtep-sprint-trend";

    private static void assertMtepSprintTrendData(final Map<String, Object> data, final int total, final int success,
            final String sprint, final int failure) {
        Assert.assertEquals(data.get("total"), total);
        Assert.assertEquals(data.get("SUCCESS"), success);
        Assert.assertEquals(data.get("sprint"), sprint);
        Assert.assertEquals(data.get("FAILURE"), failure);
    }

    private static Map<String, Object> getJson(final String from, final int index) {
        final Map<String, Object> map = from(from).get("[" + index + "]");
        return map;
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-1.json" }) })
    @ServerDateTime("21-01-2016 12:00:00")
    public void testMtepSprintTrendWillReturnExpectedData() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertMtepSprintTrendData(getJson(s, 0), 6, 4, "16.2", 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-2.json" }) })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendMultipleSprintsWillReturnExpectedData() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertMtepSprintTrendData(getJson(s, 1), 6, 4, "16.2", 2);
        assertMtepSprintTrendData(getJson(s, 0), 5, 3, "16.1", 2);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendRangeEnteredWillReturnExpectedData() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2"));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(3));
        final String s = response.asString();
        assertMtepSprintTrendData(getJson(s, 2), 6, 4, "16.2", 2);
        assertMtepSprintTrendData(getJson(s, 1), 5, 3, "16.1", 2);
        // TODO :: need to do an investigation why mvn build fails showing data is null while value is 0
        // follow up :: http://jira-nam.lmera.ericsson.se/browse/CIS-23114
        assertMtepSprintTrendData(getJson(s, 0), 3, 2, "15.17", 1);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendRangeEnteredSwappedToAndFromWillReturnExpectedData() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?to=16.2&from=15.17"));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(3));
        final String s = response.asString();
        assertMtepSprintTrendData(getJson(s, 2), 6, 4, "16.2", 2);
        assertMtepSprintTrendData(getJson(s, 1), 5, 3, "16.1", 2);
        // follow up :: http://jira-nam.lmera.ericsson.se/browse/CIS-23114
        assertMtepSprintTrendData(getJson(s, 0), 3, 2, "15.17", 1);
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendCharEnteredWillReturnErrorMessage() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=$&to=16.2")).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendNonSprintNumberEnteredWillReturnErrorMessage() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=10&to=11")).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendLetterEnteredWillReturnErrorMessage() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=x")).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendExtraPeriodEnteredWillReturnErrorMessage() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=15.16.1&to=16.2")).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendFromGreaterThanToEnteredWillReturnErrorMessage() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=16.2&to=15.17")).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/mtep-sprint-trend/mtep-sprint-trend-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("25-01-2016 12:00:00")
    public void testMtepSprintTrendNothingEnteredWillReturnLast5() {
        when().get(format("%s%s", basicUrl, END_POINT, "?from=&to=")).then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(5));
    }
}
