
package com.ericsson.cifwk.metrics.domain.sprint;

import static org.junit.Assert.assertEquals;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.mockserver.verify.VerificationTimes.once;
import io.netty.handler.codec.http.HttpHeaders;

import java.util.Map;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.Parameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.ericsson.cifwk.metrics.sprint.SprintScheduledTask;
import com.ericsson.cifwk.metrics.sprint.SprintService;

@SprintFixture
public class SprintSchedulerTaskIT extends AbstractIntegrationTest {
    private static final String SPRINT = "%sprintValue%";
    private static final String SPRINT_NOT_IN_FORMAT = "%sprintNIFValue%";
    
    private static ClientAndServer mockJiraServer;
   
    @Value("${sprint.burndown}")
    private String sprintBurndownQuery;

    @Value("${sprint.commitment}")
    private String sprintCommitmentQuery;

    @Autowired
    private SprintService service;

    @Autowired
    private SprintScheduledTask sprintScheduledTask;

    @BeforeClass
    public static void tearUp() {
        mockJiraServer = startClientAndServer(JIRA_MOCK_SERVER_PORT);
    }

    @AfterClass
    public static void tearDown() {
        mockJiraServer.stop();
    }

    @Before
    public void reset() {
        mockJiraServer.reset();
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "sprint", mapping = "/common/sprint-mapping.json") })
    @ServerDateTime("26-10-2015 09:00:00")
    public void shouldUpdatePointsValueForSprintWithGivenValues() {

		String query = sprintBurndownQuery.replace(SPRINT, "15.15")
				.replace(SPRINT_NOT_IN_FORMAT, "15.15");
        final HttpRequest requestSprintVelocity = request().withPath(
                "/rest/scriptrunner-jira/latest/jqlfunctions/aggregateResult")
                .withQueryStringParameters(new Parameter("jql", query));
        mockJiraServer.when(requestSprintVelocity).respond(
                response().withHeaders(
                        new Header(HttpHeaders.Names.CONTENT_TYPE,
                                MediaType.APPLICATION_JSON_VALUE)).withBody(
                        "{\"velocity\": \"900\"}"));

		query = sprintCommitmentQuery.replace(SPRINT, "15.15")
				.replace(SPRINT_NOT_IN_FORMAT, "15.15");
        final HttpRequest requestExpectedVelocity = request().withPath(
                "/rest/scriptrunner-jira/latest/jqlfunctions/aggregateResult")
                .withQueryStringParameters(new Parameter("jql", query));
        mockJiraServer.when(requestExpectedVelocity).respond(
                response().withHeaders(
                        new Header(HttpHeaders.Names.CONTENT_TYPE,
                                MediaType.APPLICATION_JSON_VALUE)).withBody(
                        "{\"total\": \"1000\"}"));

        // Execution
        sprintScheduledTask.updateSprintVelocity();
        // Retrieving values from DB after task execution
        final Map<String, String> result = service.getCurrentSprintDetails();

        // Verification
        assertEquals(result.get("committedPoints"), "1000.0");
        assertEquals(result.get("completedPoints"), "900.0");

        mockJiraServer.verify(requestSprintVelocity, once());
        mockJiraServer.verify(requestExpectedVelocity, once());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "sprint", mapping = "/common/sprint-mapping.json") })
    @ServerDateTime("26-10-2015 09:00:00")
    public void shouldUpdatePointsValueForSprintWithZeroValues() {
        // Execution
        sprintScheduledTask.updateSprintVelocity();
        // Retrieving values from DB after task execution
        final Map<String, String> result = service.getCurrentSprintDetails();

        // Verification
        assertEquals(result.get("committedPoints"), "0.0");
        assertEquals(result.get("completedPoints"), "0.0");
    }

}
