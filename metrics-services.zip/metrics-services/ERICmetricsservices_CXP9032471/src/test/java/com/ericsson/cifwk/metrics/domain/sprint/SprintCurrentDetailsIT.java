
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class SprintCurrentDetailsIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/sprint-current-details";

    @Test
    @ServerDateTime("10-10-2015 12:00:00")
    public void testSprintDetailsForMiddleOfSprint() {
        // sprint: 15.15, day: 5
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("sprint", equalTo("15.15"))
                .body("duration", equalTo("21"))
                .body("daysFinished", equalTo("5"))
                .body("start", equalTo("1444089600000"))
                .body("end", equalTo("1445903999999"))
                .body("daysRemaining", equalTo("16"))
                .body("today", equalTo("10/10/2015"));
    }

    @Test
    @ServerDateTime("06-10-2015 00:00:00")
    public void testSprintDetailsForFirstDay() {
        // sprint: 15.15, day: 1
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("sprint", equalTo("15.15"))
                .body("daysFinished", equalTo("1"))
                .body("start", equalTo("1444089600000"))
                .body("end", equalTo("1445903999999"))
                .body("daysRemaining", equalTo("20"))
                .body("today", equalTo("06/10/2015"));
    }

    @Test
    @ServerDateTime("26-10-2015 12:00:00")
    public void testSprintDetailsForLastDay() {
        // sprint: 15.15, day: 21
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("sprint", equalTo("15.15"))
                .body("daysFinished", equalTo("21"))
                .body("start", equalTo("1444089600000"))
                .body("end", equalTo("1445903999999"))
                .body("daysRemaining", equalTo("0"))
                .body("today", equalTo("26/10/2015"));
    }

    @Test
    @ServerDateTime("07-03-2016 12:00:00")
    public void testSprintDetailsGetNearestOpen() {

        when().get(format("%s%s", basicUrl, END_POINT))
            .then()
            .statusCode(HttpStatus.OK.value())
            .body("sprint", equalTo("16.5"))
            .body("daysFinished", equalTo("1"))
            .body("start", equalTo("1457395200000"))
            .body("end", equalTo("1459036799999"))
            .body("daysRemaining", equalTo("19"))
            .body("today", equalTo("07/03/2016"));
    }

    @Test
    @ServerDateTime("27-03-2016 12:00:00")
    public void testSprintDetailsGetPreviousOpen() {

        when().get(format("%s%s", basicUrl, END_POINT))
            .then()
            .statusCode(HttpStatus.OK.value())
            .body("sprint", equalTo("16.5"))
            .body("daysFinished", equalTo("20"))
            .body("start", equalTo("1457395200000"))
            .body("end", equalTo("1459036799999"))
            .body("daysRemaining", equalTo("0"))
            .body("today", equalTo("27/03/2016"));
    }

}
