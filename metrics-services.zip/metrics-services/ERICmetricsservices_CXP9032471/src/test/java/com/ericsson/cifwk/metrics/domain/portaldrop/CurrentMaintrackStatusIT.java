
package com.ericsson.cifwk.metrics.domain.portaldrop;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class CurrentMaintrackStatusIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/current-maintrack-status";

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "portaldrop", files = { "/portaldrop/current-maintrack-status/portaldrop-correct.json" },
                    mapping = "/portaldrop/portaldrop-mapping.json") })
    @ServerDateTime("01-11-2015 17:00:00")
    public void testCurrentMainTrackStatus() {
        // Testing latest maintrack status from different portal drop entries
        when().get(format("%s%s", basicUrl, END_POINT)).
                then().
                statusCode(HttpStatus.OK.value()).
                body("status", equalTo("open"),
                        "eventTime", equalTo("2015-10-26T06:13:37.360Z"),
                        "reason", equalTo("Some reason"));
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "portaldrop", files = { "/portaldrop/current-maintrack-status/portaldrop-non-enm.json" },
                    mapping = "/portaldrop/portaldrop-mapping.json") })
    @ServerDateTime("10-11-2015 17:00:00")
    public void testNoENMInformation() {
        // Testing latest maintrack status from different portal drop which doesn't have a ENM product
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("status", equalTo("open"), "eventTime", equalTo(null));
    }

    @Test
    @Fixtures(
            dropIndex = true,
            fixtures = { @Fixture(type = "portaldrop", files = { "/portaldrop/current-maintrack-status/portaldrop-invalid-drop.json" },
                    mapping = "/portaldrop/portaldrop-mapping.json") })
    @ServerDateTime("10-11-2015 17:00:00")
    public void testNoDropInformation() {
        // Testing latest maintrack status from different portal drop which have only drops that's invalid for time given
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("status", equalTo("open"), "eventTime", equalTo(null));
    }

    @Test
    @Fixtures(dropIndex = true,
            fixtures = { @Fixture(type = "portaldrop", files = { "/portaldrop/current-maintrack-status/portaldrop-correct-closed.json" },
                    mapping = "/portaldrop/portaldrop-mapping.json") })
    @ServerDateTime("05-11-2015 17:00:00")
    public void testPortalColsed() {
        // Testing latest maintrack status from different portal drop entries , this should show maintrack status as closed
        when().get(format("%s%s", basicUrl, END_POINT)).
                then().
                statusCode(HttpStatus.OK.value()).
                body("status", equalTo("closed"),
                        "eventTime", equalTo("2015-10-26T06:13:37.360Z"),
                        "reason", equalTo("Sprint over"));
    }
}
