/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2015
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.test.fixture;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Can only be used inside {@link Fixtures}.
 */
@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.ANNOTATION_TYPE)
public @interface Fixture {

    /**
     * List of JSON files (paths) that will be loaded to the database.
     * E.G "/type/test.json"
     */
    String[] files() default {};

    /**
     * ES data type.
     * E.G "clme"
     */
    String type();

    /**
     * Mention the name of mapping file for ES (in json format) ,
     * this is a mandatory field ,without mapping all the tests and ES query will give incorrect results
     *
     * @return
     */
    String mapping();

}
