
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;
import static com.jayway.restassured.RestAssured.when;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

//TODO
//Separate test class due to sprint fixture is not properly supported at method level 
//found issue with asynchronicity. Created improvement CIP-12762, when done this test 
//must be located in SprintRangeDetailsIT
@SprintFixture(sprintData = "/common/no-data.json")
public class SprintRangeDetails_NoDataIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/sprint-range-details";
       
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testNoSPrintsInDBWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2")).then()
        .statusCode(HttpStatus.BAD_REQUEST.value());
    }

}
