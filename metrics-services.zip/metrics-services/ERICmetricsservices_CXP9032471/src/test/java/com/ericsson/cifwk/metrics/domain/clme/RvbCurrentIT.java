
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class RvbCurrentIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/rvb-current";
    
    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/happyPath.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentShouldReturnHigherMasterVersion() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentNodes", equalTo("10"))
                .body("currentStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.16"))
                .body("currentRVBIsoVersion", equalTo("1.15.50"))
                .body("currentRVBProductVersion", equalTo("15.16.51"));
    }
    
    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/OldSprintHasHighestMasterVersion.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentWhenSprintOutOfRangeHasHighestMasterVersionWillNotReturn() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentNodes", equalTo("3"))
                .body("currentStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.17"))
                .body("currentRVBIsoVersion", equalTo("1.15.50"))
                .body("currentRVBProductVersion", equalTo("15.17.51"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/duplicates.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentDuplicateShouldReturnOneItem() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentNodes", equalTo("3"))
                .body("drop", equalTo("15.16"))
                .body("currentStatus", equalTo("SUCCESS"))
                .body("currentRVBIsoVersion", equalTo("1.15.50"))
                .body("currentRVBProductVersion", equalTo("15.16.52"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/finishedLevelAndStartLevelNoRVB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentNoRecordForstartedLevelAndfinishedLevelShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentRVBIsoVersion", equalTo("Not Set"))
                .body("currentRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/sort.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentSameMasterVersionShouldReturnMaxNode() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentNodes", equalTo("23"))
                .body("currentStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.16"))
                .body("currentRVBIsoVersion", equalTo("1.15.50"))
                .body("currentRVBProductVersion", equalTo("15.16.52"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/startedLevelNoRVB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentStartedLevelWrongShouldReturnThatEntry() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentNodes", equalTo("3"))
                .body("currentStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.16"))
                .body("currentRVBIsoVersion", equalTo("1.15.50"))
                .body("currentRVBProductVersion", equalTo("15.16.52"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/finishedLevelNoRVB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentFinishedLevelWrongShouldReturnThatEntry() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentNodes", equalTo("3"))
                .body("currentStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.16"))
                .body("currentRVBIsoVersion", equalTo("1.15.50"))
                .body("currentRVBProductVersion", equalTo("15.16.52"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/messageTypeNoCDB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentNoRecordForMessageTypeShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentRVBIsoVersion", equalTo("Not Set"))
                .body("currentRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/masterVersionEmpty.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentMasterVersionEmptyShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentRVBIsoVersion", equalTo("Not Set"))
                .body("currentRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/maintrack-radiator-rvb-baseline/messageTypeEmpty.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentMessageTypeEmptyShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentRVBIsoVersion", equalTo("Not Set"))
                .body("currentRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/completedEventFalse.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbCurrentCompletedEventFalseShouldReturnMasterVersion() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentStatus", equalTo("IN PROGRESS"))
                .body("currentRVBIsoVersion", equalTo("1.15.49"))
                .body("currentRVBProductVersion", equalTo("15.16.51"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/regexAlphanumericCheck.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testAlphanumericMasterVersionRegexWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentRVBIsoVersion", equalTo("Not Set"))
                .body("currentRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/regexStringCheck.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testMasterVersionHavingStringWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentRVBIsoVersion", equalTo("Not Set"))
                .body("currentRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-current/regexWhenMasterVersionBlank.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testRegexMasterVersionBlankWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("currentRVBIsoVersion", equalTo("Not Set"))
                .body("currentRVBProductVersion", equalTo("Not Set"));
    }

}
