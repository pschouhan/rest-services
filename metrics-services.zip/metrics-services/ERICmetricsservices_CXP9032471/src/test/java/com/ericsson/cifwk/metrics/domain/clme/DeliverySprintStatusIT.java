
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class DeliverySprintStatusIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/delivery-sprint-status";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-1.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDeliverySprintStatus() {
        // happy path.
        // List should contain count for all data
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.15"))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(2))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(1))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-1.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testEmptySprintParameter() {
        // When sprint is ""
        // Will take sprint according to server date
        // List should contain count for all data
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint="))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(2))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(1))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-1.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testNullSprintParameter() {
        // When sprint is null
        // Will take sprint according to server date
        // List should contain count for all data
        when().get(format("%s%s", basicUrl, END_POINT))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(2))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(1))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-1.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testWrongStringAsSprintParameter() {
        // Will take sprint according to server date
        // As a invalid name should return empty list
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=wrongSprint"))
                .then().statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-1.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testOldSprintParameter() {
        // Will take sprint according to server date
        // As a invalid name should return empty list
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.10"))
                .then().statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-2.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testNoSprintInformation() {
        // DB has data but not related to the current sprint
        // List contains count to zero returned for elapsed sprint days
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.15"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(0))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(0))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-3.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testOneDataThisSprint() {
        // DB has one event between first day of the sprint, "today" is third day of the sprint
        // DB has besides another data in the future (error data) but inside this sprint
        // List should contain count = 1 for first event only in corresponding day
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.15"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(0))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(1))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-4.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testNoDropInformation() {
        // DB has data but none related to the searched drop
        // List should contain data for 3 days with count 0
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.15"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(0))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(0))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-5.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testNoProductInformation() {
        // DB has data but not related to ENM product
        // List should contain data for 3 days with count 0
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.15"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(0))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(0))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-6.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("26-10-2015 12:00:00")
    public void testSprintBoundaries() {
        // DB has more data then a sprint. Check if returns only 21 values (1 per day).
        // 'today' is placed as last day of sprint
        // List should return 9 Data in total in db, 7 returned in as count, 2 out of boundaries discarded
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.15"))
                .then().statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(21))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(2))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(1))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(3))
                .body("find { it.weekDay == 'Friday' }.deliveryCount", equalTo(1));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-sprint-status/delivery-sprint-status-7.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDBhasTestwareDataWillReturnOnlyDeliveriesData() {
        when().get(format("%s%s%s%s", basicUrl, END_POINT, "?", "sprint=15.15"))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("find { it.weekDay == 'Tuesday' }.deliveryCount", equalTo(1))
                .body("find { it.weekDay == 'Wednesday' }.deliveryCount", equalTo(2))
                .body("find { it.weekDay == 'Thursday' }.deliveryCount", equalTo(0));
    }

}
