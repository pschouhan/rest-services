
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class DeliveryTodayIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/delivery-today";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-today/delivery-today-1.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDeliveryTodayWillReturnExpectedDeliveriesCount() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("deliveriesToday", equalTo(2));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-today/delivery-today-2.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDBhasDataButNotRelatedToDropWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("deliveriesToday", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-today/delivery-today-3.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDBhasDataButNoTodayInformationWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("deliveriesToday", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-today/delivery-today-4.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDBhasDataButNotRelatedToProductWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("deliveriesToday", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-today/delivery-today-5.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDBhasDataButNotRelatedToMessageTypeWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("deliveriesToday", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = { "/clme/delivery-today/delivery-today-6.json" },
            mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("08-10-2015 12:00:00")
    public void testDBhasTestwareDataWillReturnOnlyDeliveriesData() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("deliveriesToday", equalTo(2));
    }

}
