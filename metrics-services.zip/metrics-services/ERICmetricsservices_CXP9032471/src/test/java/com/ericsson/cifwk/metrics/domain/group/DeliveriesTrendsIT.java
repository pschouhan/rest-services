
package com.ericsson.cifwk.metrics.domain.group;

import static java.lang.String.format;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class DeliveriesTrendsIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/deliveries-trends";

    private static void assertDeliveriesTrendData(
            final Map<String, Object> data, final String dateTime,
            final int deliveredArtifactCount, final int deliveredTestwareCount,
            final int deliveredGroupCount, final int obsoletedArtifactCount , 
            final int obsoletedGroupCount,final int obsoletedTestwareCount,final String weekDay) {
        Assert.assertEquals(data.get("dateTime"), dateTime);
        Assert.assertEquals(data.get("deliveredArtifactCount"), deliveredArtifactCount);
        Assert.assertEquals(data.get("deliveredGroupCount"), deliveredGroupCount);
        Assert.assertEquals(data.get("deliveredTestwareCount"), deliveredTestwareCount);
        Assert.assertEquals(data.get("obsoletedArtifactCount"), obsoletedArtifactCount);
        Assert.assertEquals(data.get("obsoletedGroupCount"), obsoletedGroupCount);
        Assert.assertEquals(data.get("obsoletedTestwareCount"), obsoletedTestwareCount);
        Assert.assertEquals(data.get("weekDay"), weekDay);
    }

    private static Map<String, Object> getJson(final String from, final int index) {
        final Map<String, Object> map = from(from).get("[" + index + "]");
        return map;
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends/deliveries-trends-1.json" }) })
    @ServerDateTime("31-10-2015 12:00:00")
    public void testDeliveriesTrendsWillReturnExpectedData() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", 110, 9, 2, 60, 2, 46, "Wk1.1");
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", 60, 1, 1, 50, 1, 12, "Wk1.2");
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", 30, 5, 1, 0, 0, 0, "Wk1.3");
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", 40, 1, 1, 0, 0, 0, "Wk1.4");
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", 100, 6, 1, 0, 0, 0, "Wk1.5");
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.6");
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", 0, 0, 0, 0, 0, 0,"Wk1.7");
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.1");
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.2");
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.3");
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", 0, 0, 0, 0, 0, 0,"Wk2.4");
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.5");
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.6");
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.7");
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.1");
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.2");
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.3");
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.4");
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.5");
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.6");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends/deliveries-trends-2.json" }) })
    @ServerDateTime("27-10-2015 12:00:00")
    public void testNoDropInformationWillReturnZeroArtifactTestwareAndGroupCount() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.1");
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.2");
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.3");
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.4");
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.5");
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.6");
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.7");
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.1");
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.2");
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.3");
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.4");
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.5");
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.6");
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.7");
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.1");
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.2");
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.3");
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.4");
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.5");
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.6");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends/deliveries-trends-3.json" }) })
    @ServerDateTime("28-10-2015 12:00:00")
    public void testNoSprintInformationWillReturnZeroArtifactTestwareAndGroupCount() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.1");
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.2");
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.3");
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.4");
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.5");
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.6");
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.7");
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.1");
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.2");
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.3");
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.4");
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.5");
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.6");
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.7");
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.1");
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.2");
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.3");
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.4");
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.5");
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.6");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends/deliveries-trends-4.json" }) })
    @ServerDateTime("27-10-2015 12:00:00")
    public void testNoStatusInformationWillReturnZeroArtifactTestwareAndGroupCount() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.1");
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.2");
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.3");
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.4");
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.5");
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.6");
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.7");
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.1");
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.2");
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.3");
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.4");
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.5");
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.6");
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.7");
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.1");
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.2");
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.3");
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.4");
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.5");
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.6");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", mapping = "/group/group-mapping.json",
            files = { "/group/delivery-trends/deliveries-trends-5.json" }) })
    @ServerDateTime("31-10-2015 12:00:00")
    public void testSprintBoundariesWillReturnExpectedData() {
        final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
        assertDeliveriesTrendData(getJson(s, 0), "2015-10-27T00:00:00.000Z", 50, 1, 1, 50, 1, 10, "Wk1.1");
        assertDeliveriesTrendData(getJson(s, 1), "2015-10-28T00:00:00.000Z", 60, 5, 1, 64, 1, 15, "Wk1.2");
        assertDeliveriesTrendData(getJson(s, 2), "2015-10-29T00:00:00.000Z", 30, 1, 1, 0, 0, 0, "Wk1.3");
        assertDeliveriesTrendData(getJson(s, 3), "2015-10-30T00:00:00.000Z", 40, 6, 1, 0, 0, 0, "Wk1.4");
        assertDeliveriesTrendData(getJson(s, 4), "2015-10-31T00:00:00.000Z", 100, 2, 1, 0, 0, 0, "Wk1.5");
        assertDeliveriesTrendData(getJson(s, 5), "2015-11-01T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.6");
        assertDeliveriesTrendData(getJson(s, 6), "2015-11-02T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk1.7");
        assertDeliveriesTrendData(getJson(s, 7), "2015-11-03T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.1");
        assertDeliveriesTrendData(getJson(s, 8), "2015-11-04T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.2");
        assertDeliveriesTrendData(getJson(s, 9), "2015-11-05T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.3");
        assertDeliveriesTrendData(getJson(s, 10), "2015-11-06T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.4");
        assertDeliveriesTrendData(getJson(s, 11), "2015-11-07T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.5");
        assertDeliveriesTrendData(getJson(s, 12), "2015-11-08T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.6");
        assertDeliveriesTrendData(getJson(s, 13), "2015-11-09T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk2.7");
        assertDeliveriesTrendData(getJson(s, 14), "2015-11-10T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.1");
        assertDeliveriesTrendData(getJson(s, 15), "2015-11-11T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.2");
        assertDeliveriesTrendData(getJson(s, 16), "2015-11-12T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.3");
        assertDeliveriesTrendData(getJson(s, 17), "2015-11-13T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.4");
        assertDeliveriesTrendData(getJson(s, 18), "2015-11-14T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.5");
        assertDeliveriesTrendData(getJson(s, 19), "2015-11-15T00:00:00.000Z", 0, 0, 0, 0, 0, 0, "Wk3.6");
    }

}
