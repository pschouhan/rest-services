
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;

import static com.jayway.restassured.RestAssured.given;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.jayway.restassured.http.ContentType;

@SprintFixture(sprintData = "/sprint/update-sprint/to-be-updated.json")
public class UpdateSprintIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/sprint";

    @Test
    public void test_Should_Update_Existing_Sprint_Information() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.15\",\"startDate\": \"2015-10-06T00:00:00.000Z\", \"endDate\": \"2015-10-26T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.15/")).then().statusCode(HttpStatus.OK.value());
    }
    
    @Test
    public void test_Should_Update_Velocity_Sprint_Information() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.15\",\"startDate\": \"2015-10-06T00:00:00.000Z\", \"endDate\": \"2015-10-26T23:59:59.999Z\",\"release\": \"16A\",\"committedPoints\": \"4000.0\",\"completedPoints\": \"1500\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.15/")).then().statusCode(HttpStatus.OK.value());
    }

    @Test
    public void test_Should_Not_Update_Sprint_Due_To_No_Entity_In_DB() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.16\",\"startDate\": \"2015-10-27T00:00:00.000Z\", \"endDate\": \"2015-11-15T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.16/")).then().statusCode(HttpStatus.NOT_FOUND.value());
    }

    @Test
    public void test_Should_Not_Update_Due_To_Empty_ResourcePath() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.16\",\"startDate\": \"2015-10-27T00:00:00.000Z\", \"endDate\": \"2015-11-15T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "")).then().statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Null_StartDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Null_SprintName() {
        given().contentType(ContentType.JSON).body(
                "{\"startDate\": \"2015-10-27T00:00:00.000Z\", \"endDate\": \"2015-11-15T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Null_EndDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Null_Release() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"endDate\": \"2015-12-04T23:59:59.999Z\",\"endDate\": \"2015-12-04T23:59:59.999Z\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Invalid_DateFormat_StartDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16\",\"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Invalid_DateFormat_EndDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"endDate\": \"2015-12-04\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Empty_SprintName() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"  \", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_To_Empty_Release() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \" \"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.17/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Updated_Due_Mismatch_Of_Path_Variable_And_SprintName() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \"16A \"}")
                .when().put(format("%s%s%s", basicUrl, END_POINT, "/15.16/")).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }
}
