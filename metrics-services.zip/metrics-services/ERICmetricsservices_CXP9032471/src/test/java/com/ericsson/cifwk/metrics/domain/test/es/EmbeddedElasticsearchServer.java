/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2012
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.test.es;

import static org.elasticsearch.node.NodeBuilder.nodeBuilder;

import org.elasticsearch.client.Client;
import org.elasticsearch.client.node.NodeClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.springframework.beans.factory.InitializingBean;

/**
 * Create an embedded 'Elastic Search' server and wire it to the application.
 */
public class EmbeddedElasticsearchServer implements InitializingBean {

    private final NodeClient client;

    public EmbeddedElasticsearchServer() {
        final ImmutableSettings.Builder elasticsearchSettings = ImmutableSettings.settingsBuilder()
                .put("http.enabled", "false")
                .put("path.data", "target/elasticsearch-data");
        client = (NodeClient) nodeBuilder()
                .local(true)
                .settings(elasticsearchSettings.build())
                .node().client();
    }

    /**
     * Produces 'Elastic Search' client.
     *
     * @return client.
     */
    public Client getClient() {
        return client;
    }

    @Override
    public void afterPropertiesSet() throws Exception {}

}
