
package com.ericsson.cifwk.metrics.domain.scm;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class TeamPerformanceIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/team-performance";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/team-performance/team-performance-1.json" }) })
    public void testTeamPerformanceForCurrentSprint() {
        // This test checks the aggregation. Expected : Return teams and their
        // corresponding commits count of 15.15 sprint
        when().get(format("%s%s?sprint=15.15", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(1))
                .body("[0].team", equalTo("dharma"))
                .body("[0].commit", equalTo("2"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/team-performance/team-performance-2.json" }) })
    @ServerDateTime("01-11-2015 00:00:00")
    public void testEmptySprintParameter() {
        // This test checks when sprint name is "". Expected : Returns current
        // sprint's team and their commits
        when().get(format("%s%s?sprint=", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(2))
                .body("find { it.team == 'dharma' }.commit", equalTo("2"))
                .body("find { it.team == 'axis' }.commit", equalTo("2"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/team-performance/team-performance-2.json" }) })
    @ServerDateTime("01-11-2015 00:00:00")
    public void testNoSprintParameter() {
        // This test checks when sprint name is "". Expected : Returns current
        // sprint's team and their commits
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(2))
                .body("find { it.team == 'dharma' }.commit", equalTo("2"))
                .body("find { it.team == 'axis' }.commit", equalTo("2"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/team-performance/team-performance-2.json" }) })
    @ServerDateTime("01-11-2015 00:00:00")
    public void testWrongStringAsSprintParameter() {
        // This test checks when sprint name is "abc" (wrong sprint name).
        // Expected : empty list
        when().get(format("%s%s?sprint=abc", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/team-performance/team-performance-2.json" }) })
    @ServerDateTime("01-11-2015 00:00:00")
    public void testOldSprintParameter() {
        // This test checks when sprint name is old. Expected : empty list
        when().get(format("%s%s?sprint=15.1", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());

    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/team-performance/team-performance-4.json" }) })
    public void testEmptyTeam() {
        // Check with one team + empty team. Expected : Returns only team and
        // corresponding commits which has a team name
        when().get(format("%s%s?sprint=15.16", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(2))
                .body("find { it.team == 'dharma' }.commit", equalTo("1"))
                .body("find { it.team == '' }.commit", equalTo("2"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "scm", mapping = "/scm/scm-mapping.json",
            files = { "/scm/team-performance/team-performance-3.json" }) })
    public void testMoreThanTenTeams() {
        // Have more than 10 teams and check that only 10 is returned
        when().get(format("%s%s?sprint=15.16", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value()).body("size()", equalTo(10));
    }

}
