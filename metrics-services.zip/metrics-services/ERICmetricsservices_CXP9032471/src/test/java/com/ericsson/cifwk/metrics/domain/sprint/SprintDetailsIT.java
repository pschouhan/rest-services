
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;
import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.jayway.restassured.response.Response;

@SprintFixture
public class SprintDetailsIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/sprint-details";
    
	private static void assertSprintData(final Map<String, Object> data,
			final String name, final String startDate, final String endDate,
			final String release, final double committedPoints, final double completedPoints) {
		Assert.assertEquals(data.get("name"), name);
		Assert.assertEquals(data.get("startDate"), startDate);
		Assert.assertEquals(data.get("endDate"), endDate);
		Assert.assertEquals(data.get("release"), release);
		Assert.assertEquals(Double.parseDouble(data.get("committedPoints").toString()), committedPoints, 0);
		Assert.assertEquals(Double.parseDouble(data.get("completedPoints").toString()), completedPoints, 0);
	}

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testDefaultShouldReturnCurrentSprint() {
        final Response response = get(format("%s%s", basicUrl, END_POINT));
        response.then().statusCode(HttpStatus.OK.value());
        final String s = response.asString();
    	assertSprintData(from(s).get(), "16.4",  "2016-02-15T00:00:00.000Z", "2016-03-06T23:59:59.999Z", "16B", 4584.5, 358.5); 
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testSprintGivenValueWillReturn1Sprint() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?sprint=15.17"));
        response.then().statusCode(HttpStatus.OK.value());
        final String s = response.asString();
        assertSprintData(from(s).get(), "15.17", "2015-11-16T00:00:00.000Z", "2015-12-04T23:59:59.999Z", "16A", 4665.0, 4428.0);
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testSprintEmptyNameValueWillReturnDefaultCurrentSprint() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?sprint="));
        response.then().statusCode(HttpStatus.OK.value());
        final String s = response.asString();
    	assertSprintData(from(s).get(), "16.4",  "2016-02-15T00:00:00.000Z", "2016-03-06T23:59:59.999Z", "16B", 4584.5, 358.5);   
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testCharGivenAsSprintNameWillReturn400Error() {
    	final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?sprint=$"));
        response.then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testNotValidSprintNameGivenWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?sprint=10")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testLetterGivenAsSprintNameWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?sprint=x")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testNotExistingSprintGivenWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?sprint=15.10")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

}
