
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class MteTableDetailsIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/mtetable-details";

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-0.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testDBHasDataWillReturnAllData() {
        // Happy Path
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(9));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-1.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testOlderThanThreeWeekInformationWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT))
                .then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-2.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("15-11-2015 12:00:00")
    public void testDBHasDuplicatesDataWillRemoveOldest() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(2))
                .root("find { it.isoVersion == '1.15.63'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.65"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo(""))
                .body("eventTime", equalTo("2015-11-15T10:10:52.273Z"))
                .body("drop", equalTo("15.16"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-3.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testDBHasDataButNoCDBMessageTypeWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-4.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testDBHasDataButNoExpectedStartLevelWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-5.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("15-11-2015 12:00:00")
    public void testDBHasDataButNoExpectedFinishLevelWillReturnZero() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-6.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("15-11-2015 12:00:00")
    public void testDbHasDataWillReturnSortedDescByMasterLevel() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("[0].isoVersion", equalTo("1.15.63"))
                .body("[1].isoVersion", equalTo("1.15.62"))
                .body("[2].isoVersion", equalTo("1.15.58"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-7.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("15-11-2015 12:00:00")
    public void testDbHasEmptyMasterVersionWillReturnSortedDescByMasterLevelEmptyIsLast() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(3))
                .body("[0].isoVersion", equalTo("1.15.63"))
                .body("[1].isoVersion", equalTo("1.15.62"))
                .body("[2].isoVersion", equalTo(""));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-8.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testDbHasMoreThan10DataWillReturn10Data() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(10));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-9.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testWhenResultAndCompleteEventAreSuccessWillReturnOverallAndMTESuccess() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(2))
                .root("find { it.isoVersion == '1.15.63'}")
                .body("overall", equalTo("SUCCESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.65"))
                .body("mte", equalTo("SUCCESS"))
                .body("rfa", equalTo(""))
                .body("eventTime", equalTo("2015-11-15T16:10:52.273Z"))
                .body("drop", equalTo("15.16"))
                .root("find { it.isoVersion == '1.15.64'}")
                .body("overall", not(equalTo("SUCCESS")))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.67"))
                .body("mte", not(equalTo("SUCCESS")))
                .body("rfa", equalTo(""))
                .body("eventTime", equalTo("2015-11-15T07:33:17.052Z"))
                .body("drop", equalTo("15.16"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-10.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testWhenResultSuccessButNotCompleteEventWillReturnOverallAndMTEInProgress() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(2))
                .root("find { it.isoVersion == '1.15.52'}")
                .body("overall", equalTo("IN PROGRESS"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.53"))
                .body("mte", equalTo("IN PROGRESS"))
                .body("rfa", equalTo(""))
                .body("eventTime", equalTo("2015-11-14T22:16:35.655Z"))
                .body("drop", equalTo("15.16"))
                .root("find { it.isoVersion == '1.15.62'}")
                .body("overall", not(equalTo("IN PROGRESS")))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.64"))
                .body("mte", not(equalTo("IN PROGRESS")))
                .body("rfa", equalTo(""))
                .body("eventTime", equalTo("2015-11-14T06:42:21.956Z"))
                .body("drop", equalTo("15.16"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme",
            files = { "/clme/mte-table-details/mte-table-details-11.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("16-11-2015 12:00:00")
    public void testWhenResultIsNotSuccessWillReturnOverallAndMTEFailure() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(2))
                .root("find { it.isoVersion == '1.15.54'}")
                .body("overall", equalTo("FAILURE"))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.55"))
                .body("mte", equalTo("FAILURE"))
                .body("rfa", equalTo(""))
                .body("eventTime", equalTo("2015-11-15T11:47:31.753Z"))
                .body("drop", equalTo("15.16"))
                .root("find { it.isoVersion == '1.15.52'}")
                .body("overall", not(equalTo("FAILURE")))
                .body("groupId", equalTo("com.ericsson.oss"))
                .body("artifactId", equalTo("AOM901151"))
                .body("productVersion", equalTo("17.0.53"))
                .body("mte", not(equalTo("FAILURE")))
                .body("rfa", equalTo(""))
                .body("eventTime", equalTo("2015-11-15T01:26:02.044Z"))
                .body("drop", equalTo("15.16"));
    }

}
