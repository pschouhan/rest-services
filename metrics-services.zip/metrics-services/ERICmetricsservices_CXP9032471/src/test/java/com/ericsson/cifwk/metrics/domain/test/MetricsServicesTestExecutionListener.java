/*------------------------------------------------------------------------------
 *******************************************************************************
 * COPYRIGHT Ericsson 2016
 *
 * The copyright to the computer program(s) herein is the property of
 * Ericsson Inc. The programs may be used and/or copied only with written
 * permission from Ericsson Inc. or in accordance with the terms and
 * conditions stipulated in the agreement/contract under which the
 * program(s) have been supplied.
 *******************************************************************************
 *----------------------------------------------------------------------------*/

package com.ericsson.cifwk.metrics.domain.test;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.XContentType;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.data.elasticsearch.core.query.IndexQueryBuilder;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.support.AbstractTestExecutionListener;

import com.ericsson.cifwk.metrics.domain.MockServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

public class MetricsServicesTestExecutionListener extends AbstractTestExecutionListener {

    private static final String SERVER_DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm:ss";
    private static final String PROCESS_BEFORE_CLASS_ANNOTATION = "processBeforeClassAnnotation";

    private final Logger logger = LoggerFactory.getLogger(getClass());
    // Flag to detect ,if sprint index is populated for test class
    private boolean didSprintCreated = false;

    @Override
    public void beforeTestClass(final TestContext testContext) throws Exception {
        // can't process @Fixtures at class level here! If you try it will
        // start spring twice. This will be delayed to the #prepareTestInstance() method.
        // the flag bellow is to enforce the execution only once as
        // #prepareTestInstance() might run more than once.
        testContext.setAttribute(PROCESS_BEFORE_CLASS_ANNOTATION, Boolean.TRUE);
    }

    @Override
    public void afterTestClass(final TestContext testContext) throws Exception {
        // Making flag false after finishing each class
        didSprintCreated = false;
    }

    @Override
    public void prepareTestInstance(final TestContext testContext) throws Exception {
        final Boolean processBeforeClassAnnotation = (Boolean) testContext.getAttribute(PROCESS_BEFORE_CLASS_ANNOTATION);
        if (processBeforeClassAnnotation) {
            // get class level annotation
            processAnnotations(testContext);
            // done processing! won't do it again.
            testContext.setAttribute(PROCESS_BEFORE_CLASS_ANNOTATION, Boolean.FALSE);
        }
    }

    @Override
    public void beforeTestMethod(final TestContext testContext) throws Exception {
        // get method level annotation
        final Fixtures fixtures = testContext.getTestMethod().getAnnotation(Fixtures.class);
        processFixturesAnnotation(fixtures, testContext.getApplicationContext());
        // checks if server 'datetime' needs to be set
        final ServerDateTime serverDateTime = testContext.getTestMethod().getAnnotation(ServerDateTime.class);
        processServerDateTimeAnnotation(serverDateTime, testContext.getApplicationContext());
    }

    private void processAnnotations(final TestContext testContext) {
        final SprintFixture sprintFixture = testContext.getTestClass().getAnnotation(SprintFixture.class);
        processSprintFixtureAnnotation(sprintFixture, testContext.getApplicationContext());
        final Fixtures fixtures = testContext.getTestClass().getAnnotation(Fixtures.class);
        processFixturesAnnotation(fixtures, testContext.getApplicationContext());
    }

    private void processSprintFixtureAnnotation(final SprintFixture sprintFixture, final ApplicationContext context) {
        // this condition will block creating sprint index multiple time for a test class,thus make test execution time less for a class
        if (!didSprintCreated && sprintFixture != null) {
            final String index = sprintFixture.index();
            final String type = sprintFixture.type();
            final String mapping = sprintFixture.mapping();
            final String dataFile = sprintFixture.sprintData();
            dropIndex(context, index);
            readFileAndPopulateIndex(context, index, type, dataFile, mapping);
            didSprintCreated = true;
        }

    }

    private void processServerDateTimeAnnotation(final ServerDateTime serverDateTime, final ApplicationContext context) {
        if (serverDateTime == null || StringUtils.trimToNull(serverDateTime.value()) == null) {
            return;
        }
        try {
            final MockServerDateTime bean =
                    (MockServerDateTime) context.getBean(com.ericsson.cifwk.metrics.domain.ServerDateTime.class);
            final DateTime dateTime = DateTime.parse(serverDateTime.value(),
                    DateTimeFormat.forPattern(SERVER_DATE_TIME_FORMAT));

            bean.setDateTime(dateTime.withZoneRetainFields(DateTimeZone.UTC));

        } catch (final Exception e) {
            logger.warn("Ignoring set server datetime. Context:" + context, e);
        }
    }

    private void processFixturesAnnotation(final Fixtures fixtures, final ApplicationContext context) {
        if (fixtures != null) {
            // should drop index?
            if (fixtures.dropIndex()) {
                dropIndex(context, fixtures.index());
            }
            // populate ES
            populateIndex(fixtures.fixtures(), fixtures.index(), context);
        }
    }

    private void dropIndex(final ApplicationContext context, final String index) {
        final ElasticsearchTemplate esTemplate = context.getBean(ElasticsearchTemplate.class);
        esTemplate.deleteIndex(index);
        esTemplate.createIndex(index);
        esTemplate.refresh(index, true);
    }

    private void populateIndex(final Fixture[] fixtures, final String index, final ApplicationContext context) {
        final ElasticsearchTemplate esTemplate = context.getBean(ElasticsearchTemplate.class);
        for (final Fixture fixture : fixtures) {
            final String type = fixture.type();
            final String mapping = fixture.mapping();
            if (StringUtils.trimToNull(type) == null) {
                logger.warn("Ignoring fixture with empty 'type'. Context:" + context);
                continue;
            }
            for (final String file : fixture.files()) {
                if (StringUtils.trimToNull(file) == null) {
                    logger.warn("Ignoring fixture with empty 'file'. Context:" + context);
                    continue;
                }

                readFileAndPopulateIndex(context, index, type, file, mapping);
            }
        }
        // need to refresh index so the data is show
        esTemplate.refresh(index, true);
    }

    private void readFileAndPopulateIndex(final ApplicationContext context, final String index, final String type,
            final String file, final String mapping) {
        try {
            // read mapping file
            final ElasticsearchTemplate esTemplate = context.getBean(ElasticsearchTemplate.class);
            final String mappingStr = readFileFromClasspath(context, mapping);
            // defining mapping for type in index
            final XContentParser parser = XContentFactory.xContent(XContentType.JSON).createParser(mappingStr.getBytes());
            parser.close();
            final XContentBuilder contentBuilder = XContentFactory.jsonBuilder().copyCurrentStructure(parser);
            esTemplate.putMapping(index, type, contentBuilder);
            esTemplate.refresh(index, true);
            // read data file
            final String jsonStr = readFileFromClasspath(context, file);

            // the file content is expected to be an array
            final JSONArray jsonArray = new JSONArray(jsonStr);
            for (int i = 0; i < jsonArray.length(); i++) {
                // save the json to database
                final IndexQuery indexQuery =
                        new IndexQueryBuilder().withIndexName(index).withType(type).withSource(jsonArray.getJSONObject(i).toString()).build();
                esTemplate.index(indexQuery);
                esTemplate.refresh(index, true);
            }
        } catch (final Exception e) {
            logger.warn("Ignoring fixture, failed to read file. Context:" + context, e);
        }
    }

    private String readFileFromClasspath(final ApplicationContext context, final String mapping) throws IOException {
        final Resource resourceMapping = context.getResource("classpath:" + mapping);
        final String content = IOUtils.toString(resourceMapping.getInputStream(), "UTF-8");
        IOUtils.closeQuietly(resourceMapping.getInputStream());
        return content;
    }


}
