package com.ericsson.cifwk.metrics.domain.group;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static java.lang.String.format;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class QueueProfileDeliveriesIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/queue-profile-deliveries";

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/complete-test.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_Default_SprintRange() {
	final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	checkData(JSONResponseBody.getJSONObject(0), "15.16", 31, 1, 1, 65, 2, 5, 105, 3, 15, "27/10/2015",
		"02/11/2015", "03/11/2015", "09/11/2015", "10/11/2015", "15/11/2015");
	checkData(JSONResponseBody.getJSONObject(1), "15.17", 37, 1, 7, 38, 1, 8, 39, 1, 9, "16/11/2015", "22/11/2015",
		"23/11/2015", "29/11/2015", "30/11/2015", "04/12/2015");
	checkData(JSONResponseBody.getJSONObject(2), "16.1", 311, 1, 11, 322, 1, 22, 333, 1, 33, "05/12/2015",
		"11/12/2015", "12/12/2015", "18/12/2015", "19/12/2015", "03/01/2016");
	checkData(JSONResponseBody.getJSONObject(3), "16.2", 344, 1, 44, 355, 1, 55, 366, 1, 66, "04/01/2016",
		"10/01/2016", "11/01/2016", "17/01/2016", "18/01/2016", "24/01/2016");
	checkData(JSONResponseBody.getJSONObject(4), "16.3", 377, 1, 77, 388, 1, 88, 399, 1, 99, "25/01/2016",
		"31/01/2016", "01/02/2016", "07/02/2016", "08/02/2016", "14/02/2016");

    }

    private void checkData(JSONObject jsonObject, String sprint, int w1Artifact, int w1Group, int w1Testware,
	    int w2Artifact, int w2Group, int w2Testware, int w3Artifact, int w3Group, int w3Testware, String w1From,
	    String w1To, String w2From, String w2To, String w3From, String w3To) {

	Assert.assertEquals(jsonObject.getString("week1From"), w1From);
	Assert.assertEquals(jsonObject.getString("week2From"), w2From);
	Assert.assertEquals(jsonObject.getString("week3From"), w3From);
	Assert.assertEquals(jsonObject.getString("week1To"), w1To);
	Assert.assertEquals(jsonObject.getString("week2To"), w2To);
	Assert.assertEquals(jsonObject.getString("week3To"), w3To);
	Assert.assertEquals(jsonObject.getInt("artifactWeek1"), w1Artifact);
	Assert.assertEquals(jsonObject.getInt("groupsWeek1"), w1Group);
	Assert.assertEquals(jsonObject.getInt("testwareWeek1"), w1Testware);
	Assert.assertEquals(jsonObject.getInt("artifactWeek2"), w2Artifact);
	Assert.assertEquals(jsonObject.getInt("groupsWeek2"), w2Group);
	Assert.assertEquals(jsonObject.getInt("testwareWeek2"), w2Testware);
	Assert.assertEquals(jsonObject.getInt("artifactWeek3"), w3Artifact);
	Assert.assertEquals(jsonObject.getInt("groupsWeek3"), w3Group);
	Assert.assertEquals(jsonObject.getInt("testwareWeek3"), w3Testware);

    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-without-weeks.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_Filtering_SprintRange_Without_Weeks() {
	final String s = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2")).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	Assert.assertEquals(JSONResponseBody.getJSONObject(0).getString("sprint"), "15.17");
	Assert.assertEquals(JSONResponseBody.getJSONObject(1).getString("sprint"), "16.1");
	Assert.assertEquals(JSONResponseBody.getJSONObject(2).getString("sprint"), "16.2");
	Assert.assertEquals(JSONResponseBody.length(), 3);
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/complete-test.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_Filtering_SprintRange() {
	final String s = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2")).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	Assert.assertEquals(JSONResponseBody.getJSONObject(0).getString("sprint"), "15.17");
	Assert.assertEquals(JSONResponseBody.getJSONObject(1).getString("sprint"), "16.1");
	Assert.assertEquals(JSONResponseBody.getJSONObject(2).getString("sprint"), "16.2");
	Assert.assertEquals(JSONResponseBody.length(), 3);
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-one-week.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_Data_For_Filtering_SprintRange_One_Week_Per_Sprint() {
	final String s = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2")).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	Assert.assertEquals(JSONResponseBody.getJSONObject(0).getString("sprint"), "15.17");
	Assert.assertEquals(JSONResponseBody.getJSONObject(1).getString("sprint"), "16.1");
	Assert.assertEquals(JSONResponseBody.getJSONObject(2).getString("sprint"), "16.2");
	Assert.assertEquals(JSONResponseBody.length(), 3);
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-no-data-sprint.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_No_Sprint_If_Absent() {
	final String s = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2")).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	Assert.assertEquals(JSONResponseBody.getJSONObject(0).getString("sprint"), "15.17");
	Assert.assertEquals(JSONResponseBody.getJSONObject(1).getString("sprint"), "16.2");
	Assert.assertEquals(JSONResponseBody.length(), 2);
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-no-first-sprint.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_No_First_Sprint_If_Absent() {
	final String s = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2")).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	Assert.assertEquals(JSONResponseBody.getJSONObject(0).getString("sprint"), "16.1");
	Assert.assertEquals(JSONResponseBody.getJSONObject(1).getString("sprint"), "16.2");
	Assert.assertEquals(JSONResponseBody.length(), 2);
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-no-first--two-sprints.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_No_First_two_Sprints_If_Absent() {
	final String s = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2")).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	Assert.assertEquals(JSONResponseBody.getJSONObject(0).getString("sprint"), "16.2");
	Assert.assertEquals(JSONResponseBody.length(), 1);
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-no-intermediate-sprint.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Return_No_Intermediate_Sprints_If_Absent() {
	final String s = get(format("%s%s", basicUrl, END_POINT)).asString();
	JSONArray JSONResponseBody = new JSONArray(s);
	Assert.assertEquals(JSONResponseBody.getJSONObject(0).getString("sprint"), "15.16");
	Assert.assertEquals(JSONResponseBody.getJSONObject(1).getString("sprint"), "16.2");
	Assert.assertEquals(JSONResponseBody.length(), 2);
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-no-intermediate-sprint.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Throw_Exception_if_sprint_From_invalid() {
	when().get(format("%s%s", basicUrl, END_POINT + "?from=a")).then()
		.statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-no-intermediate-sprint.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Throw_Exception_if_sprint_To_invalid() {
	when().get(format("%s%s", basicUrl, END_POINT + "?to=a")).then()
		.statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("12-02-2016 12:00:00")
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "group", files = {
	    "/group/queue-profile-activities/test-no-intermediate-sprint.json" }, mapping = "/group/group-mapping.json") })
    public void test_Should_Throw_Exception_if_sprint_to_from_absent() {
	when().get(format("%s%s", basicUrl, END_POINT + "?to=15.16")).then()
		.statusCode(HttpStatus.BAD_REQUEST.value());
    }

}
