
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;
import static org.hamcrest.CoreMatchers.equalTo;
import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;
import static com.jayway.restassured.path.json.JsonPath.from;

import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.jayway.restassured.response.Response;

@SprintFixture
public class SprintRangeDetailsIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/sprint-range-details";
    
	private static void assertSprintData(final Map<String, Object> data,
			final String name, final String startDate, final String endDate,
			final String release, final double committedPoints, final double completedPoints) {
		Assert.assertEquals(data.get("name"), name);
		Assert.assertEquals(data.get("startDate"), startDate);
		Assert.assertEquals(data.get("endDate"), endDate);
		Assert.assertEquals(data.get("release"), release);
		Assert.assertEquals(Double.parseDouble(data.get("committedPoints").toString()), committedPoints, 0);
		Assert.assertEquals(Double.parseDouble(data.get("completedPoints").toString()), completedPoints, 0);
	}
    
    private static Map<String, Object> getJson(final String from, final int index) {
        final Map<String, Object> map = from(from).get("[" + index + "]");
        return map;
    }

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testDefaultShouldReturnLast5Sprints() {
        final Response response = get(format("%s%s", basicUrl, END_POINT));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(5));
        final String s = response.asString();
    	assertSprintData(getJson(s, 0), "15.17", "2015-11-16T00:00:00.000Z", "2015-12-04T23:59:59.999Z", "16A", 4665.0, 4428.0);
    	assertSprintData(getJson(s, 1), "16.1",  "2015-12-05T00:00:00.000Z", "2016-01-03T23:59:59.999Z", "16B", 4295.5, 2836.5);
    	assertSprintData(getJson(s, 2), "16.2",  "2016-01-04T00:00:00.000Z", "2016-01-24T23:59:59.999Z", "16B", 4359.0, 3668.0);
    	assertSprintData(getJson(s, 3), "16.3",  "2016-01-25T00:00:00.000Z", "2016-02-14T23:59:59.999Z", "16B", 5137.0, 3870.0);
    	assertSprintData(getJson(s, 4), "16.4",  "2016-02-15T00:00:00.000Z", "2016-03-06T23:59:59.999Z", "16B", 4584.5, 358.5);    	
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testSprintRangeGivenSameValueWillReturn1Sprint() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=15.17"));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        final String s = response.asString();
        assertSprintData(getJson(s, 0), "15.17", "2015-11-16T00:00:00.000Z", "2015-12-04T23:59:59.999Z", "16A", 4665.0, 4428.0);
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testSprintRangeGivenWillReturn3Sprints() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=16.2"));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(3));
        final String s = response.asString();
        assertSprintData(getJson(s, 0), "15.17", "2015-11-16T00:00:00.000Z", "2015-12-04T23:59:59.999Z", "16A", 4665.0, 4428.0);
        assertSprintData(getJson(s, 1), "16.1",  "2015-12-05T00:00:00.000Z", "2016-01-03T23:59:59.999Z", "16B", 4295.5, 2836.5);
        assertSprintData(getJson(s, 2), "16.2",  "2016-01-04T00:00:00.000Z", "2016-01-24T23:59:59.999Z", "16B", 4359.0, 3668.0);
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testSprintRangeGivenSwappedToAndFromWillReturnExpectedData() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?to=16.2&from=15.17"));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(3));
        final String s = response.asString();
        assertSprintData(getJson(s, 0), "15.17", "2015-11-16T00:00:00.000Z", "2015-12-04T23:59:59.999Z", "16A", 4665.0, 4428.0);
        assertSprintData(getJson(s, 1), "16.1",  "2015-12-05T00:00:00.000Z", "2016-01-03T23:59:59.999Z", "16B", 4295.5, 2836.5);
        assertSprintData(getJson(s, 2), "16.2",  "2016-01-04T00:00:00.000Z", "2016-01-24T23:59:59.999Z", "16B", 4359.0, 3668.0);
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testCharGivenAsSprintNameWillReturn400Error() {
    	final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?from=$&to=16.2"));
        response.then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testNotValidSprintNameGivenWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=10&to=11")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testLetterGivenAsSprintNameWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=15.17&to=x")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }
    
    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testNotExistingSprintsGivenWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=15.16&to=20.1")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testSprintRangeFromGreaterThanToWillReturn400Error() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?from=16.2&to=15.17")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @ServerDateTime("17-02-2016 12:00:00")
    public void testSprintEmptyNameValuesWillReturnDefaultLast5Sprints() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?from=&to="));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(5));
        final String s = response.asString();
    	assertSprintData(getJson(s, 0), "15.17", "2015-11-16T00:00:00.000Z", "2015-12-04T23:59:59.999Z", "16A", 4665.0, 4428.0);
    	assertSprintData(getJson(s, 1), "16.1",  "2015-12-05T00:00:00.000Z", "2016-01-03T23:59:59.999Z", "16B", 4295.5, 2836.5);
    	assertSprintData(getJson(s, 2), "16.2",  "2016-01-04T00:00:00.000Z", "2016-01-24T23:59:59.999Z", "16B", 4359.0, 3668.0);
    	assertSprintData(getJson(s, 3), "16.3",  "2016-01-25T00:00:00.000Z", "2016-02-14T23:59:59.999Z", "16B", 5137.0, 3870.0);
    	assertSprintData(getJson(s, 4), "16.4",  "2016-02-15T00:00:00.000Z", "2016-03-06T23:59:59.999Z", "16B", 4584.5, 358.5);   
    }

}
