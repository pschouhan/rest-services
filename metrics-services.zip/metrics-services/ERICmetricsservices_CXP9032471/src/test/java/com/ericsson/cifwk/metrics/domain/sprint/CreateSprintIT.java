
package com.ericsson.cifwk.metrics.domain.sprint;

import static java.lang.String.format;

import static com.jayway.restassured.RestAssured.given;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.jayway.restassured.http.ContentType;

@SprintFixture(sprintData = "/sprint/create-sprint/seed-sprint.json")
public class CreateSprintIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/sprint";

    @Test
    public void test_Sprint_Creation() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.15\",\"startDate\": \"2015-10-06T00:00:00.000Z\", \"endDate\": \"2015-10-26T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.CREATED.value());
    }

    @Test
    public void test_Sprint_Not_Created_Overlapping_date() {
        given().contentType(ContentType.JSON).body(
            "{\"name\": \"15.15\",\"startDate\": \"2015-10-28T00:00:00.000Z\", \"endDate\": \"2015-10-26T23:59:59.999Z\",\"release\": \"16A\"}")
            .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.CONFLICT.value());
    }

    @Test
    public void test_Sprint_Not_Created_AlreadyExists() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.16\",\"startDate\": \"2015-10-27T00:00:00.000Z\", \"endDate\": \"2015-11-15T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.CONFLICT.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Null_StartDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Null_SprintName() {
        given().contentType(ContentType.JSON).body(
                "{\"startDate\": \"2015-10-27T00:00:00.000Z\", \"endDate\": \"2015-11-15T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Null_EndDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Null_Release() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"endDate\": \"2015-12-04T23:59:59.999Z\",\"endDate\": \"2015-12-04T23:59:59.999Z\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Invalid_DateFormat_StartDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16\",\"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Invalid_DateFormat_EndDate() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"endDate\": \"2015-12-04\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Empty_SprintName() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"  \", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \"16A\"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    public void test_Sprint_Not_Creted_Due_To_Empty_Release() {
        given().contentType(ContentType.JSON).body(
                "{\"name\": \"15.17\", \"startDate\": \"2015-11-16T23:59:59.999Z\",\"endDate\": \"2015-12-04T23:59:59.999Z\",\"release\": \" \"}")
                .when().post(format("%s%s", basicUrl, END_POINT)).then().statusCode(HttpStatus.BAD_REQUEST.value());
    }
}
