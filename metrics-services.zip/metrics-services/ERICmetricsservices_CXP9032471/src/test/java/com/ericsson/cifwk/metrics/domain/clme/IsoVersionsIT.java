
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;
import com.jayway.restassured.response.Response;

@SprintFixture
public class IsoVersionsIT extends AbstractIntegrationTest {
    private static final String END_POINT = "/iso-versions";

    private static void assertIsoVersionData(final List<String> data, final int index, final String masterVersion) {
        Assert.assertEquals(data.get(index), masterVersion);
    }

    private static List<String> getJson(final Response response) {
        final List<String> array = Arrays.asList(response.getBody().as(String[].class));
        return array;
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/iso-versions/iso-versions.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListWillNotReturnDataDueToNoDropParam() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/iso-versions/iso-versions.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListDropEnteredWillReturn2Isos() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?drop=16.3"));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(2));
        assertIsoVersionData(getJson(response), 0, "1.18.75");
        assertIsoVersionData(getJson(response), 1, "1.18.4");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/iso-versions/iso-versions.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListDifferentDropEnteredWillReturn1Iso() {
        final Response response = get(format("%s%s%s", basicUrl, END_POINT, "?drop=15.17"));
        response.then().statusCode(HttpStatus.OK.value()).body("size()", equalTo(1));
        assertIsoVersionData(getJson(response), 0, "1.15.66");
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/iso-versions/iso-versions.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListDifferentDropEnteredWithDurationKnownFalseWillReturnEmpty() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?drop=16.1")).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/iso-versions/iso-versions.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListLettersEnteredWillReturnError() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?drop=abc")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/iso-versions/iso-versions.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListCharsEnteredWillReturnError() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?drop=$$$")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/clme/iso-versions/iso-version.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListBlankEnteredWillReturnError() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?drop=")).then()
                .statusCode(HttpStatus.BAD_REQUEST.value());
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", files = {
        "/common/no-data.json" }, mapping = "/clme/clme-mapping.json") })
    @ServerDateTime("09-02-2016 12:00:00")
    public void testIsoVersionListNoDataWillReturnEmpty() {
        when().get(format("%s%s%s", basicUrl, END_POINT, "?drop=15.17")).then()
                .statusCode(HttpStatus.OK.value())
                .body("size()", equalTo(0));
    }
}
