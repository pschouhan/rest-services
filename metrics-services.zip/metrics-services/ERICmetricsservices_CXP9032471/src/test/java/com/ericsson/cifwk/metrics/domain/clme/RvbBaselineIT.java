
package com.ericsson.cifwk.metrics.domain.clme;

import static java.lang.String.format;

import static org.hamcrest.CoreMatchers.equalTo;

import static com.jayway.restassured.RestAssured.when;

import org.junit.Test;
import org.springframework.http.HttpStatus;

import com.ericsson.cifwk.metrics.domain.test.AbstractIntegrationTest;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixture;
import com.ericsson.cifwk.metrics.domain.test.fixture.Fixtures;
import com.ericsson.cifwk.metrics.domain.test.fixture.ServerDateTime;
import com.ericsson.cifwk.metrics.domain.test.fixture.SprintFixture;

@SprintFixture
public class RvbBaselineIT extends AbstractIntegrationTest {

    private static final String END_POINT = "/rvb-baseline";
    

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/happyPath.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineShouldReturnHigherMasterVersion() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineNodes", equalTo("3"))
                .body("baselineStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.16"))
                .body("baselineRVBIsoVersion", equalTo("1.15.50"))
                .body("baselineRVBProductVersion", equalTo("15.16.52"));
    }
    
    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/OldSprintHasHighestMasterVersion.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineWhenSprintOutOfRangeHasHighestMasterVersionWillNotReturn() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineNodes", equalTo("3"))
                .body("baselineStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.17"))
                .body("baselineRVBIsoVersion", equalTo("1.15.50"))
                .body("baselineRVBProductVersion", equalTo("15.17.51"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/duplicates.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineDuplicateShouldReturnOneItem() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineNodes", equalTo("3"))
                .body("baselineStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.16"))
                .body("baselineRVBIsoVersion", equalTo("1.15.50"))
                .body("baselineRVBProductVersion", equalTo("15.16.52"));
    }
 
    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/finishedLevelNoRVB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineNoRecordForFinishedLevelShouldReturnEmptyString() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/sort.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineSameMasterVersionShouldReturnMaxNode() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineNodes", equalTo("23"))
                .body("baselineStatus", equalTo("SUCCESS"))
                .body("drop", equalTo("15.16"))
                .body("baselineRVBIsoVersion", equalTo("1.15.50"))
                .body("baselineRVBProductVersion", equalTo("15.16.52"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/messageTypeNoCDB.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineNoRecordForMessageTypeShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/resultFailure.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineNoRecordForResultShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/messageTypeEmpty.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineMessageTypeEmptyShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }
     
    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/completedEventFalse.json" }) })
    @ServerDateTime("26-11-2015 00:00:00")
    public void testMaintrackRadiatorRvbBaselineCompletedEventFalseShouldReturnMessage() {

        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/regexAlphanumericCheck.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testAlphanumericMasterVersionRegexWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/regexStringCheck.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testMasterVersionHavingStringWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }

    @Test
    @Fixtures(dropIndex = true, fixtures = { @Fixture(type = "clme", mapping = "/clme/clme-mapping.json",
            files = { "/clme/rvb-baseline/regexWhenMasterVersionBlank.json" }) })
    @ServerDateTime("15-11-2015 00:00:00")
    public void testRegexMasterVersionBlankWillReturnNotSet() {
        when().get(format("%s%s", basicUrl, END_POINT)).then()
                .statusCode(HttpStatus.OK.value())
                .body("baselineRVBIsoVersion", equalTo("Not Set"))
                .body("baselineRVBProductVersion", equalTo("Not Set"));
    }

}
